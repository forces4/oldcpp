
#include <math.h>
#include <stdlib.h>
#include <GL/glut.h>
#include <conio.h>
#include <iostream.h>
#include <stdio.h>
#include <fstream.h>

ofstream outFile("pic.txt");


//function prototypes -----------------                

void init(void);
void mouse(int button, int state, int x, int y);
void mousemove(int button, int state, int x, int y);
void display(void);
void drawgrid(void);
void drawpic(void);
void piccol(void); // prompt for color to draw
void writepic(void);//send array to file


//end function prototypes----------

//----------siz x and y is size of pic--

const int sizx=16;
const int sizy=16;

//for textures, sizx and sizy must be powers of 2.
// 2, 4, 8, 16, 32, 64, 128, 256

int ww=500; //width of drawing window
int wh=500; // height of drawing window

int dotsize=ww/sizx; //size of magnified pixels

//current cursor pos of mouse-------
int xpos=0; 
int ypos=0;
//----------------------------------


float picture[sizx][sizy][4]; // aray for color values, r, g, b, a

float currentcol[4]; // brush color


//------------------------begin init---------------------

void init(void)
{
	glClearColor(0.0,0.0,0.0,0.0);
	glShadeModel(GL_FLAT);


	for(int x=0; x<sizx; x++)
	{
		for(int y=0; y<sizy; y++)
		{
			picture[x][y][0] =.6;
			picture[x][y][1] =.6;
			picture[x][y][2] =.6;
			picture[x][y][3] =1;

			//above is clear color for picture
		}

	}

}//-----------------------------end init--------------



//-----------------------------begin mouse-----------------
void
mouse(int button, int state, int x, int y)
{
  if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN) 
  {
	  
	  xpos= int((x * sizx)/ww);
	  ypos= int(((wh-y) * sizy)/wh); // picture is mirrored around y axis for some reason.

	  picture[xpos][ypos][0] = currentcol[0];
	  picture[xpos][ypos][1] = currentcol[1];
	  picture[xpos][ypos][2] = currentcol[2];

	  //printf("x %d  y %d \n ",x, y);

glutPostRedisplay();
  }


if (button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN) 
    piccol(); // very cheasy way for setting brush color, have to manually input values.


}//----------end mouse---------------------


//-----------start mousemove------------(for holding button down and moving mouse)

void mousemove(int x, int y)
{

//below conditional speeds up process, keeps function from doing anything unless
//mouse position changes to new pixel.
//-=-----------------------------------------------------------------------
	if(int((x * sizx)/ww) != xpos || int(((wh-y) * sizy)/wh) != ypos)
	{
		xpos= int((x * sizx)/ww);
		ypos= int(((wh-y) * sizy)/wh);

	  picture[xpos][ypos][0] = currentcol[0];
	  picture[xpos][ypos][1] = currentcol[1];
	  picture[xpos][ypos][2] = currentcol[2];
		
	  //printf("x %d  y %d \n ",x, y); //<<<that was for debug

		glutPostRedisplay();
	}

}// ---------end mousevove----------


//------------------begin piccol---------(cheasy color choosing routine, you may want to fix it)
void piccol(void)
{
currentcol[3] =1; //alpha value.  remember 3 is the 4th pos in array (0 to n-1)

//--when inputing values be sure they are floats between 0 and 1.

	cout << '\n' << "red ";
	cin >> currentcol[0];
        cout << '\n' << "green ";
	cin >> currentcol[1];
	cout << '\n' << "blue ";
	cin >> currentcol[2];

	//cout << '\n' << '\n' << "red in hex is " << (GLubyte) (currentcol[0] * 255) 
	// << '\n' << '\n';

}//---------------end piccol

//---------------------------------------begin drawgrid---------

void drawgrid(void)
{

	glColor3f(.5,.5,.5);
	

	glBegin(GL_LINES);

for(int x=0; x<sizx; x++)
{

	glVertex3i(x * dotsize,0,0);
	glVertex3i(x * dotsize, sizy * dotsize,0);


}

for(int y=0; y<sizy; y++)
{

	glVertex3i(0, y * dotsize,0);
	glVertex3i(sizx * dotsize , y*dotsize,0);

}

glEnd();

}//--------------end drawgrid----------


//---------begin drawpic-------------
void drawpic(void)
{

for(int x=0; x<sizx; x++)
{
	for(int y=0; y<sizy; y++)
	{
		glColor3f(picture[x][y][0], picture[x][y][1], picture[x][y][2] );

	glRecti(x * dotsize, y * dotsize,
		    x * dotsize + dotsize, y*dotsize + dotsize);

	}
}


}//----------------end drawpic------------




//-------begin writepic--------------------------------------------------------------
// had to write the image as 3 diferent pictures, 1 for each color component.
// the multidemensional array assignment crap was to confusing to me.
// example: crap[2][2]= { {blah, blah}, {blah, blah} };
// cant bend my mind around 3 dimensions.  guess i am a flat kind of guy.
// the 3 pictures are reasembled in the fast3d program.

void writepic(void)
{

cout << "in outfile"; // <-- was for debuging

//below is actually code that gets compiled when fast3d includes the pic.txt
//kind of weird that the program writes it own code, wonder if this concept could 
//be used for AI?

	outFile  << "const int sizx=" << sizx << ";" << '\n' <<
		      "const int sizy=" << sizy << ";"; 
		
for(int colnum=0; colnum <3; colnum++)
{
	outFile << '\n'<< '\n';

	if(colnum ==0)
	outFile << "float red[][sizy]= {" << '\n';
	if(colnum==1)
	outFile << "float green[][sizy]= {" << '\n';
	if(colnum==2)
	outFile << "float blue[][sizy]= {" << '\n';

	for(int ry=0; ry<sizy; ry++)
	{
		outFile << "{";

		for(int rx=0; rx <sizx; rx++)
		{	
			outFile << picture[rx][ry][colnum];

			if(rx < sizx -1)
			outFile <<","; 

		}

		if(ry < sizy-1)
		outFile << "}," << '\n';
		else 
			outFile << "}" << '\n' << "};";

	}//end ry loop

}//end colnum loop



}//----------------end writepic--------------





//------------begin display----------------------

void
display(void)
{
    glClear(GL_COLOR_BUFFER_BIT );

    glColor3f(1.0,1.0,1.0);
	glLoadIdentity();//clears matrix	
	glScalef(1.0,1.0,1.0);

drawpic();
drawgrid();
 

glutSwapBuffers();
	 glFlush();
}//--------------------------end display-------------


//-------------------begin reshape--------------------
void
reshape(int width, int height)
{
    glViewport(0, 0, width, height);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, sizx * dotsize, 0, sizy * dotsize, -1, 1);
	//glFrustum(-10.0, 10.0 ,-10.0 ,10.0, 10.0, 1000.0);
	//gluPerspective(60.0,1.0,1.5,20);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

	ww= width;
	wh= height;

}//------------------end reshape-------------------


//-------------begin keyboard------------------------

void
keyboard(unsigned char key, int x, int y)
{   	
	if (key ==27) {
        exit(0);
	   }
	if (key=='w')
		writepic();
}


//-----------------end keyboard----------------



int
main(int argc, char** argv)
{	

	glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
    glutInitWindowSize(ww, wh);
    glutInitWindowPosition(50, 50);

    glutCreateWindow(argv[0]);
	init();
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutKeyboardFunc(keyboard);
	glutMouseFunc(mouse);
	glutMotionFunc(mousemove);
	//glutIdleFunc(idle);
	
 
    glutMainLoop();
    return 0;
}



