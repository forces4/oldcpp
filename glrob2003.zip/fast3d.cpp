
#include <math.h>
#include <stdlib.h>
#include <GL/glut.h>
#include <conio.h>
#include <iostream.h>
#include <stdio.h>
#include <rand.h>


#include "pic.txt"
//above is texture image with image size variables.
// use makepic.exe to make diferent picture. have to set 
// image dimensions in source code of makepic.


const int gm=0; //1 for game mode (full screen), 0 for window
const int tex=0; //1 for texture enabled (slow on my computer)

GLuint theBoard; // name for checkerboard
GLuint theBox;  // name for buildings
GLuint windows; // name for texture

const float PI=3.14159265358979323846; 
// half the # of pie slice edges that can fit around the pie pan

float cx=0, cy=4, cz=0;//camera coordinates
float lx=0,ly=4,lz=-40;//camera look at coordinates
float bx=0, by=4, bz=0;// ball coordinates

float direction=PI/2; //camera orientation (radians) 
float ydirection=0;   // for looking up and down
float spin =0;        //rotate the box thingy

float balldir=0;  
float yballdir=0; //up doun direction for ball

int isball =0;  // ball durration counter

int up=0, down=0, left=0, right=0, pup=0, pdown=0;  // keyboard flags

float scale=1;          //size of everything
int bsize=15; //ball size

int boxstart=15876;  // location in square[] where board values end
int boxcount=boxstart;  //cursor for building (box) array
const int numboxes = 100;  // number of buildings

GLfloat square[37600];  //vertex array for board and buildings
//37500 total w/6faces per box
//21600 = 9*4*6*100
 
//below is for transparancy
GLubyte window[] ={
0xAA, 0xAA, 0xAA, 0xAA, 0x55, 0x55, 0x55, 0x55, 
0xAA, 0xAA, 0xAA, 0xAA, 0x55, 0x55, 0x55, 0x55,
0xAA, 0xAA, 0xAA, 0xAA, 0x55, 0x55, 0x55, 0x55, 
0xAA, 0xAA, 0xAA, 0xAA, 0x55, 0x55, 0x55, 0x55,
0xAA, 0xAA, 0xAA, 0xAA, 0x55, 0x55, 0x55, 0x55, 
0xAA, 0xAA, 0xAA, 0xAA, 0x55, 0x55, 0x55, 0x55,
0xAA, 0xAA, 0xAA, 0xAA, 0x55, 0x55, 0x55, 0x55, 
0xAA, 0xAA, 0xAA, 0xAA, 0x55, 0x55, 0x55, 0x55,
0xAA, 0xAA, 0xAA, 0xAA, 0x55, 0x55, 0x55, 0x55, 
0xAA, 0xAA, 0xAA, 0xAA, 0x55, 0x55, 0x55, 0x55,
0xAA, 0xAA, 0xAA, 0xAA, 0x55, 0x55, 0x55, 0x55, 
0xAA, 0xAA, 0xAA, 0xAA, 0x55, 0x55, 0x55, 0x55,
0xAA, 0xAA, 0xAA, 0xAA, 0x55, 0x55, 0x55, 0x55, 
0xAA, 0xAA, 0xAA, 0xAA, 0x55, 0x55, 0x55, 0x55,
0xAA, 0xAA, 0xAA, 0xAA, 0x55, 0x55, 0x55, 0x55, 
0xAA, 0xAA, 0xAA, 0xAA, 0x55, 0x55, 0x55, 0x55,
};

int city [numboxes][6]; // array for making a building w/6 vertacies
GLubyte pic[sizx][sizy][3]; //texture


//x,y,z, xmove, ymove, zmove------------

int sqdone=0; //dont think this is used anymore.


//function prototypes-----------------------------------------

void display(void);  
void drawbox(int boxl, int boxh, int boxw, int tx, int ty, int tz );
void idle(void);
void init(void);
int issolid(int x, int y, int z); //so you cant walk through buildings
void keyboard(unsigned char key, int x, int y); 
void makeboard(void);                           //checkerboard pattern
void reshape(int width, int height);
void shootball(void);
void special(int key, int x, int y);  //for keys with no ascii code
void specialup(int key, int x, int y);// what to do when you let up on a key
void spincam(void);
void makepic(void);

//-----------------------------------ShootBall--------------
void shootball(void)
{

	float sdis=(4*isball*cos(yballdir))*sin(balldir)*scale;
    float cdis=(4*isball*cos(yballdir))*cos(balldir)*scale;

	//sdis = sine;  cdis = cosine distance
		

glColor4f(1,.1,.1,1);	

glEnable(GL_POLYGON_STIPPLE);
glPolygonStipple(window); // for transparancy

if(isball<=30 && !issolid(bx+cdis, by+4*isball*sin(yballdir)*scale, bz-sdis))
{
	glColor4f(0,0,1,1);		

	bz-=sdis;
		
	bx+=cdis;

	by+= 4*isball*sin(yballdir)*scale;


}
else if(isball<30) isball = 30;

		
isball++;


if(isball >30)
{
	bsize=bsize+20; // for explosion
	glDisable(GL_POLYGON_STIPPLE);
}
	glPushMatrix();

	glTranslatef(bx /scale, by /scale, bz /scale);
	

//glPolygonMode(GL_BACK, GL_FILL);

glutSolidSphere(bsize,20,20);

//glPolygonMode(GL_BACK, GL_LINE);
		
glDisable(GL_POLYGON_STIPPLE);
glPopMatrix();

if(isball >=60)
{
isball=0;

bsize=15;
}


}//--------------------------------end shootball----------





//--------------------------------------------draw box--------


void drawbox(int boxl, int boxh, int boxw, int tx, int ty, int tz )
{

//glEnable(GL_POLYGON_STIPPLE);
//glPolygonStipple(window);

// below sets up building collors------------
// I replaced normal values with texture coordinates.
// you would have to comment out texture values and uncomment
// the normals for lighting and disable texture.


// -------------------------top face

// top face  bottom right 
//color
square[boxcount]=.7;
boxcount++;
square[boxcount]=.7;
boxcount++;
square[boxcount]=.7;
boxcount++;

/*/normals 

square[boxcount]= 0;
boxcount++;
square[boxcount]=1;
boxcount++;
square[boxcount]= 0;
boxcount++;
*/

//------top face  bottom right textures
square[boxcount]= 1;
boxcount++;
square[boxcount]=0;
boxcount++;
square[boxcount]= 0;//not used, texture is 2d.
boxcount++;


//vertex

square[boxcount]= tx +boxl/2;
boxcount++;
square[boxcount]= ty +boxh;
boxcount++;
square[boxcount]= tz +boxw/2;
boxcount++;

// ---------------top face top right
//color	

square[boxcount]=.7;
boxcount++;
square[boxcount]=.7;
boxcount++;
square[boxcount]=.7;
boxcount++;

/*/normal

square[boxcount]= 0;
boxcount++;
square[boxcount]=1;
boxcount++;
square[boxcount]= 0;
boxcount++;
*/

//top face top right textures 
square[boxcount]= 1;
boxcount++;
square[boxcount]= 1;
boxcount++;
square[boxcount]= 0; //not used
boxcount++;




//vertex

square[boxcount]= tx +boxl/2;
boxcount++;
square[boxcount]= ty +boxh;
boxcount++;
square[boxcount]= tz - boxw/2;
boxcount++;

//--------------top face top left

//color
square[boxcount]= .6;
boxcount++;
square[boxcount]= .6;
boxcount++;
square[boxcount]= .6;	
boxcount++;
	
/*/normal
square[boxcount]= 0;
boxcount++;
square[boxcount]=1;
boxcount++;
square[boxcount]= 0;
boxcount++;
*/

// top face top left textures
square[boxcount]= 0;
boxcount++;
square[boxcount]=1;
boxcount++;
square[boxcount]= 0;//not used
boxcount++;


//vertex
square[boxcount]= tx -boxl/2;
boxcount++;
square[boxcount]= ty +boxh;
boxcount++;
square[boxcount]= tz -boxw/2;
boxcount++;

//---------------------top face bottom left
//color
square[boxcount]= .7;
boxcount++;
square[boxcount]= .7;
boxcount++;
square[boxcount]= .7;	
boxcount++;	

/*/normal
square[boxcount]= 0;
boxcount++;
square[boxcount]=1;
boxcount++;
square[boxcount]= 0;
boxcount++;
*/

//top face bottom left textures
square[boxcount]= 0;
boxcount++;
square[boxcount]=0;
boxcount++;
square[boxcount]= 0;
boxcount++;

//vertex
square[boxcount]= tx -boxl/2;
boxcount++;
square[boxcount]= ty +boxh;
boxcount++;
square[boxcount]= tz +boxw/2;
boxcount++;

// -----------front face bottom right

//color
square[boxcount]= .5;
boxcount++;
square[boxcount]= .7;
boxcount++;
square[boxcount]= .7;	
boxcount++;
	
/*/normal
square[boxcount]= 0;
boxcount++;
square[boxcount]=0;
boxcount++;
square[boxcount]= 1;
boxcount++;
*/

// front face bottom right texture
square[boxcount]= boxl/10;
boxcount++;
square[boxcount]=0;
boxcount++;
square[boxcount]= 1;//not used
boxcount++;

//vertex
square[boxcount]= tx +boxl/2;
boxcount++;
square[boxcount]= ty;
boxcount++;
square[boxcount]= tz +boxw/2;
boxcount++;

// -------------------front face top right
//color
square[boxcount]= .7;
boxcount++;
square[boxcount]= .7;
boxcount++;
square[boxcount]= .8;	
boxcount++;
	
/*/normal
square[boxcount]= 0;
boxcount++;
square[boxcount]=0;
boxcount++;
square[boxcount]= 1;
boxcount++;
*/

//-front face top right texture
square[boxcount]= boxl/10;
boxcount++;
square[boxcount]=boxh/10;
boxcount++;
square[boxcount]= 1;//not used
boxcount++;

//vertex
square[boxcount]= tx +boxl/2;
boxcount++;
square[boxcount]= ty + boxh;
boxcount++;
square[boxcount]= tz +boxw/2;
boxcount++;

//------------ front face top left
//color
square[boxcount]= .6;
boxcount++;
square[boxcount]= .6;
boxcount++;
square[boxcount]= .8;	
boxcount++;
	
/*/normal
square[boxcount]= 0;
boxcount++;
square[boxcount]=0;
boxcount++;
square[boxcount]= 1;
boxcount++;
*/

//front face top left texture
square[boxcount]= 0;
boxcount++;
square[boxcount]=boxh/10;
boxcount++;
square[boxcount]= 1;//not used
boxcount++;

//vertex
square[boxcount]= tx -boxl/2;
boxcount++;
square[boxcount]= ty + boxh;
boxcount++;
square[boxcount]= tz +boxw/2;
boxcount++;

// ----------front face bottom left
//color
square[boxcount]= .6;
boxcount++;
square[boxcount]= .7;
boxcount++;
square[boxcount]= .8;	
boxcount++;
	
/*/normal
square[boxcount]= 0;
boxcount++;
square[boxcount]=0;
boxcount++;
square[boxcount]= 1;
boxcount++;
*/

//front face bottom left texture
square[boxcount]= 0;
boxcount++;
square[boxcount]=0;
boxcount++;
square[boxcount]= 1;
boxcount++;

//vertex
square[boxcount]= tx -boxl/2;
boxcount++;
square[boxcount]= ty;
boxcount++;
square[boxcount]= tz +boxw/2;
boxcount++;

//-----------left face bottom right
//color
square[boxcount]= .6;
boxcount++;
square[boxcount]= .6;
boxcount++;
square[boxcount]= .6;	
boxcount++;
	
/*/normal
square[boxcount]= -1;
boxcount++;
square[boxcount]=0;
boxcount++;
square[boxcount]= 0;
boxcount++;
*/

//left face bottom right texture
square[boxcount]= boxw/10;
boxcount++;
square[boxcount]=0;
boxcount++;
square[boxcount]= 0;//not used
boxcount++;

//vertex
square[boxcount]= tx -boxl/2;
boxcount++;
square[boxcount]= ty;
boxcount++;
square[boxcount]= tz +boxw/2;
boxcount++;

//---------left face top right
//color
square[boxcount]= .7;
boxcount++;
square[boxcount]= .7;
boxcount++;
square[boxcount]= .8;	
boxcount++;
	
/*/normal
square[boxcount]= -1;
boxcount++;
square[boxcount]=0;
boxcount++;
square[boxcount]= 0;
boxcount++;
*/

//left face top right texture 
square[boxcount]= boxw/10;
boxcount++;
square[boxcount]= boxh/10;
boxcount++;
square[boxcount]= 0;
boxcount++;

//vertex
square[boxcount]= tx -boxl/2;
boxcount++;
square[boxcount]= ty +boxh;
boxcount++;
square[boxcount]= tz +boxw/2;
boxcount++;

//---------left face top left
//color
square[boxcount]= .6;
boxcount++;
square[boxcount]= .6;
boxcount++;
square[boxcount]= .8;	
boxcount++;
	
/*/normal
square[boxcount]= -1;
boxcount++;
square[boxcount]=0;
boxcount++;
square[boxcount]= 0;
boxcount++;
*/
	
//left face top left texture
square[boxcount]= 0;
boxcount++;
square[boxcount]=boxh/10;
boxcount++;
square[boxcount]= 0;
boxcount++;

//vertex
square[boxcount]= tx -boxl/2;
boxcount++;
square[boxcount]= ty +boxh;
boxcount++;
square[boxcount]= tz -boxw/2;
boxcount++;

//------------left face bottom left
//color
square[boxcount]= .3;
boxcount++;
square[boxcount]= .3;
boxcount++;
square[boxcount]= .3;	
boxcount++;
	
/*/normal
square[boxcount]= -1;
boxcount++;
square[boxcount]=0;
boxcount++;
square[boxcount]= 0;
boxcount++;
*/

//left face bottom left texture
square[boxcount]= 0;
boxcount++;
square[boxcount]=0;
boxcount++;
square[boxcount]= 0;
boxcount++;

//vertex
square[boxcount]= tx -boxl/2;
boxcount++;
square[boxcount]= ty;
boxcount++;
square[boxcount]= tz -boxw/2;
boxcount++;
 

//---------right face bottom right
//color
square[boxcount]= .3;
boxcount++;
square[boxcount]= .3;
boxcount++;
square[boxcount]= .3;	
boxcount++;
	
/*/normal
square[boxcount]= 1;
boxcount++;
square[boxcount]=0;
boxcount++;
square[boxcount]= 0;
boxcount++;
*/
	
//right face bottom right texture
square[boxcount]= boxw/10;
boxcount++;
square[boxcount]=0;
boxcount++;
square[boxcount]= 0;
boxcount++;

//vertex
square[boxcount]= tx +boxl/2;
boxcount++;
square[boxcount]= ty;
boxcount++;
square[boxcount]= tz -boxw/2;
boxcount++;

//------------right face top right
//color
square[boxcount]= .8;
boxcount++;
square[boxcount]= .8;
boxcount++;
square[boxcount]= .8;	
boxcount++;
	
/*/normal
square[boxcount]= 1;
boxcount++;
square[boxcount]=0;
boxcount++;
square[boxcount]= 0;
boxcount++;
*/
	
//right face top right texture
square[boxcount]= boxw/10;
boxcount++;
square[boxcount]=boxh/10;
boxcount++;
square[boxcount]= 0;
boxcount++;

//vertex
square[boxcount]= tx +boxl/2;
boxcount++;
square[boxcount]= ty +boxh;
boxcount++;
square[boxcount]= tz -boxw/2;
boxcount++;

//----------right face top left
//color
square[boxcount]= .6;
boxcount++;
square[boxcount]= .6;
boxcount++;
square[boxcount]= .8;	
boxcount++;
	
/*/normal
square[boxcount]= 1;
boxcount++;
square[boxcount]=0;
boxcount++;
square[boxcount]= 0;
boxcount++;
*/

//right face top left texture
square[boxcount]= 0;
boxcount++;
square[boxcount]=boxh/10;
boxcount++;
square[boxcount]= 0;
boxcount++;

//vertex
square[boxcount]= tx +boxl/2;
boxcount++;
square[boxcount]= ty +boxh;
boxcount++;
square[boxcount]= tz +boxw/2;
boxcount++;
	
//right face bottom left
//color
square[boxcount]= .4;
boxcount++;
square[boxcount]= .4;
boxcount++;
square[boxcount]= .4;	
boxcount++;
	
/*/normal
square[boxcount]= 1;
boxcount++;
square[boxcount]=0;
boxcount++;
square[boxcount]= 0;
boxcount++;
*/
	
//right face bottom left texture
square[boxcount]= 0;
boxcount++;
square[boxcount]=0;
boxcount++;
square[boxcount]= 0;
boxcount++;

//vertex
square[boxcount]= tx +boxl/2;
boxcount++;
square[boxcount]= ty;
boxcount++;
square[boxcount]= tz +boxw/2;
boxcount++;
	
	// back  face    --wind is clockwise.
//back face top right
//color
square[boxcount]= .6;
boxcount++;
square[boxcount]= .6;
boxcount++;
square[boxcount]= .8;	
boxcount++;
	
/*/normal
square[boxcount]= 0;
boxcount++;
square[boxcount]=0;
boxcount++;
square[boxcount]= -1;
boxcount++;
*/

//back face top right texture
square[boxcount]= boxl/10;
boxcount++;
square[boxcount]=boxh/10;
boxcount++;
square[boxcount]= -1;
boxcount++;

//vertex
square[boxcount]= tx +boxl/2;
boxcount++;
square[boxcount]= ty +boxh;
boxcount++;
square[boxcount]= tz -boxw/2;
boxcount++;

//------------------back face bottom right
//color
square[boxcount]= .4;
boxcount++;
square[boxcount]= .4;
boxcount++;
square[boxcount]= .4;	
boxcount++;
	
/*/normal
square[boxcount]= 0;
boxcount++;
square[boxcount]=0;
boxcount++;
square[boxcount]= -1;
boxcount++;
*/
	
//back face bottom right texture
square[boxcount]= boxl/10;
boxcount++;
square[boxcount]=0;
boxcount++;
square[boxcount]= -1;
boxcount++;


//vertex
square[boxcount]= tx +boxl/2;
boxcount++;
square[boxcount]= ty;
boxcount++;
square[boxcount]= tz -boxw/2;
boxcount++;

//---------------back face bottom left
//color
square[boxcount]= .5;
boxcount++;
square[boxcount]= .5;
boxcount++;
square[boxcount]= .5;	
boxcount++;
	
/*/normal
square[boxcount]= 0;
boxcount++;
square[boxcount]=0;
boxcount++;
square[boxcount]= -1;
boxcount++;
*/
	
//back face bottom left texture
square[boxcount]= 0;
boxcount++;
square[boxcount]=0;
boxcount++;
square[boxcount]= -1;
boxcount++;

//vertex
square[boxcount]= tx -boxl/2;
boxcount++;
square[boxcount]= ty;
boxcount++;
square[boxcount]= tz -boxw/2;
boxcount++;

//---------------back face top left
//color
square[boxcount]= .7;
boxcount++;
square[boxcount]= .7;
boxcount++;
square[boxcount]= .8;	
boxcount++;
	
/*/normal
square[boxcount]= 0;
boxcount++;
square[boxcount]=0;
boxcount++;
square[boxcount]= -1;
boxcount++;
*/
	
//back face top left texture
square[boxcount]= 0;
boxcount++;
square[boxcount]=boxh/10;
boxcount++;
square[boxcount]= -1;
boxcount++;

//vertex
square[boxcount]= tx -boxl/2;
boxcount++;
square[boxcount]= ty +boxh;
boxcount++;
square[boxcount]= tz -boxw/2;

boxcount++;

//glDisable(GL_POLYGON_STIPPLE);

}//----------------------------------end Drawbox-------


//-----------------------------------start Makeboard----------------
void makeboard(void)
{


//---[ 3color, 3normal, x,y,z,]*21*21

if(sqdone==0)
{
int col=1;
int vcount=0;
GLfloat r=0,g=0,b=0;    //red green blue
GLfloat xcoo, ycoo, zcoo;


for(int z=-10; z<=10; z++)
{
	for(int x=-10;x<=10;x++)
	{
		for(int corner=0;corner<=3; corner++)
		{
		//-------------------colors---------
		if(col==1)
		{
		r=1;g=0;b=0;	
	        //glColor3f(1, 0, 0);
		}

		else
		{
		r=1;g=1;b=0;
		//glColor3f(1,1,0);
		} 

		//start setting array values---------------------
		

		square[vcount]=r;
		vcount++;
		square[vcount]=g;
		vcount++;
		square[vcount]=b;
		vcount++;

		
		
		//---------------------normals--------------
		square[vcount]=0;
		vcount++;
		square[vcount]=1;
		vcount++;
		square[vcount]=0;
		vcount++;
		
		//--------------------XYZ Coodinates-------------
		
		if(corner==0){xcoo=x*20; ycoo = -50; zcoo = -z*20;}//lower left
		if(corner==1){xcoo=x*20+20; ycoo = -50; zcoo =- z*20;}//lower right
		if(corner==2){xcoo=x*20+20; ycoo = -50; zcoo =- z*20 -20;}//upper right
		if(corner==3){xcoo=x*20; ycoo = -50; zcoo = -z*20 -20;}//uper left

		square[vcount]=xcoo;
		vcount++;
		square[vcount]=ycoo;
		vcount++;
		square[vcount]=zcoo;
		vcount++;
		
//printf("count = %d\n",vcount);
		}//----------end corner for loop------------


	
		
//-----------------------------------------------------

		col=-col;
	
	}//---------end x loop

}//---------end zloop




}//--------------------------------end if sqdone
sqdone=1;


//---[ 3color, 3normal, x,y,z,]*21*21




}//---------end makeboard-----------------------


//-------------------------------start issolid--------------
//(so you can't walk through buildings)

int issolid(int x, int y, int z)
{


	for(int building=0; building<numboxes; building++)
	{
	
		if(
			x < (city[building][3] + city[building][0]/2)*scale +2*scale&&
			x > (city[building][3] - city[building][0]/2)*scale -2*scale&&
			y < (city[building][4] + city[building][1]) *scale +2*scale &&
			y > city[building][4] * scale  -2*scale &&
			z < (city[building][5] + city[building][2]/2)*scale +2*scale &&
			z > (city[building][5] - city[building][2]/2)*scale -2*scale 
			

			)
		{
		return(1);	
		}
	}

if(y<-10)return(1); // can't go underground

	return(0);

}




void idle(void)//---------------------------Begin IDLE-------------
{
spin = spin + 5;
if(spin >360*5)
	spin = 0 ;


float sdis=(10*cos(ydirection))*sin(direction)*scale;
float cdis=(10*cos(ydirection))*cos(direction)*scale;


    //down
	if(down) 
	{	
		if( !issolid(cx, cy, cz+sdis))
		{
			cz+=sdis;
			lz+=sdis;
		}

		if( !issolid(cx-cdis, cy, cz))
		{
			cx-=cdis;
			lx-=cdis;
		}
			
			if(cy-10*sin(ydirection)>3 && 
			  !issolid(cx, cy-10*sin(ydirection)*scale, cz))
			{
		cy-=10*sin(ydirection)*scale;
		ly-=10*sin(ydirection)*scale;
			}
		
	}

//if( !issolid(cx+cdis, cy+20*sin(ydirection)*scale, cz-sdis))
	//up
	if(up ) {
		if( !issolid(cx, cy, cz-sdis))
		{
		cz-=sdis;
		lz-=sdis;
		}
		if( !issolid(cx+cdis, cy, cz))
		{
		cx+=cdis;
		lx+=cdis;
		}
			if(cy+10*sin(ydirection)>3  && 
			!issolid(cx, cy+10*sin(ydirection)*scale, cz))
			{
		cy+=10*sin(ydirection)*scale;
		ly+=10*sin(ydirection)*scale;
			}
		
	}
	//left
	if(left){
		direction+=.1;
		lx=cx + 20*cos(ydirection)* cos(direction);
		lz=cz - 20*cos(ydirection)* sin(direction);
		
	}


	//right
	if(right){
		direction-=.1;
		lx=cx + 20*cos(ydirection)* cos(direction);
		lz=cz - 20*cos(ydirection)* sin(direction);
		
	}


		//pup
	if(pup && ydirection<PI/2 -.2){
		ydirection+=.2;
		lx=cx + 20*cos(ydirection)* cos(direction);
		lz=cz - 20*cos(ydirection)* sin(direction);
		ly=cy + 20*sin(ydirection);
		
	}


	//pdown
	if(pdown && ydirection >= -PI/2 +.2){
		ydirection-=.2;
		lx=cx + 20*cos(ydirection)* cos(direction);
		lz=cz - 20*cos(ydirection)* sin(direction);
		ly=cy + 20*sin(ydirection);
		
	}




	
glutPostRedisplay(); 
}

//---------------------------------------END IDLE---------------------------

//------------------------------begin makepic--------
//this combines the r, g, and b components in pic.txt
// and changes data from float to unsigned byte 

void makepic(void)
{
	for(int colnum=0; colnum<3; colnum++){
	for(int cy= 0; cy <sizy; cy++)
	{
		for(int cx=0; cx<sizx; cx++)
		{
			if(colnum==0)
			pic[cx][cy][0] = (GLubyte) (red[cx][cy]*255);
			if(colnum==1)
			pic[cx][cy][1] = (GLubyte) (green[cx][cy]*255);
			if(colnum==2)
			pic[cx][cy][2] = (GLubyte) (blue[cx][cy]*255);
		
		}



	}//end cy loop

	}//end colnum loop

}




void spincam(void)
{

spin = spin + .01;
if(spin >2)
	spin = spin -2 ;
glutPostRedisplay(); 

}


//--------------------------------------BEGIN INIT-------------

void init(void)
{
//glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
	makepic();

	if(gm)glutEnterGameMode();
	glClearColor(0.0,0.7,1.0,0.0);
	glShadeModel(GL_FLAT);
	//glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER, GL_FALSE);

	float pos[]={1,1,1,1};
	glLightfv(GL_LIGHT0, GL_POSITION, pos);
    glEnable(GL_COLOR_MATERIAL);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);

//---------------------------------TEXTURES---------------------	
	if(tex){
	glGenTextures(1, &windows);
	glBindTexture(GL_TEXTURE_2D, windows);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST_MIPMAP_NEAREST);

	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, sizx, sizy, 0, 
		         GL_RGB, GL_UNSIGNED_BYTE, pic);

	//glTexImage2D(target, level[mipmap], internal format, width,  
	// height, border, format,pic data type, name of texture)


	gluBuild2DMipmaps(GL_TEXTURE_2D, GL_RGB, sizx, sizy, 
		         GL_RGB, GL_UNSIGNED_BYTE, pic);

	glBindTexture(GL_TEXTURE_2D, windows);
	}//end if tex
//---------------END TEXTURES----------------
	
	glutIgnoreKeyRepeat(1);
	
makeboard();

	glEnableClientState(GL_COLOR_ARRAY);
	//glEnableClientState(GL_NORMAL_ARRAY);
	if(tex)glEnableClientState(GL_TEXTURE_COORD_ARRAY);
    glEnableClientState(GL_VERTEX_ARRAY);

	//glEnable(GL_BLEND);
	//glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);





//----------make city array-------

for(int cit=0;cit<numboxes;cit++)
{
city[cit][0] =RND()%50;  //width
city[cit][1] =RND()%200; //hight
city[cit][2] =RND()%50;  //lenght
city[cit][3] =RND()%1000 - 500; //x translate
city[cit][4] =0;                   //ytranslate  
city[cit][5] =RND()%1000 - 500; //ztranslate


}






//--------------------------make buildings---------


for(int boxnum=0; boxnum<numboxes; boxnum++)
{
	//drawbox(20+boxnum,10*boxnum,20+boxnum,0,0,100*boxnum);

	drawbox(city[boxnum][0],city[boxnum][1],
	city[boxnum][2],city[boxnum][3],
	city[boxnum][4],city[boxnum][5]);
}

glColorPointer(3, GL_FLOAT, 9*sizeof(GLfloat), &square[0]);
//glNormalPointer(GL_FLOAT, 9*sizeof(GLfloat), &square[3]);
if(tex)glTexCoordPointer(2, GL_FLOAT, 9*sizeof(GLfloat), &square[3]);
glVertexPointer(3, GL_FLOAT, 9*sizeof(GLfloat), &square[6]);




//make boxlist-------------------------------

theBox=glGenLists(2);
glNewList(theBox, GL_COMPILE);

if(tex){
glEnable(GL_TEXTURE_2D);
glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
glBindTexture(GL_TEXTURE_2D, windows);

}//end if tex
glBegin(GL_QUADS);

//boxstart
for(int bcount=1764; bcount<(numboxes*5*4 +1764 ); bcount++)
{
		glArrayElement(bcount);
	
		
	
}//-------------------end count loop-----

glEnd();

glDisable(GL_TEXTURE_2D);
glEndList();


//-------------------------make board list

theBoard=glGenLists(1);
glNewList(theBoard, GL_COMPILE);

glBegin(GL_QUADS);


for(int count=0; count<(21*21*4); count++)
{
		glArrayElement(count);
	
		
	
}//-------------------end count loop-----

glEnd();

glEndList();



}//-------------------------END INIT--------------




//------------------------------------Begin Display-------------------------
void
display(void)
{
    glClear(GL_COLOR_BUFFER_BIT |GL_DEPTH_BUFFER_BIT);

    glColor3f(1.0,1.0,1.0);
	glLoadIdentity();//clears matrix

gluLookAt(cx, cy, cz
		, lx, ly, lz, 0.0, 1.0, 0.0);

	// (camera at x,y,z, aimed at 0,0,0, up is 0,1,0)
	//glScalef(scale, scale,scale);
//glutWireCube(1.0);


	glPolygonMode(GL_FRONT, GL_FILL);
	glPolygonMode(GL_BACK, GL_FILL);


glDisable(GL_LIGHTING);

//-------ground

glColor3f(.3, .8, .3);

glPushMatrix();
glRotatef(-90,1,0,0);
glRectf(-1000,-1000,1000,1000);
glPopMatrix();


//---------------------begin buildings
//skyscrapers

//glEnable(GL_LIGHTING);
glCallList(theBox);



//------------------------------------------------------------end building


//----------------------------------CHECKERBOARD FLOOR & WALL----------

//glCallList(theBoard);


/* 

glPushMatrix();

for(int hop=0; hop<5; hop++)
{

glTranslatef(0,400,-450);
glCallList(theBoard);
}

glPopMatrix();

 */

glPushMatrix();

	glTranslatef(0,50,0);
	glRotatef(180,1,0,0);	

	glCallList(theBoard);

glPopMatrix();



glEnable(GL_LIGHTING);

//----------------------------END CHECKERBOARD----------


if(isball>0) shootball();


//---------------------------below is rotating cube thingy-------

glPushMatrix();

glRotatef(spin,0,1,0);



    glBegin(GL_QUADS);

// back  face    --wind is clockwise.

glColor3f(0, 1, 0);
	glNormal3f(0,0,-1);
	glVertex3i(10, 20,-10);//top right
glColor3f(0, 0, 0);
	glNormal3f(0,0,-1);
	glVertex3i(10, 0,-10);//bottom right
glColor3f(0, 0, 1);
	glNormal3f(0,0,-1);
	glVertex3i(-10, 0,-10); //bottom left
glColor3f(0, 1, 1);
	glNormal3f(0,0,-1);
	glVertex3i(-10, 20,-10); // top left

// face left

glColor3f(1, 0, 1);
	glNormal3f(-1,0,0);
	glVertex3i(-10, 0,10); //bottom right
glColor3f(1, 1, 1);
	glNormal3f(-1,0,0);
	glVertex3i(-10, 20,10); //top right
glColor3f(0, 1, 1);	
	glNormal3f(-1,0,0);
	glVertex3i(-10, 20,-10); // top left
glColor3f(0, 0, 1);
	glNormal3f(-1,0,0);
	glVertex3i(-10, 0,-10); //bottom left

// front face

glColor3f(1, 0, 0);
	glNormal3f(0,0,1);
    glVertex3i(10, 0,10); //bottom right
glColor3f(1, 1, 0);
	glNormal3f(0,0,1);
	glVertex3i(10, 20,10); // top right
glColor3f(1, 1, 1);	
	glNormal3f(0,0,1);
	glVertex3i(-10, 20,10);	// top left
glColor3f(1, 0, 1);
	glNormal3f(0,0,1);
	glVertex3i(-10, 0,10); //bottom left

//  right  face

glColor3f(0, 0, 0);
	glNormal3f(1,0,0);
    glVertex3i(10, 0,-10);//bottom right
glColor3f(0, 1, 0);
	glNormal3f(1,0,0);
	glVertex3i(10, 20,-10);	//top right
glColor3f(1, 1, 0);
	glNormal3f(1,0,0);
	glVertex3i(10, 20,10);  // top left
glColor3f(1, 0, 0);
	glNormal3f(1,0,0);
	glVertex3i(10, 0,10);  //bottom left



    glEnd();


glPopMatrix();

glPushMatrix();
glTranslatef(-25,10,0);
glutWireTorus(24,26,20,1);
glPopMatrix();

glPushMatrix();
glRotatef(-spin,0,1,0);
	glTranslatef(25,10,0);
	
    glColor3f(1,0,1);
	glutSolidCube(7);

glPushMatrix();
glTranslatef(-10,0,0);
glutWireTorus(7.5,8.5,20,1);
glPopMatrix();

glRotatef(3*spin,0,1,0);
//glRotatef(spin,1,0,0);
	glTranslatef(10,0,0);
	
    glColor3f(1,0,0);
	glutSolidCube(3);

glPopMatrix();
//light

glPushMatrix();

float pos[]={0,0,0,1};

glRotatef(.2 * spin,0,1,0);

glTranslatef(200/4,50/4,50/4);
glLightfv(GL_LIGHT0, GL_POSITION, pos);

glDisable(GL_LIGHTING);
glColor3f(1,1,1);

glutWireSphere(20/4,20,20);

glPopMatrix();


glRasterPos3i(0,50, -100);
glDrawPixels(sizx, sizy, GL_RGB, GL_UNSIGNED_BYTE, pic);


glutSwapBuffers();
	 glFlush();
}


//-------------------------------------End Display--------------------------

void
reshape(int width, int height)
{
	


    glViewport(0, 0, width, height);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    //glOrtho(0, 100, 0, 100, -100, 100);
float l=float(width)/float(height);	
	
	if(width<=height)
	glFrustum(-1, 1 ,-1/l ,1/l, 1.5, 1000*scale);
	else
	glFrustum(-l , l , -1 ,1, 1.5, 1000*scale);
	
	
	//gluPerspective(60.0,1.0,1.5,20);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

	glEnable(GL_DEPTH_TEST);

}



void
keyboard(unsigned char key, int x, int y)
{   	
	if (key ==27) {
        exit(0);
	   }

	if (key ==32 && isball==0){
		
		isball=1;
		balldir = direction;
		yballdir = ydirection;
		bx=cx; by=cy; bz= cz;
		

		shootball();

		}

}



void
special(int key, int x, int y)
{
  switch (key) {
  
  case GLUT_KEY_UP:
    up = 1;
    
    break;
  case GLUT_KEY_LEFT:
    left = 1;
    
    break;
  case GLUT_KEY_RIGHT:
    right = 1;
    
    break;
  case GLUT_KEY_DOWN:
    down = 1;

    break;
  case GLUT_KEY_PAGE_UP:
    pup = 1;
    
    break;
  case GLUT_KEY_PAGE_DOWN:
    pdown = 1;
    break;




  }
}


void
specialup(int key, int x, int y)
{
  switch (key) {
  case GLUT_KEY_UP:
    up = 0;
    break;
  case GLUT_KEY_LEFT:
    left = 0;
    break;
  case GLUT_KEY_RIGHT:
    right = 0;
    break;
  case GLUT_KEY_DOWN:
    down = 0;
    break;
  case GLUT_KEY_PAGE_DOWN:
    pdown = 0;
    break;
  case GLUT_KEY_PAGE_UP:
    pup = 0;
    break;




  }
}


int
main(int argc, char** argv)
{	
	glutInit(&argc, argv);
	glutInitDisplayString("rgb double depth>=16");

    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB |GLUT_DEPTH);
    glutInitWindowSize(500, 500);
    if(!gm)glutInitWindowPosition(50, 50);

    if(!gm)glutCreateWindow(argv[0]);
	init();
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutKeyboardFunc(keyboard);
    //glutKeyboardUpFunc(keyup);
    glutSpecialFunc(special);
    glutSpecialUpFunc(specialup);
	glutIdleFunc(idle);
    glutMainLoop();
    return 0;
}

