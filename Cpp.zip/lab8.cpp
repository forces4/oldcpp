#include <iostream>
#include <fstream>
#include <cstdlib>
using namespace std;


class BinaryTree {
public:
    BinaryTree(char filename[]);

    void remove(char target) {bst_remove(root, target);};
    
    friend ostream& operator<<(ostream& out, const BinaryTree& T);
    
private:
    struct Node {
        Node(char ch, Node *l = 0, Node *r = 0) :data(ch), left(l), right(r) {};
        char data;
        Node *left;
        Node *right;
    };

    Node *root;

    void bst_remove(Node*& T, char target);
    void bst_remove_max(Node*& T, char& target);
    
    enum {SCREEN_WIDTH = 79, SCREEN_HEIGHT = 20};
    typedef char Screen[SCREEN_HEIGHT][SCREEN_WIDTH];
    
    friend Node *readBinaryTree(istream& in);
    friend void writeBinaryTree(Screen& S, int& x, int y, int& max_y, Node *T);
};


BinaryTree::BinaryTree(char filename[]) {
    ifstream in(filename);

    if (! in) {
        cout << "\nCan't open file '" << filename << "'.\n";
        exit(1);
    }

    root = readBinaryTree(in);
}


BinaryTree::Node *readBinaryTree(istream& in) {
    char ch;
    in >> ch;
    
    if (ch == '*') {
        return 0;
    } else if (ch == '[') {
        in >> ch;
        BinaryTree::Node *left = readBinaryTree(in);
        BinaryTree::Node *right = readBinaryTree(in);
        char close_bracket;
        in >> close_bracket;
        return new BinaryTree::Node(ch, left, right);
    } else {
        return new BinaryTree::Node(ch);
    }
}


ostream& operator<<(ostream& out, const BinaryTree& T) {
    int x = 0, max_y = 0;
    BinaryTree::Screen S;
    for (int i = 0; i < BinaryTree::SCREEN_HEIGHT; ++i)
        for (int j = 0; j < BinaryTree::SCREEN_WIDTH; ++j)
            S[i][j] = ' ';
            
    writeBinaryTree(S, x, 0, max_y, T.root);
    
    for (int i = 0; i <= max_y; ++i) {
        for (int j = 0; j < BinaryTree::SCREEN_WIDTH; ++j) out << S[i][j];
        out << endl;
    }
    
    return out;
}


void writeBinaryTree(BinaryTree::Screen& S, int& x, int y, int& max_y, BinaryTree::Node *T) {
    if (T != 0) {
        writeBinaryTree(S, x, y+1, max_y, T->left);
        S[y][x] = T->data;
        ++x;
        if (y > max_y) max_y = y;
        writeBinaryTree(S, x, y+1, max_y, T->right);
    }
}


// THESE ARE THE THREE METHODS YOU HAVE TO IMPLEMENT.
// DO NOT CHANGE ANYTHING ELSE IN THE PROGRAM.


void BinaryTree::bst_remove(BinaryTree::Node*& T, char target) {
    
	if (T == 0) {
        ; // case 1    
    } else if (target < T->data) {
        bst_remove(T->left, target); // case 2
    } else if (target > T->data) {
        bst_remove(T->right, target); // case 3
    } else if (T->left == 0) {
        T = T->right; // case 4a
    } else {
        bst_remove_max(T->left, target); // case 4b
    }
}


void BinaryTree::bst_remove_max(BinaryTree::Node*& T, char& target) {
    if (T->right == 0) {
        ; // case 1
    } else {
        ; // case 2
    }
}


int main(int argc, char *argv[]) {
    
    // Parameters argc and argv are passed by the operating system.
    // argc is the number of command-line arguments (including the
    // program name), and argv[0] is the program name, argv[1] is
    // the first command-line argument, argv[2] is the second command-
    // line argument, and so on

    if (argc != 2) {
        cout << "You must specify the name of a binary tree file.\n";
        exit(1);
    }

    // create a binary tree from the file given in command-line argument 1
    BinaryTree T(argv[1]);
    
    cout << "Initial tree:\n\n" << T;
    T.remove('A');
    T.remove('B');
    T.remove('C');
    cout << "\nTree after removal of A, B, and C:\n\n" << T;
}
