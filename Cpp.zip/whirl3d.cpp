#include "3dpoint.h"
#include <iostream.h>
#include <math.h>




int numpoints = 300;

int xmov = 320;
int ymov = 240;
int zmov = 240;

int xfact = 10;
int yfact = 10;
int zfact = 10;
	char x;
	int a=1;
	



void spin();

void main()
{
	x= 'k';	
	



	int install_timer();
	int allegro_init();

	install_keyboard(); 
 	set_gfx_mode(GFX_AUTODETECT, 640, 480, 1024, 1024);
  	 set_pallete(desktop_pallete);

	extern volatile char key[128]; // keyboard flags--if (key[KEY_SPACE])

	


	floodfill(screen, 100, 100, 25);


spin();	




}//--------------end main------------------------------------------


void spin()
{
int xrand = rand () % 100 +1;
int yrand = rand () % 100 +1;
int zrand = rand () % 100 +1;

point whirl[numpoints];


for (int i = 0; i< numpoints; i++)
	{

	whirl[i].move_x(i);
	whirl[i].plot();
	}


	while(! key[KEY_SPACE])
	{
xrand = xrand + random () % 100;
yrand = yrand + random () % 100;
zrand = zrand + random () % 100;

if(xrand > 200)
	xrand = 1;
if(yrand > 200)
	yrand = random () % 1000 +1;
if(zrand > 200)
	zrand = random () % 1000 +1;



xfact = (random () % xrand) +1;
yfact = (random () % yrand) +1;
zfact = (random () % zrand) +1;
floodfill(screen, 100, 100, 25);

	for (float i = 0; i <= 2 * PI + .05; i+= .01)
	{

	
		for (int j = 0; j < numpoints; j++)
		{
			whirl[j].zunplot();
			whirl[j].set_x(xmov + j * cos((j/xfact) * i));
			 
			whirl[j].set_y(ymov + j * sin((j/yfact) * i));
			whirl[j].set_z(zmov + j * sin((j/zfact) * i));
			whirl[j].zplot();
		}
	

	//xmov = int(640 * sin(i/2));
	//ymov = int(400 * sin(i/4));

	if(keypressed())
		i = 100;
	}

	}






}
