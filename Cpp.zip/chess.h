#ifndef CHESS_H

#include "allegro.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>


//global types


const int BLACK = 0;
const int WHITE = 1;
const int RED = 1;

const int EMPTY =0;
const int PAWN = 1;
const int ROOOK = 2;
const int KNIGHT = 3;
const int BISHOP = 4
const int QUEEN = 5
const int KING = 6






class piece
{

	public:

	 piece(kind[3]);
	

	// member functions

	
	void move_x(int distance);
	void move_y(int distance);
	void plot();
	

	private:

	int x_pos;
	int y_pos;
	int type[3];  // type of piece (player, piece, square collor)
	
};

point::point()
{
	x_pos = random () % 640;
	y_pos = random ()% 480;
	colr = random () % 57;
}



void point::move_x(int distance)
{
	if ((x_pos + distance < 2)|| (x_pos +distance > 640))
		x_pos = x_pos - distance;
	else x_pos = x_pos + distance;
}

void point::move_y(int distance)
{
	if ((y_pos + distance < 2)|| (y_pos +distance > 480))
		y_pos = y_pos - distance;
	else y_pos = y_pos + distance;
}


void point::plot()
{
putpixel(screen, x_pos, y_pos, colr);

}
#define POINT_H
#endif

