#include <iostream.h>
#include <rand.h>
#include <math.h>
#include <stdlib.h>

#include <conio.h>


void main()
{

int shape=1;
int a,b;


for(int x=1;x<=10;x++)
{
/*

for(int y=1;y<=5;y++)
{

a=(shape * x^2 + shape * y^2)/shape;
b= (shape * x+2 + shape * y+2)/shape;

cout << "a " << a << "   x " << x << "   y "<< y << 
"             (shape * x^2 + shape * y^2)/shape" <<
'\n' << "b " << b << '\n' << 
"             (shape * x+2 + shape * y+2)/shape" <<endl;


}//end x for

*/
int y=x^2;

cout << x << "   "<< y << '\n'; 
}//end y for

}//--------------------------------------end main

