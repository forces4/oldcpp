#include <iostream.h>
#include <rand.h>
#include "point.h"



#include "allegro.h"

//int keypressed(); true or false
BITMAP *scrbuff;




int main(int argc, char *argv[])
{

char pict[200];
PALLETE my_pallete;
int x, scrmspxl;

int GREY;

allegro_init();
install_timer();

install_mouse();
install_keyboard(); 
set_gfx_mode(GFX_AUTODETECT, 640, 480, 1024, 1024);
   set_pallete(desktop_pallete);

extern volatile char key[128]; // keyboard flags--if (key[KEY_SPACE])

//set_mouse_range(1, 1, 300, 100);

BITMAP *memory_bitmap;
memory_bitmap = create_bitmap(320, 200);
clear(memory_bitmap);
//blit(memory_bitmap, screen, 0, 0, x, y, 320, 200);


//for (y=0; y<SCREEN_H; y+=200)
      //for (x=0; x<SCREEN_W; x+=200)
//for(int n=0; n<100; n++)
	//cout << RND()%320 << endl;

replace_filename(pict, argv[0], "risk.bmp", sizeof(pict));
scrbuff = load_bitmap(pict, my_pallete);
set_pallete (my_pallete);


//void show_mouse(BITMAP *bmp);
//set_mouse_sprite(scrbuff);

floodfill(screen, 1, 1, 11);
blit(scrbuff, screen, 0, 0, 0, 0, 635, 435);
show_mouse(screen);

int RED =160;
const int BLUE = 11;
const int GREEN = 16;
int player = 1;
int col[3];

GREY = getpixel(screen, 500, 200);

col[1] = RED;
col[2] = BLUE;
col[3] = GREEN;

textout(screen, font, "payer one" , 10, 465, RED);
do{
//-----------------------------MAIN-----------------------------------


scrmspxl = getpixel(screen , mouse_x, mouse_y);

if ((mouse_b & 1) && (scrmspxl - GREY < 5 && scrmspxl -GREY > -5)) 
{
scare_mouse();
	
	floodfill(screen, mouse_x, mouse_y, col[player]);
	++player;
	if(player == 4 ) player =1;

	if(player == 1)
	textout(screen, font, "payer one  " , 10, 465, RED);

	if(player == 2)
	textout(screen, font, "payer two  " , 10, 465, BLUE);

	if(player == 3)
	textout(screen, font, "payer three" , 10, 465, GREEN);

unscare_mouse();




}



//--------------------------------------------------------------------
}while (! keypressed());

destroy_bitmap(memory_bitmap);
destroy_bitmap(scrbuff);

   readkey();
   return 0;
}

