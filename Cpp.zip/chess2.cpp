#include <iostream.h>
#include "allegro.h"
#include <string.h>


struct square {

	BITMAP *memory_bitmap;
	char T;
}box[8][8];




const int RED = 224;
const int BLUE = 11;
const int GREEN = 16; 
const int BLACK = 1;
const int WHITE = 255;
const int GREY = 3;
const int MSKED = 0;
int buff_temp = 0;       //-------------color of piece, 0 or 1
int xbox, ybox, scrmspxl;
int xpos[8], ypos[8];
int movx, movy;
int boxcolor = 1;

PALLETE my_pallete;
char pict[200];

BITMAP *scrbuff;

BITMAP *buffer;
BITMAP *ptemp[3];

//-----------------------------------------------------------------




void init();
void make_board();
void draw_board();
void pick_piece();





int main(int argc, char *argv[])//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
{
replace_filename(pict, argv[0], "chess3.bmp", sizeof(pict));



init();
make_board();	
draw_board();	
pick_piece();



//save_bitmap("dump.bmp", buffer, my_pallete);

	for(int n = 0; n < 8 ; n++)
	{
	
	for(int m = 0; m < 8 ;m++)
	{

	destroy_bitmap(box[n][m].memory_bitmap);
	}
	}


destroy_bitmap(scrbuff);

destroy_bitmap(buffer);

for(int n = 0; n<=2 ; n++)
	destroy_bitmap(ptemp[n]);


   readkey();
   return 0;

}//-----------------------------------------------------------
//-----------------------FUNCTIONS------------------------------

void init()
{
allegro_init();
install_timer();
install_mouse();
install_keyboard(); 

set_gfx_mode(GFX_AUTODETECT, 640, 480, 1024, 1024);
   set_pallete(desktop_pallete);

extern volatile char key[128]; // -------keyboard flags--if (key[KEY_SPACE])


scrbuff = load_bitmap(pict, my_pallete);//--------load picture--------------
set_pallete (my_pallete);

buffer = create_bitmap(560, 120);

for(int n =0 ; n <=2; n++)
	ptemp[n] = create_bitmap(80, 60);


blit(scrbuff, buffer, 0, 0, 0, 0, 570, 130);
floodfill(buffer, 1, 1, MSKED);
show_mouse(screen);

for(int y = 0; y<8; y++){xpos[y] = y*80; ypos[y] = y*60;}  // --setup position grid-

}

//------------------------------------MAKE BOARD-----------------------

void make_board()
{
int col = RED;
int colswtch = 0;

	for(int n = 0; n < 8 ; n++)
	{
	
	for(int m = 0; m < 8; m++)
	{
		if(colswtch == 0 && m!=0)
		{
			colswtch = 1;
			col = BLACK;
		}
		
		else if(colswtch == 1 && m!=0)
		{
			colswtch = 0;
			col = RED;
		}
	
		box[m][n].memory_bitmap = create_bitmap(80, 60);
		clear_to_color(box[m][n].memory_bitmap, col);
		//floodfill(box[m][n].memory_bitmap, 10, 10, col);
		

	}
	
	}


}

//-----------------------------------------

void draw_board()
{
for(int y = 0; y < 8; y++)
{
	if((y > 1) || (y<6))
		

	for(int x = 0; x < 8; x++)
	{
		if((y > 1) || (y<6))
			box[x][y].T = 'E';

	scare_mouse();
	
	//----------------------pawns------------

	if(y == 1)
	{
		masked_blit(buffer, box[x][y].memory_bitmap, 0, 0, 0, 0, 80, 60);
		box[x][y].T = 'p';
	}
	if(y == 6)
	{
		masked_blit(buffer, box[x][y].memory_bitmap, 0, 60, 0, 0, 80, 60);
		box[x][y].T = 'P';
	}

	//------------------- player pieces-----------------------
	if(y==0)buff_temp = 0;
	if(y==7)buff_temp = 1;
	if(y != 0 && y != 7)buff_temp = -1;
	
	if(buff_temp != -1 && (x == 0 || x == 7))//--------ROOKS--------------
	{
	
		masked_blit(buffer, box[x][y].memory_bitmap, xpos[1], ypos[buff_temp], 0, 0, 80, 60);
		if( y == 7)
			box[x][y].T = 'R';
		if( y == 0)
			box[x][y].T = 'r';
			
	}	
	
	if(buff_temp != -1 && (x == 1 || x == 6))//--------KNIGHTS--------------
	{
		masked_blit(buffer, box[x][y].memory_bitmap, xpos[2], ypos[buff_temp], 0, 0, 80, 60);
		
		if( y == 7)
			box[x][y].T = 'N';
		if( y == 0)
			box[x][y].T = 'n';	
	}

	if(buff_temp != -1 && (x == 2 || x == 5))//--------BISHOPS--------------
	{
		masked_blit(buffer, box[x][y].memory_bitmap, xpos[5], ypos[buff_temp], 0, 0, 80, 60);
		if( y == 7)
			box[x][y].T = 'B';
		if( y == 0)
			box[x][y].T = 'b';	
	}

	if(buff_temp != -1 && (x == 3))//--------QUEENS--------------
	{
		masked_blit(buffer, box[x][y].memory_bitmap, xpos[4], ypos[buff_temp], 0, 0, 80, 60);
		if( y == 7)
			box[x][y].T = 'Q';
		if( y == 0)
			box[x][y].T = 'q';	
	}

	if(buff_temp != -1 && (x == 4))//--------KINGS--------------
	{
		masked_blit(buffer, box[x][y].memory_bitmap, xpos[3], ypos[buff_temp], 0, 0, 80, 60);	
		if( y == 7)
			box[x][y].T = 'K';
		if( y == 0)
			box[x][y].T = 'k';
	}

	
	blit(box[x][y].memory_bitmap, screen, 0, 0, xpos[x], ypos[y] , 80, 60);
	unscare_mouse();
	}
}
}

//-------------------PICK PIECE------------------------------

void pick_piece()
{


do{

//scrmspxl = getpixel(screen , mouse_x, mouse_y);//color of mouse point

if (mouse_b & 1) 
{


//----------------------------------select box------------------
	for(int y = 0; y < 8; y++)
	{
		for(int x = 0; x < 8; x++)
		{
		if(mouse_x >= xpos[x]) xbox = x;  //pos[x];
		if(mouse_y >= ypos[y]) ybox = y;  //pos[y];			
		}
	}
//--------------------------------end select box-----------------
//--------------------------------draw box-----------------------

	do{
	scare_mouse();
	
	
		

	rect(screen, xpos[xbox] + 1, ypos[ybox] +1, xpos[xbox]+78, ypos[ybox]+59, boxcolor);
	rect(screen, xpos[xbox] + 2, ypos[ybox] +2, xpos[xbox]+77, ypos[ybox]+58, boxcolor);

	rect(screen, xpos[xbox] + 3, ypos[ybox] +3, xpos[xbox]+75, ypos[ybox]+56, boxcolor);

	unscare_mouse();
	//for(int delay =0; delay < 1000; ++delay)

	boxcolor++;
	if(boxcolor > 254) boxcolor = BLUE;


	}while(mouse_b & 1);


	for(int y = 0; y < 8; y++) // -------get second box number
	{
		for(int x = 0; x < 8; x++)
		{
		if(mouse_x >= xpos[x]) movx = x;
		if(mouse_y >= ypos[y]) movy = y;			
		}
	}
	scare_mouse();

	blit(box[xbox][ybox].memory_bitmap, ptemp[0], 0, 0, 0, 0, 80, 60);
	floodfill(ptemp[0], 4, 4, MSKED);


	clear_to_color(box[xbox][ybox].memory_bitmap, getpixel(screen, xpos[xbox]+4, ypos[ybox]+4));
	clear_to_color(box[movx][movy].memory_bitmap, getpixel(screen, xpos[movx]+4, ypos[movy]+4));

	masked_blit(ptemp[0], box[movx][movy].memory_bitmap, 0, 0, 0, 0, 80, 60);
	blit(box[xbox][ybox].memory_bitmap, screen, 0, 0, xpos[xbox], ypos[ybox] , 80, 60);	
	blit(box[movx][movy].memory_bitmap, screen, 0, 0, xpos[movx], ypos[movy] , 80, 60);
	unscare_mouse();

	box[movx][movy].T = box[xbox][ybox].T;
	box[xbox][ybox].T = 'E';



blit(box[movx][movy].memory_bitmap, ptemp[0], 0, 0, 0, 0, 80, 60); // ---get piece bmp-------
	floodfill(ptemp[0], 4, 4, MSKED);

	if(movy == 7)
	{
		masked_blit(buffer, ptemp[1], 0, 0, 0, 0, 80, 60);
		floodfill(ptemp[1], 4, 4, MSKED);

		if(box[movx][movy].T == 'p')
		{


		masked_blit(buffer, box[movx][movy].memory_bitmap, xpos[4], ypos[0], 0, 0, 80, 60);
		scare_mouse();	
		blit(box[movx][movy].memory_bitmap, screen, 0, 0, xpos[movx], ypos[movy], 80, 60); 
		unscare_mouse();
		}
	}
	if(movy == 0)
	{
		masked_blit(buffer, ptemp[1], 0, 60, 0, 0, 80, 60);
		floodfill(ptemp[1], 4, 4, MSKED);

		if(box[movx][movy].T == 'P')
		{
		masked_blit(buffer, box[movx][movy].memory_bitmap, xpos[4], ypos[1], 0, 0, 80, 60);
		scare_mouse();
		blit(box[movx][movy].memory_bitmap, screen, 0, 0, xpos[movx], ypos[movy], 80, 60); 
		unscare_mouse();
		}
	}


	

	
  
}





}while (! keypressed());

}

