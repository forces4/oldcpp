#include "point.h"
#include <iostream.h>
#include <math.h>


void init()

void main()
{

	int numpoints = 50;

	point whirl[numpoints];



	int install_timer();
	int allegro_init();

	install_keyboard(); 
 	set_gfx_mode(GFX_AUTODETECT, 640, 480, 1024, 1024);
  	 set_pallete(desktop_pallete);

	extern volatile char key[128]; // keyboard flags--if (key[KEY_SPACE])


	floodfill(screen, 100, 100, 3);




}
