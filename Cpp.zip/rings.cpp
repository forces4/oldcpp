#include <iostream.h>
#include <rand.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>

#include "allegro.h"
#include "3dpoint.h"



void main()
{

allegro_init();
install_mouse();
install_timer();


install_keyboard(); 
 set_gfx_mode(GFX_AUTODETECT, 640, 480, 1024, 1024);
   set_pallete(desktop_pallete);

extern volatile char key[128]; // keyboard flags--if (key[KEY_SPACE])



//-----------------------------------------------------------------

point first[200][102];

int shot = 0;
int shotcount[102];
for(int r =0;r<101;++r){shotcount[r] =0;}



show_mouse(screen);


do{

if (mouse_b & 2)
{
	scare_mouse();
	 floodfill(screen, mouse_x, mouse_y, 15);
	unscare_mouse();
}


if (mouse_b & 1) 
{	
	shotcount[shot] = 100;

	first[101][shot].set_x(mouse_x);
	first[101][shot].set_y(mouse_y);
	++shot;
	if(shot >99) shot =0;
}

	for(int i = 0; i <= 99; ++i)
	{
	if(shotcount[i] >0)
	{
		first[shotcount[i]][i].set_z(int(shotcount[i]/2));



                first[shotcount[i]][i].set_x(  first[shotcount[i]+1][i].gx() - ((first[shotcount[i]+1][i].gx() - 320)/90)   );
                first[shotcount[i]][i].set_y(  first[shotcount[i]+1][i].gy() - ((first[shotcount[i]+1][i].gy() - 240)/90)   );
				


		if(shotcount[i] >= 5)
		{
			scare_mouse();
			first[shotcount[i]][i].zplot();
			unscare_mouse();
		}

		if(shotcount[i] < 96)
		{
			scare_mouse();
			first[shotcount[i]+5][i].zunplot();
			unscare_mouse();
		}

		if(shotcount[i] >0) --shotcount[i];
		if(shotcount[i] ==0) circle(screen, first[1][i].gx()
		, first[1][i].gy(), 100, 23);
				
		
	for(float k = 0; k< 99; k += .01){}//-----------delay

	}//------end if
	
	}//------end for




}while (! keypressed());	


}//--------------------------------------end main

