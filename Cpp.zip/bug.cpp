#include <conio.h>
#include <iostream.h>
#include <stdio.h>
#include <stdlib.h>
#include <fstream.h>
#include <string.h>




const MAXSTRING =10000;
typedef char string[MAXSTRING];

struct big1
{
string record[MAXSTRING] = '\0';
string rec_next[MAXSTRING] = '\0';
string trash[MAXSTRING] = '\0';
string description[MAXSTRING] = '\0';

string name = '\0';
string price = '\0';
string number = '\0';
string kind = '\0';
string sug_ret = '\0';
string description = '\0';
char *cursor;
char *curs2;
};


int num_record = 1;
int maxfields;

ifstream inFile("original.txt");
ofstream ouFile("after.txt");




big1 field[100];


void main(void)
{

//**************************START ROUTINE*********************************

inFile.getline(field[0].record, MAXSTRING, '\n');

while(inFile.good())
{

	
	inFile.getline(field[1].record, MAXSTRING, '\n');

for(int nxt = 0; nxt < 2; nxt++)
{
	field[nxt].cursor = field[nxt].record;

 	field[nxt].curs2 = field[nxt].name;
	while( field[nxt].*cursor != '~' )
	{
		field[nxt].*curs2 = field[nxt].*cursor;
		field[nxt].cursor++;
		field[nxt].curs2++;
	}
	field[nxt].cursor++;

	

	 field[nxt].curs2 = field[nxt].price;
	while( field[nxt].*cursor != '~' )
	{
		field[nxt].*curs2 = field[nxt].*cursor;
		field[nxt].cursor++;
		field[nxt].curs2++;
	}
	field[nxt].cursor++;

	 field[nxt].curs2 = field[nxt].number;
	while( field[nxt].*cursor != '~' )
	{
		field[nxt].*curs2 = field[nxt].*cursor;
		field[nxt].cursor++;
		field[nxt].curs2++;
	}field[nxt].cursor++;
	field[nxt].cursor++;

	 field[nxt].curs2 = field[nxt].kind;
	while( field[nxt].*cursor != '~' )
	{
		field[nxt].*curs2 = field[nxt].*cursor;
		field[nxt].cursor++;
		field[nxt].curs2++;
	}field[nxt].cursor++;
	field[nxt].cursor++;


	 field[nxt].curs2 = field[nxt].sug_ret;
	while( field[nxt].*cursor != '~' )
	{
		field[nxt].*curs2 = field[nxt].*cursor;
		field[nxt].cursor++;
		field[nxt].curs2++;
	}field[nxt].cursor++;

	 field[nxt].curs2 = field[nxt].description;
	while( field[nxt].*cursor != '\n' )
	{
		field[nxt].*curs2 = field[nxt].*cursor;
		field[nxt].cursor++;
		field[nxt].curs2++;
	}
	

	
}//----------------------end for
	 
}//----------end while
}
