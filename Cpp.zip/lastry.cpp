#include <conio.h>
#include <iostream.h>
#include <stdio.h>
#include <stdlib.h>
#include <fstream.h>
#include <string.h>
#include <istream.h>

const int MAXSTRING = 1000;
typedef char string[MAXSTRING];
char temporary;


void heading();
void combine();
void init(int n);
int isame(int num_rcd);



class big1
{
public:

big1();

string record;

string name;
string price ;
string number;
string url;

string kind ;
string justincase;
string sug_ret ;
string description ;
char *cursor;
char *curs2;
char *hdpt;
int kurs;
int kurs2;
private:


};

big1::big1()
{
	hdpt = record;

}

int num_rcd = 1;
int num_rec =1;
int maxfields;
int recnum = 0;
int recref = 0;
int rectop =1;
ifstream inFile("original.txt");
ofstream outFile("after.txt");




big1 field[610];


void main(void)
{

heading();




while(inFile.good() && ! inFile.eof() && recnum < 600)
{

	inFile.getline(field[recnum].record, MAXSTRING, '\n');
	
	recnum++;
}
num_rec = recnum;

recnum = 1;


	



for(int nxt = 0; nxt < num_rec; nxt++)
{
cout << nxt << " of " << num_rec << endl;
//cin >> temporary;

	field[nxt].kurs = 0;
	field[nxt].kurs2 = 0;


	//-----------------name------------------
	
	
	while( field[nxt].record[field[nxt].kurs] != '~')
	{
		field[nxt].name[field[nxt].kurs2] = field[nxt].record[field[nxt].kurs];
		

		field[nxt].kurs++;
		field[nxt].kurs2++;
	}

	field[nxt].kurs++;
	field[nxt].name[field[nxt].kurs2] = '\0';
	field[nxt].kurs2 = 0;

//cout << field[nxt].name << endl;



	while( field[nxt].record[field[nxt].kurs] != '~')
	{
		field[nxt].price[field[nxt].kurs2] = field[nxt].record[field[nxt].kurs];

		field[nxt].kurs++;
		field[nxt].kurs2++;
	}
	field[nxt].kurs++;
	field[nxt].price[field[nxt].kurs2] = '\0';
	field[nxt].kurs2 = 0;
cout << field[nxt].price << endl;


	while( field[nxt].record[field[nxt].kurs] != '~')
	{
		field[nxt].number[field[nxt].kurs2] = field[nxt].record[field[nxt].kurs];

		field[nxt].kurs++;
		field[nxt].kurs2++;
	}
	
	field[nxt].kurs++;
	field[nxt].number[field[nxt].kurs2] = '\0';
	field[nxt].kurs2 = 0;
cout << field[nxt].number << endl;


//-----------------------------------url

	while( field[nxt].record[field[nxt].kurs] != '~')
	{
		field[nxt].url[field[nxt].kurs2] = field[nxt].record[field[nxt].kurs];

		field[nxt].kurs++;
		field[nxt].kurs2++;
	}
	
	field[nxt].kurs++;
	field[nxt].url[field[nxt].kurs2] = '\0';
	field[nxt].kurs2 = 0;
cout << field[nxt].url << endl;



//--------------------------------------end url



	while( field[nxt].record[field[nxt].kurs] != '~')
	{
		field[nxt].kind[field[nxt].kurs2] = field[nxt].record[field[nxt].kurs];

		field[nxt].kurs++;
		field[nxt].kurs2++;
	}
	
	field[nxt].kurs++;
	field[nxt].kind[field[nxt].kurs2] = '\0';
	field[nxt].kurs2 = 0;
cout << field[nxt].kind << endl;



//-----------------------------------justincase

	while( field[nxt].record[field[nxt].kurs] != '~')
	{
		field[nxt].justincase[field[nxt].kurs2] = field[nxt].record[field[nxt].kurs];

		field[nxt].kurs++;
		field[nxt].kurs2++;
	}
	
	field[nxt].kurs++;
	field[nxt].justincase[field[nxt].kurs2] = '\0';
	field[nxt].kurs2 = 0;
cout << field[nxt].justincase << endl;



//--------------------------------------end justincase



	while( field[nxt].record[field[nxt].kurs] != '~')
	{
		field[nxt].sug_ret[field[nxt].kurs2] = field[nxt].record[field[nxt].kurs];

		field[nxt].kurs++;
		field[nxt].kurs2++;
	}
	field[nxt].kurs++;
	field[nxt].sug_ret[field[nxt].kurs2] = '\0';
	field[nxt].kurs2 = 0;
//cout << field[nxt].sug_ret << endl;




	while( field[nxt].record[field[nxt].kurs] != '\0')
	{
		field[nxt].description[field[nxt].kurs2] = field[nxt].record[field[nxt].kurs];

		field[nxt].kurs++;
		field[nxt].kurs2++;
	}
	field[nxt].kurs = 0;
	field[nxt].description[field[nxt].kurs2] = '\0';
	field[nxt].kurs2 = 0;



//cout <<  field[nxt].description << endl ;
//cin >> temporary;



}//------end for	




cout << endl << "before combine" << endl;
combine();

cout << maxfields;



}//-------------------------------END MAIN------------------






void heading()      //----------------------heading------------
{


	string tary;

	
	if(inFile.good() )
	{
        	for(int i=0; i < 3; i++) 
        	{
        		 inFile.getline(tary, MAXSTRING, '\n');
			cout << tary << '\n';
			outFile << tary << '\n';
		}

	}



}//-------------------------------------------END VOID HEADING.----------------------------



//-*************************COMBINE***********************************


void combine()
{
for(recnum = 1; recnum < num_rec; recnum++)
{
cout << field[recref].name << endl;

outFile << field[recref].name << '~' << field[recref].price << "~" << field[recref].number
<< "~<br><center><table border=0 cellspacing=0 cellpadding=0><tr><td><img src=\""
<< field[recref].url << "�></td></tr></table>"
<< "</center><br><br><center><font size=�+2�>" << field[recref].name << "</font></center><br><br><font size=�+1�>"
<< field[recref].description << "</font><br>Suggested Retail: " << field[recref].sug_ret 
<< "<br><table border=�1� cellspacing=�0� cellpadding=�0�><tr><td><font size=�+3�>"
<< "Color/Size</font></td><td><font size=�+3�>Quanitiy in Stock";

// ------------------is single or compressed?

if (!(isame(recnum) ))
{

	outFile << "</font></td></tr><tr><td></td><td></td></tr><td></td>"
	<< "<td></td></tr><td></td><td></td></tr></table>~" << field[recref].justincase
	<< "~" << field[recref].kind
	<< "~" << field[recref].url << '\n';

	recref = recnum;


} //------------------end if--------
else
{


	outFile << "</font></td></tr><tr><td>" << field[recref].kind << "</td><td></td></tr><td>"
	<< field[recnum].kind;
	
	

	recnum++;
	 

	while(isame(recnum))
	{
	outFile << "</td><td></td></tr><td>" << field[recnum].kind;

	recnum++;

	 


	}//---------------end while

	if(( recnum - recref) > maxfields)
		maxfields = ( recnum - recref);

	rectop = (recnum -1);


	outFile << "</td><td></td></tr></table>~" <<field[recref].justincase 
		<< "~" << field[recref].kind << "~" << field[recref].url;

	for(int i = recref; i <= rectop; i++)
	{
		outFile << '~' << field[i].kind;
	}
	outFile << '\n';

	recref = recnum;



}//-------------------END ELSE------

rectop++;


}//-----end for
}//---------------------------------------------End Combine






int isame(int num_rcd)
{
if(( (strcmp(field[recref].name, field[recnum].name) ==0) && (strcmp(field[recref].price, field[recnum].price) ==0)  ))
	return 1;
else return 0;

}//----------------end isame-------------------

