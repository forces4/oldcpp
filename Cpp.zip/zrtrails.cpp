#include "physics.h"
#include <iostream.h>
#include <math.h>
#include <rand.h>

#include <stdlib.h>
#include <stdio.h>


int speedlimit=22;

int Num_dots=20;
int center_force=-90000;
int partical_force=0;
int trails =50;
int dlaymax=90000;
float xgrav =0;
float ygrav =0;
float zgrav =0;



const int RED2 = 15;
const int RED = 224;
const int BLUE = 110;
const int GREEN = 16; 
const int BLACK = 1;
const int WHITE = 25;
const int GREY = 3;
const int MSKED = 0;

int x_dir;
int y_dir;
int z_dir;

int xmid=1024/2;
int ymid=768/2;
int zmid=1000/2;

float get_xforce(float x1, float y1, float z1);
float get_yforce(float x1, float y1, float z1);
float get_zforce(float x1, float y1, float z1);


void main()
{

//--------------------------Allegro stuff------------	
	install_timer();
	allegro_init();
	install_keyboard(); 
	install_mouse();
 	set_gfx_mode(GFX_AUTODETECT, 1024, 768, 1024, 768);
  	set_pallete(desktop_pallete);
	extern volatile char key[128]; // keyboard flags--if (key[KEY_SPACE])
//-----------------------end Allegro--------------------

floodfill(screen, 100, 100, BLACK);

int trailswitch=5;
point first[Num_dots];
point second[Num_dots][trails];



for(int i=0;i<Num_dots;i++)
{
first[i].set_x(random() % 1024);
first[i].set_y(random() % 728);
first[i].set_z(random() % 1000);

  /*
first[i].set_x(random() % 500 +500);
first[i].set_y(random() % 500 +350);
first[i].set_z(random() % 100) ;

 */
first[i].set_xvel(random() %10 -5);
first[i].set_yvel(random() %10 -5);
first[i].set_zvel(random() %10 -5);

first[i].set_yacl(0);
first[i].set_xacl(0);
first[i].set_zacl(0);
}
floodfill(screen, 100, 100, BLACK);
//circle(screen, 1024/2, 768/2, 500/50, 234);

//-------------------------------------------------------START MAIN LOOP-----------------
while(!key[KEY_ESC])
{
//if(random() % 200 >=187)center_force =-center_force;

circle(screen, xmid, ymid, zmid/50, 15);
triangle(screen, xmid, ymid, xmid+zmid/50, ymid-zmid/50, 
xmid+zmid/50, ymid+zmid/50, 234);


triangle(screen, xmid, ymid, xmid+zmid/50, ymid-zmid/50, 
xmid+zmid/50, ymid+zmid/50, 234);

for(int dlay=0;dlay<dlaymax;dlay++)
{
//kjhujh
}



 xmid=mouse_x;
 ymid=mouse_y;

if(mouse_b & 1 ) zmid+=100;

if(mouse_b & 2 ) zmid-=100;

	circle(screen, xmid, ymid, zmid/50, 234);

	triangle(screen, xmid, ymid, xmid+zmid/50, ymid-zmid/50, 
xmid+zmid/50, ymid+zmid/50, 234);

//--------------------------------------------Start Trails loop---------------------------
for(int tr =0;tr <trails;tr++)
{

	for(int i=0;i<Num_dots;i++)
	{

//void circle(BITMAP *bmp, int x, int y, int radius, int color);
//Draws a circle with the specified centre and radius.

	circle(screen, xmid, ymid, zmid/50, 234);
triangle(screen, xmid, ymid, xmid+zmid/50, ymid-zmid/50, 
xmid+zmid/50, ymid+zmid/50, 234);

//Draws a filled triangle between the three points. 


	second[i][tr].set_x(first[i].gx());
	second[i][tr].set_y(first[i].gy());
	second[i][tr].set_z(first[i].gz());
	//-----------------------------------Now can change first with ability to unplot old.------



	first[i].move_x(first[i].gxvel());
	first[i].move_y(first[i].gyvel());
	first[i].move_z(first[i].gzvel());

	//----------Below is for center force------------------------
	if(center_force !=0)
	{

	first[i].set_yacl(ygrav + get_yforce(first[i].gx(), first[i].gy(),first[i].gz()));
	first[i].set_xacl(xgrav + get_xforce(first[i].gx(), first[i].gy(),first[i].gz()));
	first[i].set_zacl(zgrav + get_zforce(first[i].gx(), first[i].gy(),first[i].gz()));
	}
circle(screen, xmid, ymid, zmid/50, 15);
triangle(screen, xmid, ymid, xmid+zmid/50, ymid-zmid/50, 
xmid+zmid/50, ymid+zmid/50, RED);
xmid=mouse_x;
 ymid=mouse_y;

	circle(screen, xmid, ymid, zmid/50, 234);
triangle(screen, xmid, ymid, xmid+zmid/50, ymid-zmid/50, 
xmid+zmid/50, ymid+zmid/50, RED);

	/*
	first[1].set_yacl(0);
	first[1].set_xacl(0);
	first[1].set_yvel(0);
	first[1].set_xvel(0);
	*/
	

	if ( abs(int(first[i].gx()) - xmid) < 10 && abs( int( first[i].gy() ) -ymid)< 10 && abs( int( first[i].gz() ) -zmid)< 10)
	{
	first[i].set_x(random() % 1024);
	first[i].set_y(random() % 760);
	first[i].set_z(random() % 1000);
	first[i].set_z(zmid);
	}
	


	//first[i].set_z(zmid);


	//first[i].colr = random () % 50;


	}//------------------------------------end Num_dots for-------------------------------


	//-------------------------------------Below is for partical charge-------------



	for( int i=0 ;i<Num_dots;i++)
	{

if(partical_force !=0)
{
	float pxtotalforce=0;
	float pytotalforce=0;
	float pztotalforce=0;


	float pdistance=0;
	float tforce=0;
	float force=0;


//below tests each partical against every other partical to calculate force.---------------
		for (int j=0;j<Num_dots;j++)
		{
			if(j!=i)
			{
	
			pdistance=sqrt( (first[i].gx()-first[j].gx())*(first[i].gx()-first[j].gx()) 
			+ (first[i].gy()-first[j].gy())*(first[i].gy()-first[j].gy()) 
			+ (first[i].gz()-first[j].gz())*(first[i].gz()-first[j].gz()) );

			tforce=abs(int(first[i].gx()-first[j].gx())) + abs(int(first[i].gy()-first[j].gy()))
			+ abs(int(first[i].gz()-first[j].gz()));

			force=( partical_force/(pdistance * pdistance) );

			pxtotalforce=pxtotalforce+ ( ((first[i].gx()-first[j].gx())/tforce) * force );
			pytotalforce=pytotalforce+ ( ((first[i].gy()-first[j].gy())/tforce) * force );
			pztotalforce=pztotalforce+ ( ((first[i].gz()-first[j].gz())/tforce) * force );

			}

		}


	first[i].set_yacl( first[i].gyacl() + pytotalforce);
	first[i].set_xacl( first[i].gxacl() + pxtotalforce);
	first[i].set_zacl( first[i].gzacl() + pztotalforce);
	


	//if(distance < 30)return( ((y1-ymid)/distance) * -force );
	//if(distance >= 30)return( ((y1-ymid)/distance) * force );





	pxtotalforce=0;
	pytotalforce=0;
	pztotalforce=0;


	pdistance=0;
	tforce=0;
	force=0;

	}//__________end 0 partical force test__________________

	first[i].set_xvel(first[i].gxvel() + first[i].gxacl());
	first[i].set_yvel(first[i].gyvel() + first[i].gyacl());
	first[i].set_zvel(first[i].gzvel() + first[i].gzacl());
	


	//--------------------------------line below bestows angular velocity filter for whirlpool effect
	//if((ymid - first[i].gy())/(first[i].gx()-xmid) <= (ymid - second[i][0].gy())/(second[i][0].gx()-xmid) )
	first[i].zplot();


	//---------------------------------------------veleocity limits---------------------------------------

	if(first[i].gxvel()>=speedlimit || first[i].gxvel()<= -speedlimit)
	{
	first[i].set_xacl(-.9 * first[i].gxacl());
	first[i].set_xvel(float(first[i].gxvel()/abs(int(first[i].gxvel())) *3));
	}
	if(first[i].gyvel()>=speedlimit || first[i].gyvel()<= -speedlimit)
	{
	first[i].set_yacl(-.8 * first[i].gyacl());
	first[i].set_yvel(float(first[i].gyvel()/abs(int(first[i].gyvel())) *3));
	}
	if(first[i].gzvel()>=speedlimit || first[i].gzvel()<= -speedlimit)
	{
	first[i].set_zacl(-.5 * first[i].gzacl());
	first[i].set_zvel(float(first[i].gzvel()/abs(int(first[i].gzvel())) *3));
	}
	//---------------------------------------------end velocity limits------------------
	
	
	} //------------------------------------------end partical charge for------------------
	
	
	
	for(int dlay =0; dlay <dlay; dlay++){}




	if(trailswitch ==1 && tr==trails -1)for(int i=0;i<Num_dots;i++)second[i][0].zunplot();
	if(trailswitch ==1 && tr < trails-1)for(int i=0;i<Num_dots;i++)second[i][tr+1].zunplot();

}//-------------------------------------------end trails for______________________________________


trailswitch=1;

for(int i=0;i<Num_dots;i++)second[i][0].zunplot();


}// ----------end while

}//--------------end main-----------------------------------------------------------







float get_xforce(float x1, float y1, float z1)
{
float distance;
float force;
float tforce;

distance=sqrt( (x1-xmid)*(x1-xmid) + (y1-ymid)*(y1-ymid) + (z1-zmid)*(z1-zmid) );
tforce=abs(int(x1-xmid)) + abs(int(y1-ymid)) + abs(int(z1-zmid));
force=( center_force/(distance * distance) );

//if(distance < 30)return( ((x1-xmid)/distance) * -force );
//if(distance >= 30)return( ((x1-xmid)/distance) * force );
return( ((x1-xmid)/tforce) * force );
}


float get_yforce(float x1, float y1, float z1)
{
float distance;
float force;
float tforce;

distance=sqrt( (x1-xmid)*(x1-xmid) + (y1-ymid)*(y1-ymid)  + (z1-zmid)*(z1-zmid) );
tforce=abs(int(x1-xmid)) + abs(int(y1-ymid)) + abs(int(z1-zmid));
force=(center_force/(distance * distance));


//if(distance <30)return( ((y1-ymid)/distance) * -force );
//if(distance >= 30)return( ((y1-ymid)/distance) * force );
return( ((y1-ymid)/tforce) * force );
}

float get_zforce(float x1, float y1, float z1)
{
float distance;
float force;
float tforce;

distance=sqrt( (x1-xmid)*(x1-xmid) + (y1-ymid)*(y1-ymid)  + (z1-zmid)*(z1-zmid) );
force=(center_force/(distance * distance));
tforce=abs(int(x1-xmid)) + abs(int(y1-ymid)) + abs(int(z1-zmid));

//if(distance <30)return( ((z1-zmid)/distance) * -force );
//if(distance >= 30)return( ((z1-zmid)/distance) * force );

return( ((z1-zmid)/tforce) * force );
}

