#include "allegro.h"
#include <stdlib.h>
#include <stdio.h>
#include <iostream.h>
#include <math.h>
#include <rand.h>

const int RED = 224;
const int BLUE = 11;
const int GREEN = 16; 
const int BLACK = 1;
const int WHITE = 255;
const int GREY = 3;
const int MSKED = 0;
char pict[200];

int clr= 1;
BITMAP *mows;

//PALLETE my_pallete;

const int boardsize=100;
const int boxsize=480/boardsize+1;


PALLETE my_pallete;

int numtouching(int x, int y);
void init();
void select();

struct cell {

	
	int type;
}life[boardsize][boardsize];


cell lifenew[boardsize][boardsize];



int main(int argc, char *argv[])//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
{
replace_filename(pict, argv[0], "pen.bmp", sizeof(pict));


	int install_timer();
	int allegro_init();
	install_mouse();
	install_keyboard(); 
 	set_gfx_mode(GFX_AUTODETECT, 640, 480, 1024, 1024);
  	 set_pallete(desktop_pallete);

	extern volatile char key[128]; // keyboard flags--if (key[KEY_SPACE])

	floodfill(screen, 100, 100, 25);
//rectfill(screen, 100, 100, 150, 150, RED);

mows = create_bitmap(60, 60);
mows = load_bitmap(pict, my_pallete);//--------load picture--------------

int temp;

init();	
set_mouse_sprite(mows);

show_mouse(screen);




while(!(key[KEY_SPACE]))
{

//floodfill(screen, 100, 100, 25);
//clr=25;
clr+=clr;
if(clr>14)clr=1;

for(int y=0;y<boardsize-1;y++)
{
	for (int x=0;x<boardsize-1;x++)
	{
	
	if(numtouching(x,y) ==2) lifenew[x][y].type = life[x][y].type;
	if(numtouching(x,y) <2)  lifenew[x][y].type =0;
	if(numtouching(x,y) ==3) lifenew[x][y].type =1;
	if(numtouching(x,y) >3)  lifenew[x][y].type =0;
	}
}

for(int y=0;y<boardsize-1;y++)
{
	for(int x=0;x<boardsize-1;x++)
	{

//start select-----------------------------------------
	if(mouse_b & 2)
	{
scare_mouse();
unscare_mouse();

	while(! key[KEY_ESC])
{
scare_mouse();
unscare_mouse();

if (mouse_b & 1 && mouse_x>0 && mouse_y>0)
{
lifenew[mouse_x/boxsize][mouse_y/boxsize].type=1;
	
scare_mouse();
		rectfill(screen, mouse_x/boxsize * boxsize , mouse_y/boxsize * boxsize,
		 mouse_x/boxsize * boxsize + boxsize-1, mouse_y/boxsize*boxsize + boxsize-1, clr );
		unscare_mouse();
	
		
	life[mouse_x/boxsize][mouse_y/boxsize].type=
	lifenew[mouse_x/boxsize][mouse_y/boxsize].type;
}//end if

}//end while



	}//end select------------------------------





	if (mouse_b & 1)lifenew[mouse_x/boxsize][mouse_y/boxsize].type=1;
	

	
		if(lifenew[x][y].type != life[x][y].type)
		{ 
			if(lifenew[x][y].type==1)
			{
		scare_mouse();
		rectfill(screen, x * boxsize , y * boxsize,
		 x * boxsize + boxsize-1, y*boxsize + boxsize-1, clr );
		unscare_mouse();
			}
			else
			{
			scare_mouse();	
			rectfill(screen, x * boxsize , y * boxsize,
		 x * boxsize + boxsize-1, y*boxsize + boxsize-1,25);
			unscare_mouse();
			}
		
		//putpixel(screen, x, y, clr * lifenew[x][y].type);

		}
	life[x][y].type=lifenew[x][y].type;
	
	}
}



}//end while

}//--------------end main------------------------------------------


int numtouching(int x,int y)
{
int num=0;

if(x>0 && y>0)num = num + life[x-1][y-1].type;
if(y>0)num = num + life[x][y-1].type;
if(x<boardsize-1 && y>0)num = num + life[x+1][y-1].type;
if(x>0)num = num + life[x-1][y].type;
if(x<boardsize-1)num = num + life[x+1][y].type;
if(x>0 && y<boardsize-1)num = num + life[x-1][y+1].type;
if(y<boardsize-1)num = num + life[x][y+1].type;
if(x<boardsize-1 && y<boardsize-1)num = num + life[x+1][y+1].type; 




return(num);
}

void init()
{

for(int y=0;y<boardsize-1;y++)
{
	for (int x=0;x<boardsize-1;x++)
	{
	life[x][y].type=int(random()% 4)-1; 
	if (life[x][y].type >1)life[x][y].type=0; 

	if(lifenew[x][y].type==1)
			{

		rectfill(screen, x * boxsize , y * boxsize,
		 x * boxsize + boxsize-1, y*boxsize + boxsize-1, clr );
			}
			else
			{	
			rectfill(screen, x * boxsize , y * boxsize,
		 x * boxsize + boxsize-1, y*boxsize + boxsize-1,25);
			}
	
	//putpixel(screen, x, y, clr * life[x][y].type);

	}
}

}//end init

void select()
{

while(! key[KEY_ESC])
{
show_mouse(screen);

if (mouse_b & 1)
{
lifenew[mouse_x/boxsize][mouse_y/boxsize].type=1;
	
scare_mouse();
		rectfill(screen, mouse_x/boxsize * boxsize , mouse_y/boxsize * boxsize,
		 mouse_x/boxsize * boxsize + boxsize-1, mouse_y/boxsize*boxsize + boxsize-1, clr );
		unscare_mouse();
	
		
	life[mouse_x/boxsize][mouse_y/boxsize].type=
	lifenew[mouse_x/boxsize][mouse_y/boxsize].type;
}//end if

}//end while

}//end select

   


