
#include <stdlib.h>
#include <stdio.h>
#include <rand.h>


#include "allegro.h"


int main()
{
   BITMAP *memory_bitmap;
   int x, y;

   allegro_init();
   install_keyboard(); 
   set_gfx_mode(GFX_VGA, 320, 200, 0, 0);
   set_pallete(desktop_pallete);

   /* make a memory bitmap sized 20x20 */
   memory_bitmap = create_bitmap(320, 200);

