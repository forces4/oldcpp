
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <glut.h>



void
display()
{
	int radius =10;
	int slices = 5;
	int stacks =5;
	int a = 1;
	int b = 1;
	int y = 50;


   void glutSolidSphere(GLdouble radius,
                    GLint slices, GLint stacks);

	for ( int x = 50; x < 823; x = x + a)
	{
		glutPositionWindow(x, y);
		y = y + b;

		if(y > 300 || y < 10)
			b = -b;
		if(x > 300 || x < 10)
			a = -a;
  
	}
}







int
main(int argc, char** argv)
{
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowPosition(50, 50);
    glutInitWindowSize(320, 320);
    //                        glutInit(&argc, argv);


	 glutCreateWindow("Area");



	// void glutPositionWindow(int x, int y);

	//       void glutReshapeWindow(int width, int height);

	
glutDisplayFunc(display);
   //glutReshapeFunc(reshape);

 glutMainLoop();
    return 0;
}

