#include <iostream.h>
#include "allegro.h"
#include <string.h>


//----------------Below is framework for board-------
struct square {

	BITMAP *memory_bitmap;
	char T;
}box[8][8];

square dead[4][8];

int xmax=1024;
int ymax=768;


int SQRSIZE=ymax/8;

int stop=0;

const int RED = 224;
const int BLUE = 11;
const int GREEN = 16; 
const int BLACK = 1;
const int WHITE = 255;
const int GREY = 3;
const int MSKED = 0;
int buff_temp = 0;       //-------------color of piece, 0 or 1
int xbox, ybox, scrmspxl;
int xpos[8], ypos[2];
int movx, movy;
int boxcolor = 1;
int boxgone = RED;
PALLETE my_pallete;
char pict[200];

BITMAP *scrbuff;

BITMAP *buffer;
BITMAP *ptemp[3];
BITMAP *mousprite;
BITMAP *stretch;
//-----------------------------------------------------------------




void init();
void make_board();
void draw_board();
void pick_piece();
int islegal();
int isemptypath();




int main(int argc, char *argv[])//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
{
replace_filename(pict, argv[0], "chess3.bmp", sizeof(pict));



init();
make_board();	
draw_board();	
pick_piece();

BITMAP *bmp;     
bmp = create_bitmap(xmax, ymax);
blit(screen, bmp, 0,0,0,0,xmax,ymax);
save_bitmap("chessgame.bmp", bmp, my_pallete);
destroy_bitmap(bmp);

//----------------------------------------------------------------

	for(int n = 0; n < 8 ; n++)
	{	
		for(int m = 0; m < 8 ;m++)
		{
		destroy_bitmap(box[n][m].memory_bitmap);
		}
	}


destroy_bitmap(scrbuff);

destroy_bitmap(buffer);
destroy_bitmap(stretch);

for(int n = 0; n<=2 ; n++)
	destroy_bitmap(ptemp[n]);

destroy_bitmap(mousprite);

//^^^^^The above clears memory for exit-------------------------

   readkey();
   return 0;

}//-----------------------------------------------------------End main





//-----------------------FUNCTIONS------------------------------

void init()
{
allegro_init();
install_timer();
install_mouse();
install_keyboard(); 

set_gfx_mode(GFX_AUTODETECT, xmax, ymax, 1024, 768);
   set_pallete(desktop_pallete);

extern volatile char key[128]; // -------keyboard flags--if (key[KEY_SPACE])


scrbuff = load_bitmap(pict, my_pallete);//--------load picture--------------
set_pallete (my_pallete);

buffer = create_bitmap(560, 120);

for(int n =0 ; n <=2; n++)
	ptemp[n] = create_bitmap(ymax/8, ymax/8);

mousprite = create_bitmap(ymax/8, ymax/8);
stretch   = create_bitmap(ymax/8, ymax/8);

blit(scrbuff, buffer, 0, 0, 0, 0, 570, 130);
floodfill(buffer, 1, 1, MSKED);
show_mouse(screen);

for(int y = 0; y<8; y++){xpos[y] = y*80; }  // --setup position grid for pic pieces-
ypos[0] = 0;
ypos[1]=60;

}//------end init

//------------------------------------MAKE BOARD-----------------------

void make_board()
{
int col = RED;
int colswtch = 0;

	for(int n = 0; n < 8 ; n++)//			row
	{
	
	for(int m = 0; m < 8; m++)//			columb
	{
		if(colswtch == 0 && m !=0)
		{
			colswtch = 1;
			col = BLACK;
		}
		
		else if(colswtch == 1 && m !=0)
		{
			colswtch = 0;
			col = RED;
		}
	
		box[n][m].memory_bitmap = create_bitmap(ymax/8, ymax/8);
		clear_to_color(box[n][m].memory_bitmap, col);
		
	}//end for m loop

	for(int d=0; d<4;d++)
	{

	dead[d][n].T='E';	
	dead[d][n].memory_bitmap = create_bitmap(ymax/8, ymax/8);
	clear_to_color(dead[d][n].memory_bitmap, MSKED);
	

	}//end for d loop

	
	}//end for n loop


}// end make_board()

//-----------------------------------------

void draw_board()
{
for(int y = 0; y < 8; y++)
{
	if((y > 1) || (y<6))
		

	for(int x = 0; x < 8; x++)
	{
		if((y > 1) || (y<6))
			box[x][y].T = 'E';

	scare_mouse();
	
	//----------------------pawns------------

	if(y == 1)
	{

		stretch_blit(buffer, stretch, xpos[0], ypos[0], 80, 60, 0, 0, ymax/8, ymax/8);
		masked_blit(stretch, box[x][y].memory_bitmap, 0, 0, 0, 0, ymax/8, ymax/8);
		box[x][y].T = 'p';
	//>>>>>>BLACK<<<<<<<<
	}
	if(y == 6)
	{
		stretch_blit(buffer, stretch, xpos[0], ypos[1], 80, 60, 0, 0, ymax/8, ymax/8);
		masked_blit(stretch, box[x][y].memory_bitmap, 0, 0, 0, 0, ymax/8, ymax/8);
		box[x][y].T = 'P';
	//>>>>>>WHITE<<<<<<<<<
	}

	//------------------- player pieces-----------------------
	if(y==0)buff_temp = 0;
	if(y==7)buff_temp = 1;
	if(y != 0 && y != 7)buff_temp = -1;
	
	if(buff_temp != -1 && (x == 0 || x == 7))//--------ROOKS--------------
	{
	
		stretch_blit(buffer, stretch, xpos[1], ypos[buff_temp], 80, 60, 0, 0, ymax/8, ymax/8);
		masked_blit(stretch, box[x][y].memory_bitmap, 0, 0, 0, 0, ymax/8, ymax/8);
		if( y == 7)
			box[x][y].T = 'R';
		if( y == 0)
			box[x][y].T = 'r';
			
	}	
	
	if(buff_temp != -1 && (x == 1 || x == 6))//--------KNIGHTS--------------
	{
		stretch_blit(buffer, stretch, xpos[2], ypos[buff_temp], 80, 60, 0, 0, ymax/8, ymax/8);
		masked_blit(stretch, box[x][y].memory_bitmap, 0, 0, 0, 0, ymax/8, ymax/8);
		
		if( y == 7)
			box[x][y].T = 'N';
		if( y == 0)
			box[x][y].T = 'n';	
	}

	if(buff_temp != -1 && (x == 2 || x == 5))//--------BISHOPS--------------
	{
		stretch_blit(buffer, stretch, xpos[5], ypos[buff_temp], 80, 60, 0, 0, ymax/8, ymax/8);
		masked_blit(stretch, box[x][y].memory_bitmap, 0, 0, 0, 0, ymax/8, ymax/8);
		if( y == 7)
			box[x][y].T = 'B';
		if( y == 0)
			box[x][y].T = 'b';	
	}

	if(buff_temp != -1 && (x == 3))//--------QUEENS--------------
	{
		stretch_blit(buffer, stretch, xpos[4], ypos[buff_temp], 80, 60, 0, 0, ymax/8, ymax/8);
		masked_blit(stretch, box[x][y].memory_bitmap, 0, 0, 0, 0, ymax/8, ymax/8);
		if( y == 7)
			box[x][y].T = 'Q';
		if( y == 0)
			box[x][y].T = 'q';	
	}

	if(buff_temp != -1 && (x == 4))//--------KINGS--------------
	{
		stretch_blit(buffer, stretch, xpos[3], ypos[buff_temp], 80, 60, 0, 0, ymax/8, ymax/8);
		masked_blit(stretch, box[x][y].memory_bitmap, 0, 0, 0, 0, ymax/8, ymax/8);	
		if( y == 7)
			box[x][y].T = 'K';
		if( y == 0)
			box[x][y].T = 'k';
	}

		

	 blit(box[x][y].memory_bitmap, screen, 0, 0, x*ymax/8, y*ymax/8 , ymax/8, ymax/8);

	unscare_mouse();
	}
}


}

//-------------------PICK PIECE------------------------------

void pick_piece()
{


for(int stop=1;stop<10;stop+=0)
{

//scrmspxl = getpixel(screen , mouse_x, mouse_y);//color of mouse point

if (mouse_b & 1 && mouse_x <=(ymax)) 
{



//----------------------------------select box------------------
	for(int y = 0; y < 8; y++)
	{
		
		if(mouse_x >= y*ymax/8) xbox = y;  //pos[x];
		if(mouse_y >= y*ymax/8 ) ybox = y;  //pos[y];			
		
	}

//--------------------------------end select box-----------------
//--------------------------------draw box-----------------------

	
	scare_mouse();
	

	rect(screen, xbox*ymax/8 + 1 , ybox*ymax/8 +1, (xbox+1)*ymax/8 -2, (ybox+1)*ymax/8 -2, boxcolor);
	rect(screen, xbox*ymax/8 + 2 , ybox*ymax/8 +2, (xbox+1)*ymax/8 -3, (ybox+1)*ymax/8 -3, boxcolor);

	rect(screen, xbox*ymax/8 + 3 , ybox*ymax/8 +3, (xbox+1)*ymax/8 -4, (ybox+1)*ymax/8 -4, boxcolor);

	




blit(box[xbox][ybox].memory_bitmap, mousprite, 0, 0, 0, 0, ymax/8, ymax/8);
floodfill(mousprite, 1, 1, MSKED);


set_mouse_sprite(mousprite);
set_mouse_sprite_focus(ymax/16, ymax/16);

unscare_mouse();


do
{

 boxcolor = BLUE;

}while(mouse_b & 1);


scare_mouse();
boxgone = getpixel(screen, xbox*ymax/8 , ybox*ymax/8 );
	rect(screen, xbox*ymax/8 + 1 , ybox*ymax/8 +1, (xbox+1)*ymax/8 -2, (ybox+1)*ymax/8 -2, boxgone);
	rect(screen, xbox*ymax/8 + 2 , ybox*ymax/8 +2, (xbox+1)*ymax/8 -3, (ybox+1)*ymax/8 -3, boxgone);

	rect(screen, xbox*ymax/8 + 3 , ybox*ymax/8 +3, (xbox+1)*ymax/8 -4, (ybox+1)*ymax/8 -4, boxgone);

unscare_mouse();



	for(int y = 0; y < 8; y++) // -------get second box number
	{
		
		if(mouse_x >= y*ymax/8 ) movx = y;
		if(mouse_y >= y*ymax/8 ) movy = y;			

	}



//------------------------------------------------actually move pieces------------------------

if(mouse_x<ymax && box[xbox][ybox].T != 'E' 
&& !(box[xbox][ybox].T >'Z' && box[movx][movy].T >'Z')
&& !(box[movx][movy].T !='E' && box[xbox][ybox].T <'Z' && box[movx][movy].T <'Z' )
&& islegal()
)

//^^^cant be taken by same type or empty square.------------------------------
{

//^^^movemnet constraints___________________

	scare_mouse();

	blit(box[xbox][ybox].memory_bitmap, ptemp[0], 0, 0, 0, 0, ymax/8, ymax/8);
//^^copy original to temp

	floodfill(ptemp[0], 1, 1, MSKED);




//************************************************************************************working


stop=0;
for(int dlookx=0; (dlookx<4 && stop !=1); dlookx++)
{
	for(int dlooky=0; dlooky<8  && stop!=1; dlooky++)
	{
		if(dead[dlookx][dlooky].T=='E')
		{
		stop=1;
		dead[dlookx][dlooky].T = box[movx][movy].T;
		
		blit(box[movx][movy].memory_bitmap, dead[dlookx][dlooky].memory_bitmap,0,0,0,0,ymax/8,ymax/8);
		floodfill(dead[dlookx][dlooky].memory_bitmap, 1, 1, MSKED);
stretch_blit(dead[dlookx][dlooky].memory_bitmap, screen, 10,0,ymax/8 -20, ymax/8,
 ymax +(dlookx*(xmax-ymax)/4), dlooky*ymax/8,(xmax-ymax)/4,ymax/8);
		}

	}//end dlooky


	
}//end dlookx loop
	


	clear_to_color(box[movx][movy].memory_bitmap, getpixel(screen, movx*ymax/8 +4 , movy*ymax/8 +4));

	clear_to_color(box[xbox][ybox].memory_bitmap, getpixel(screen, xbox*ymax/8 +4 , ybox*ymax/8 +4));
//^^clear source & destination memory

	masked_blit(ptemp[0], box[movx][movy].memory_bitmap, 0, 0, 0, 0, ymax/8, ymax/8);
//^^move from temp to destination memory

	blit(box[xbox][ybox].memory_bitmap, screen, 0, 0, xbox*ymax/8, ybox*ymax/8, ymax/8, ymax/8);
//^^erase original
	
	blit(box[movx][movy].memory_bitmap, screen, 0, 0, movx*ymax/8, movy*ymax/8, ymax/8, ymax/8);
//^^draw moved piece

	unscare_mouse();

	box[movx][movy].T = box[xbox][ybox].T;
	box[xbox][ybox].T = 'E';



	blit(box[movx][movy].memory_bitmap, ptemp[0], 0, 0, 0, 0, ymax/8, ymax/8); 
// ---get piece bmp-------
	floodfill(ptemp[0], 4, 4, MSKED);


//----------------------Below is for Queen from pawn.------
	if(movy == 7)
	{
		masked_blit(buffer, ptemp[1], 0, 0, 0, 0, ymax/8, ymax/8);
		floodfill(ptemp[1], 4, 4, MSKED);

		if(box[movx][movy].T == 'p')
		{

stretch_blit(buffer, stretch, xpos[4], ypos[0], 80, 60, 0, 0, ymax/8, ymax/8);
clear_to_color(box[movx][movy].memory_bitmap, getpixel(screen, movx*ymax/8 +4 , movy*ymax/8 +4));
		masked_blit(stretch, box[movx][movy].memory_bitmap, 0, 0, 0, 0, ymax/8, ymax/8);
		scare_mouse();	
		blit(box[movx][movy].memory_bitmap, screen, 0, 0, movx*ymax/8, 7*ymax/8, ymax/8, ymax/8); 
		unscare_mouse();
	box[movx][movy].T ='q';
		}
	}

	if(movy == 0)
	{
		masked_blit(buffer, ptemp[1], 0, ymax/8, 0, 0, ymax/8, ymax/8);
		floodfill(ptemp[1], 4, 4, MSKED);

		if(box[movx][movy].T == 'P')
		{

stretch_blit(buffer, stretch, xpos[4], ypos[1], 80, 60, 0, 0, ymax/8, ymax/8);
clear_to_color(box[movx][movy].memory_bitmap, getpixel(screen, movx*ymax/8 +4 , movy*ymax/8 +4));
		masked_blit(stretch, box[movx][movy].memory_bitmap, 0, 0, 0, 0, ymax/8, ymax/8);
		scare_mouse();
		blit(box[movx][movy].memory_bitmap, screen, 0, 0, movx*ymax/8, 0, ymax/8, ymax/8); 
	
		unscare_mouse();
	box[movx][movy].T ='Q';
		}
	}

}//end same kind or empty if----------------------


set_mouse_sprite(NULL);
 
}//end if mouse button1--------------------------



if(key[KEY_ESC])stop=20; 

}//end stop for loop   

}



//-------------------------------------begin islegal()__-----------------


int islegal()
{
if( 
//----------------------pawn movemnet---------------------

(box[xbox][ybox].T == 'p' && ( (movy-ybox==2 && ybox==1 && box[movx][2].T=='E' && xbox==movx
&& box[movx][3].T=='E')
||(movy-ybox ==1 && ybox>=1 && box[movx][movy].T=='E' && xbox==movx) 
||((xbox-movx == 1 || xbox-movx ==-1) && box[movx][movy].T !='E' && movy-ybox==1) )

    )//---end Blackpawn paren


||  


(box[xbox][ybox].T == 'P' && ( (ybox-movy<=2 && ybox==6 && box[movx][5].T=='E' && xbox==movx
&& box[movx][4].T=='E')
||(ybox-movy ==1 && ybox<=6 && box[movx][movy].T=='E' && xbox==movx)
||((xbox-movx == 1 || xbox-movx ==-1) && box[movx][movy].T !='E' && ybox-movy==1) )

    )//---end Whitepawn paren


//--------------------end pawn movement_____________________
//_____________________Begin Rook___________________________

||

( (box[xbox][ybox].T == 'r' || box[xbox][ybox].T=='R') && (xbox==movx || ybox==movy)
&& isemptypath()   
	)//-----end rook paren----

//-----------end rook movement--------------
//-----------begin queen-------

||

( (box[xbox][ybox].T == 'q' || box[xbox][ybox].T == 'Q') 
&& (xbox==movx || ybox==movy || xbox-movx == ybox-movy || movx-xbox == ybox-movy ) 
&& isemptypath()

	)//----end queen paren

//-------------end queen movement------------
//-------------begin bishop movement---------

||

( (box[xbox][ybox].T == 'b' || box[xbox][ybox].T == 'B') 
&& (xbox-movx == ybox-movy || movx-xbox == ybox-movy ) 
&& isemptypath()

	)//----end bishop paren

//-------------end bishop movement----------
//-------------begin king-------------------

||

( (box[xbox][ybox].T=='k' || box[xbox][ybox].T == 'K')
&& (xbox-movx <=1 && xbox-movx >=-1 && ybox-movy <=1 && ybox-movy >=-1)

	)//----end king paren


//-------------end king movement----------
//-------------begin knight-------------------

||

( (box[xbox][ybox].T=='n' || box[xbox][ybox].T == 'N')
&& ( (abs(xbox-movx)==2 && abs(ybox-movy)==1)||(abs(xbox-movx)==1 && abs(ybox-movy)==2))

	)//----end knight paren


  )//----end if paren

{
return 1;

}//end move constraints_________________________

return 0;	
}//----------------------------------------------end islegal-------------------------


int isemptypath()
{

int nump = 0;
int xdif = movx-xbox;
int ydif = movy-ybox;
int xs=1;
int ys=1;
int tempy = ybox;


if(xdif < 0) xs = -1;
if(ydif < 0) ys = -1;

if(xdif==0 && ydif !=0)
{

for(int y= ybox + ys; y != movy; y+=ys)
	if(box[xbox][y].T != 'E') nump = nump +1;

}

if(xdif!=0 && ydif ==0)
{

for(int x= xbox + xs; x !=movx; x+=xs)
	if(box[x][ybox].T != 'E') nump = nump +1;

}


if(ydif * ys == xdif * xs)
{

for(int x= xbox + xs; x !=movx; x+=xs)
{
	tempy = tempy + ys; 
	if(box[x][tempy].T != 'E') nump = nump +1;
}

}



if(nump >0)  return 0;
if(nump ==0) return 1;

}//--------------------------------------end isemptypath()-----------------------


