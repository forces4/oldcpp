#include <windows.h>
#include <GL/glut.h>

void main()
{}

