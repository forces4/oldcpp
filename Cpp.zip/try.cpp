#include <conio.h>
#include <iostream.h>
#include <stdio.h>
#include <allegro.h>



main()
{
char c;


cout << "dsaafssdaf";
cin >> c;

}

