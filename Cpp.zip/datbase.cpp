#include <conio.h>
#include <iostream.h>
#include <stdio.h>
#include <stdlib.h>
#include <fstream.h>
#include <string.h>


void combine(ifstream &inFile, ofstream & outFile);

typedef char string[100];
const rlength = 10000;

char record[rlength];
char rec_next[rlength];
char trash[rlength];
char description[rlength];

char name[100];//-----------
char name_next[100];
char price_num[100];
char price_next[100];

char kind[100];
char sug_ret[20];


int num_records;
int maxfields;


void main(void)
{


	ifstream inFile("original.txt");

	ofstream ouFile("after.txt");


while(inFile.good() )
{

     
        for(int i=0; i < 3; i++) //----------------------heading------------
        {
        	inFile.getline(record, rlength, '\n');
		outFile << record << '\n';
	}
	
}

//**************************START ROUTINE*********************************

while(inFile.good())
{

	inFile.getline(name, 100, '~');
	inFile.getline(price_num, 100, ' ');

	 combine(ifstream &inFile, ofstream & outFile);

}


}-------END MAIN---------------------------------------------------------------------


void combine(ifstream &inFile, ofstream & outFile)
{


char tempchar;
string next_kind[100];


/*if(!(strlen(price_num) < 18))//-----------------if not duplicate
	{
		inFile.getline(record, rlength, '\n')
		outFile << name << price_num << record << endl;	//-------JUST PRINT RECORD----
	}
	else*/






	outFile << name << price_num ;//------------START RECORD----------------

	inFile.get(tempchar);
	if(tempchar != ' ')
	{
		inFile.getline(description, rlength, '\n'

	do
	{
		inFile.get(tempchar);

		if (tmpchar == ' ')
			outFile << tmpchar; //-----------keep spaces-------

	}while (tmpchar == ' ')

	inFile.getline(trash, 100, '~');//-----------GET RID OF ALL CAPS NAME
	
	inFile.get(tempchar);//------------GET RID OF  ~
	inFile.get(tempchar);//------------GET RID OF  ~	

	inFile.getline(kind, 100, '~');//-------GET KIND NAME---------

	inFile.get(tempchar);//------------GET RID OF  ~
	inFile.get(tempchar);//------------GET RID OF  ~

	inFile.getline(sug_ret, 20, '~');


	outFile << "~<br><center><table border=0 cellspacing=0 cellpadding=0><tr><td><img src="http://www.art2artonline.com/store/images/7W-1002010.jpg�></td></tr></table></center><br><br><center><font size=�+2�>" << name << "</font></center><br><br><font size=�+1�>";

	//----NOW GET DISCRIPTION AND ADD TO FILE.
	
	

	inFile.get(tmpchar);
	if(tmpchar == '\n')
	{
		outFile << '\n';
		return();
		
	}

	inFile.getline(description, rlength, '\n');
	inFile.get(tempchar);//----------------------SKIP TO NEXT RECORD-----

	ouFile << description << "</font><br>Suggested Retail: " << sug_ret << "<br><table border=�1� cellspacing=�0� cellpadding=�0�><tr><td><font size=�+3�>Color/Size</font></td><td><font size=�+3�>Quanitiy in Stock</font></td></tr><tr><td>" << kind;

	//--------NOW GET NEXT NAMES IN SAME FIELD-------------------
	
	int next_k_count == 0;
	do
	{
	
	inFile.getline(name_next, 100, '~');
	inFile.getline(price_next, 100, ' ');

	inFile.getline(trash, 100, '~');
	inFile.get();//--------------GET RID OF ~
	inFile.get();//--------------GET RID OF ~
	inFile.get(next_kind[next_k_count], 100, '~');


	if((strcmp(name_next, name) == 0) && (strcmp(price_next, price_num) == 0))
	{
		outFile << "</td><td></td></tr><td>" << next_kind[next_k_count];
	}
	else 
	{
	outFile << "    "		
		
	}while( (strcmp(name_next, name) == 0) && (strcmp(price_next, price_num) == 0) );


	//---------NOW THE END OF THE FIELD-------------------------
        outFile << "</td><td></td></tr></table>~~" << kind << "~http://www.art2artonline.com/store/images/7W-1002010.jpg~" << kind;
	
	for(int i = 0; i <= next_k_count; i++)
		outFile << '~' << next_kind[i];


	outFile << '\n';//-------------THE END!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!



}//-------------END OF COMBINE---------------------------------------
		





