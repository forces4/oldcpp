/*
	GL Chess       glchess.cpp  >main program
	Written by James Robert Wolverton
	forces4@yahoo.com
	last updated     >>>>>>>>>>>1-28-05



  1/28 -- finally got selection to work!
  1-29  ---different surroundings for different turn

*/



#include <math.h>
#include <stdlib.h>
#include <GL/glut.h>
#include <conio.h>
#include <iostream.h>
#include <stdio.h>
#include <rand.h>
#include <string.h>


#define BUFSIZE 512

const int clip =500;//overall clipping volume

float twidth=500;//temp widthand height values
float theight=500;

//--------------------------Declare varables and functions

int picnum=0;//select piece stage flag

const int gm=0; //1 for game mode (full screen), 0 for window
const int tex=0; //1 for texture enabled (slow on my computer)
float scale=1;   //size of everything

int turn=0;
int checkw=0;
int checkb=0;


GLuint theBoard=1; // name for checkerboard (1) display list

GLuint thePawn=2;
GLuint theRook=3;
GLuint theWknight=4;
GLuint theBknight=5;
GLuint theBishop=6;
GLuint theKing=7;
GLuint theQueen=8;

//----------------Below is framework for board-------
struct square {

	//BITMAP *memory_bitmap;
	char T;
}box[8][8];

square whitedead[8][2];
square blackdead[8][2];

int wdcurs=0;
int bdcurs=0;




int xbox, ybox;
int movx, movy;


const float PI=3.14159265358; 
// half the # of pie slice radiuses that can fit around the pie pan:)




float direction=3 * PI/2; //camera orientation (radians) 
float ydirection=0;   // for looking up and down (radians)
const int sightradius =40;
float cx=0, cy=20, cz=0;//camera x,y,z coordinates
float lx=0, ly=20, lz=40;//camera look at coordinates

int up=0, down=0, left=0, right=0, pup=0, pdown=0;  // keyboard flags


//function prototypes-----------------------------------------

void display(void);  

void idle(void);
void init(void);

void keyboard(unsigned char key, int x, int y); 
void reshape(int width, int height);
void special(int key, int x, int y);  //for keys with no ascii code
void specialup(int key, int x, int y);// what to do when you let up on a key

void lightning(void);//---lightning
void stars(void);
void drawnewboard(GLenum mode);//Draw piecies

void make_board();//init data
int islegal();//self explanatory
int isemptypath();
void selectbox(GLuint hits, GLuint buffer[]);// 3d selection routine

//draw functions create the pieces and compile them to a list
void draw_pawn();
void draw_rook();
void draw_wknight();
void draw_bknight();
void draw_bishop();
void draw_king();
void draw_queen();
void drawpiece(int x, int y);

void gotopos(int x, int y);//translation and set color of piece
void drawasquare(int x, int y);//draws an empty square.......
void drawdead();


//////////////////////////////BEGIN FUNCTIONS/////////////////////

void drawnewboard(GLenum mode)
{

for(int y = 0; y < 8; y++)//-------------begin y loop
{		
		if (mode == GL_SELECT)
		glLoadName(y);
	for(int x = 0; x < 8; x++)//----------begin x loop
	{
		if (mode==GL_SELECT)
				glPushName(x);
		
		if(	mode==GL_SELECT && box[x][y].T == 'E')//- if empty
		{
		gotopos(x,y);	
		drawasquare(x, y);
		glPopMatrix();
		}

		drawpiece(x,y);
		
				if(mode==GL_SELECT)
				glPopName();

	}//--------end x loop-----------

}//end y loop--------



}//------------end drawnewboard------------

void drawdead()
{


//------start whitedead draw-------------

	for(int y = 0; y < 2; y++)//-------------begin y loop
	{				
	for(int x = 0; x < 8; x++)//----------begin x loop
	{	
		if(whitedead[x][y].T != 'E')//- if empty
		{
		glPushMatrix();
		glTranslatef(0,40,-60);
			
		
		if(whitedead[x][y].T=='P'){
				gotopos(x,y);
				glColor3f(.7, .7, .8);
				glCallList(thePawn);
				glPopMatrix();
			}
			
			
				if(whitedead[x][y].T=='R'){
				gotopos(x,y);
				glColor3f(.7, .7, .8);
				glCallList(theRook);
				glPopMatrix();
				}
				if(whitedead[x][y].T=='N'){
				gotopos(x,y);
				glColor3f(.7, .7, .8);
				glCallList(theWknight);
				glPopMatrix();
				}

			

				if(whitedead[x][y].T=='Q'){
				gotopos(x,y);
				glColor3f(.7, .7, .8);
				glCallList(theQueen);
				glPopMatrix();
				}
				if(whitedead[x][y].T=='B'){
				gotopos(x,y);
				glColor3f(.7, .7, .8);
				glCallList(theBishop);
				glPopMatrix();
				}
				if(whitedead[x][y].T=='K'){
				gotopos(x,y);
				glColor3f(.7, .7, .8);
				glCallList(theKing);
				glPopMatrix();
				}
		glPopMatrix();// undoes dead board translation
		}//------end if not empty
		
	}//--------end x loop-----------

}//end y loop--------

//-------------------------------end whitedead

//-----------------------------begin blackdead
for(int by = 0; by < 2; by++)//-------------begin by loop
{		
		
	for(int x = 0; x < 8; x++)//----------begin x loop
	{
			
		if(blackdead[x][by].T != 'E')//- if notempty
		{
		glPushMatrix();	
		glTranslatef(0,40,190);
			
		
		if(blackdead[x][by].T=='p'){
				gotopos(x,by);
				glColor3f(.3, .2, .2);
				glCallList(thePawn);
				glPopMatrix();
			}
			
			
				if(blackdead[x][by].T=='r'){
				gotopos(x,by);
				glColor3f(.3, .3, .2);
				glCallList(theRook);
				glPopMatrix();
				}
				if(blackdead[x][by].T=='n'){
				gotopos(x,by);
				glColor3f(.2, .2, .2);
				glCallList(theBknight);
				glPopMatrix();
				}

			

				if(blackdead[x][by].T=='q'){
				gotopos(x,by);
				glColor3f(.2, .2, .2);
				glCallList(theQueen);
				glPopMatrix();
				}
				if(blackdead[x][by].T=='b'){
				gotopos(x,by);
				glColor3f(.2, .2, .2);
				glCallList(theBishop);
				glPopMatrix();
				}
				if(blackdead[x][by].T=='k'){
				gotopos(x,by);
				glColor3f(.2, .2, .2);
				glCallList(theKing);
				glPopMatrix();
				}
		
				glPopMatrix();
		}//------end if not emptby

		
		
	}//--------end x loop-----------

}//end by loop--------


}//------------end drawdead------------

void drawpiece(int x,int y)
{
	if(box[x][y].T=='P' || box[x][y].T=='p'){
				gotopos(x,y);
				glCallList(thePawn);
				glPopMatrix();
			}
			
			
				if(box[x][y].T=='r' || box[x][y].T=='R'){
				gotopos(x,y);
				glCallList(theRook);
				glPopMatrix();
				}
				if(box[x][y].T=='N'){
				gotopos(x,y);
				glCallList(theWknight);
				glPopMatrix();
				}

				if(box[x][y].T=='n'){
				gotopos(x,y);
				glCallList(theBknight);
				glPopMatrix();
				}

				if(box[x][y].T=='q' || box[x][y].T=='Q'){
				gotopos(x,y);
				glCallList(theQueen);
				glPopMatrix();
				}
				if(box[x][y].T=='b' || box[x][y].T=='B'){
				gotopos(x,y);
				glCallList(theBishop);
				glPopMatrix();
				}
				if(box[x][y].T=='k' || box[x][y].T=='K'){
				gotopos(x,y);
				glCallList(theKing);
				glPopMatrix();
				}


}//end drawpiece

//-----------------------------------start lightning----------------
void lightning(void)
{

glDisable(GL_LIGHTING);

glPushMatrix();

	glTranslatef(rand()%clip -clip/2,0,rand()%clip -clip/2);
	glBegin(GL_LINE_STRIP);

for(int star=200; star>0; star+=rand()%20 - 17)
{	
	glVertex3f(rand()%30 -15,star,rand()%30 -15);
	glColor3f(1, 1, 1);
}
	glEnd();

glPopMatrix();


}//--------------------------------------------end lightning


void stars(void)
{

glDisable(GL_LIGHTING);

glPushMatrix();

	//glTranslatef(rand()%clip -clip/2,0,rand()%clip -clip/2);
	glBegin(GL_POINTS);
glColor3f(.9, .9, .9);
for(int star=0; star<200; star++)
{	
	glVertex3f(rand()%clip -clip/2,rand()%100,rand()%clip -clip/2);
	
}
	glEnd();

glPopMatrix();


}//--------------------------------------------end stars

void drawasquare(int x, int y)
{
	glDisable(GL_LIGHTING);		
        
		glBegin(GL_QUADS);
		glVertex3i(-10,0,10);
		glVertex3i(10,0,10);
		glVertex3i(10,0,-10);
		glVertex3i(-10,0,-10);

		glEnd();


}

void gotopos(int x, int y)
{

	glPushMatrix();
	glTranslatef((x-4)*20+10,2,(y-4)*20+10);
	if(box[x][y].T >='A' && box[x][y].T <='Z')glColor3f(.7, .7, .8);
	if(box[x][y].T >='a' && box[x][y].T <='z')glColor3f(.2, .2, .2);
	

}//--------------------end gotopos-------------------------


//-------------------------------------------DRAW_PAWN---

void draw_pawn()
{

glNewList(thePawn, GL_COMPILE);		
glRotatef(90,1,0,0);

glTranslatef(0,0,1);	
glutSolidTorus(1,4,20,10);
glTranslatef(0,0,-1);
glRotatef(180,1,0,0);
glutSolidCone(4,8,10,10);
glRotatef(180,1,0,0);
glTranslatef(0,0,-3);
glutSolidTorus(1,3,20,10);
glTranslatef(0,0,-3);
glutSolidSphere(2,10,10);

			glPopMatrix();

glEndList();

}//----------end draw pawn--------------


//--------------------DRAW ROOK---------------------

void draw_rook()
{
	glNewList(theRook, GL_COMPILE);

glTranslatef(0,6,0);

	glScalef(1,1.5,1);
	glutSolidCube(10);
	//-------------------begin rook crown---------
for(int crownx=0; crownx <10; crownx+=4)
{
	for(int crowny=0;crowny<10; crowny+=4)
	{
	glPushMatrix();

glTranslatef(crownx-4,6,crowny-4);

		glutSolidCube(2);

	glPopMatrix();//top of rook

	}//-------end y loop
}//-------end x loop

		glPopMatrix();//------before rook
glEndList();
		
}//------------------end draw rook----------



//----------------------------------BEGIN DRAW WKNIGHT

void draw_wknight()
{
	
glNewList(theWknight, GL_COMPILE);

glPushMatrix();//---location of piece

glRotatef(90,1,0,0);
		
	

glutSolidTorus(1,5,20,10);

glTranslatef(0,0,-2);
glutSolidTorus(1,5,20,10);

glTranslatef(0,0,-2);
glutSolidTorus(0,3,20,10);


glPopMatrix();//-------undo tourus rotation

glTranslatef(0,8,0);

glPushMatrix();
//---------------------start knight rotation

glRotatef(-45,1,0,0);

glScalef(1,1,2);
glutSolidCube(4);

glPopMatrix();//----undo tourus rotation & scaleing

glTranslatef(0,4,0);


glRotatef(45,1,0,0);//--------- knight rotation

glScalef(1,1,2);
glutSolidCube(4);



glPopMatrix();//-------undo piece location

glEndList();

}//-----------------end draw wknight--------


//----------------------------BEGIN DRAW BKNIGHT---------

void draw_bknight()
{
	
glNewList(theBknight, GL_COMPILE);
glPushMatrix();//---location of piece

glRotatef(90,1,0,0);
		
	

glutSolidTorus(1,5,20,10);

glTranslatef(0,0,-2);
glutSolidTorus(1,5,20,10);

glTranslatef(0,0,-2);
glutSolidTorus(0,3,20,10);


glPopMatrix();//-------undo tourus rotation

glTranslatef(0,8,0);

glPushMatrix();
//---------------------start knight rotation

glRotatef(45,1,0,0);



glScalef(1,1,2);
glutSolidCube(4);

glPopMatrix();//----undo tourus rotation & scaleing

glTranslatef(0,4,0);


glRotatef(-45,1,0,0);//--------- knight rotation

glScalef(1,1,2);
glutSolidCube(4);



glPopMatrix();//-------undo piece location

glEndList();
}//-----------------end draw bknight--------

//----------------------------------BEGIN DRAW BISHOP------
void draw_bishop()
{

	glNewList(theBishop, GL_COMPILE);
glRotatef(90,1,0,0);
	

glutSolidTorus(1,5,20,10);
glTranslatef(0,0,-3);
glutSolidSphere(4,10,10);
glTranslatef(0,0,-3);
glutSolidTorus(1,3,20,10);
glTranslatef(0,0,-5);
glScalef(1,1,3);
glutSolidSphere(2,10,10);


glPopMatrix();

glEndList();
}//--------end draw bishop---------


void draw_queen()
{
	glNewList(theQueen, GL_COMPILE);
	glRotatef(90,1,0,0);



glutSolidTorus(1,4,20,10);

glTranslatef(0,0,-2);
glutSolidTorus(1,5,20,10);

glTranslatef(0,0,-1);
glRotatef(180,1,0,0);
glutSolidCone(4,15,20,10);

glRotatef(180,1,0,0);
glTranslatef(0,0,-18);

glutSolidSphere(3,10,10);


glPopMatrix();



glEndList();

}//--------end draw queen---------

//------------------------------------BEGIN DRAW KING-------
void draw_king()
{
	glNewList(theKing, GL_COMPILE);
glRotatef(90,1,0,0);
	

glutSolidTorus(1,4,20,10);

glTranslatef(0,0,-2);
glutSolidTorus(1,5,20,10);

glTranslatef(0,0,-1);
glRotatef(180,1,0,0);
glutSolidCone(4,15,20,10);

glRotatef(180,1,0,0);
glTranslatef(0,0,-18);
glutSolidCone(4,15,20,10);

glutSolidSphere(3,10,10);


glPopMatrix();



glEndList();
}//--------end draw king---------



//***************************************END DRAW PIECES******




//-----------------------------------------BEGIN MAKE BOARD

void make_board()
{

//*/-------init dead
for(int col =0; col<8; col++)
{
 whitedead[col][1].T='E';
 blackdead[col][1].T='E';
 whitedead[col][2].T='E';
 blackdead[col][2].T='E';
}

//*///---end init dead



for(int y = 0; y < 8; y++)//-------------begin y loop
{
		
	for(int x = 0; x < 8; x++)//-----------------begin x loop
	{

		if((y > 1) || (y<6))
			box[x][y].T = 'E';
	
	//----------------------PAWNS-------------------------------------

	if(y == 1)
	{
			
		box[x][y].T = 'p';
		gotopos(x,y);
		draw_pawn();
		glPopMatrix();

	//>>>>>>BLACK<<<<<<<<<
	}

	if(y == 6)
	{
					
		box[x][y].T = 'P';
		gotopos(x,y);
		draw_pawn();
		glPopMatrix();

		//>>>>>>>>>>WHITE>>>>>>>>>>>
	}

	//------------------- player pieces-----------------------

	
	if((y==0 || y==7) && (x == 0 || x == 7))//--------ROOKS-----------------------
	{	

		if( y == 7){
		
			box[x][y].T = 'R';
			gotopos(x,y);
			draw_rook();
			glPopMatrix();
			
		}
		if( y == 0){

			
			box[x][y].T = 'r';
			gotopos(x,y);
			draw_rook();
			glPopMatrix();
			
		}

				
	}//---------------------end ROOKS------------
	

	
	if((y==0 || y==7) && (x == 1 || x == 6))//--------KNIGHTS--------------
	{
			
		if( y == 7){
		box[x][y].T = 'N';
		gotopos(x,y);
		draw_wknight();
		glPopMatrix();
		
		}
			
		if( y == 0){
		box[x][y].T = 'n';
		gotopos(x,y);
		draw_bknight();
		glPopMatrix();
		}
	
	}//---------------------------end Knight------



	if( (y==0 || y==7)&&(x == 2 || x == 5) )//--------BISHOPS--------------
	{


		if( y == 7){
			box[x][y].T = 'B';
			gotopos(x,y);
			draw_bishop();
			glPopMatrix();
		}
		if( y == 0){
			box[x][y].T = 'b';
			gotopos(x,y);
			draw_bishop();
			glPopMatrix();
		}
	}//---------end bishop----------

	if((y==0 || y==7) && (x == 3))//--------QUEENS--------------
	{
		



			if( y == 7){
			box[x][y].T = 'Q';
			gotopos(x,y);
			draw_queen();
			glPopMatrix();
			}
			if( y == 0){
			box[x][y].T = 'q';
			gotopos(x,y);
				draw_queen();
				glPopMatrix();
			
			}




}//----------end queen

	if((y==0 || y==7) && (x == 4))//--------KINGS--------------
	{
			if( y == 7){
			
			box[x][y].T = 'K';
			gotopos(x,y);
				draw_king();	
				glPopMatrix();
			}
			if( y == 0){
			box[x][y].T = 'k';
			gotopos(x,y);
				draw_king();
				glPopMatrix();
			}
	}//------------end King

		

	 
	}//-------end x loop
}//-----------end y loop---------------------------

}//>>>>>>>>>>>>>>>>>>>>>>end makeboard<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<


//--------------------------------BEGIN SELECT----------------------

void selectbox(GLuint hits, GLuint buffer[])
{
//------------------------------------------------actually move pieces------------------------



//below comes from book-------------

    unsigned int i, j;
	GLuint ii, jj, names, *ptr;

	printf("hits = %i\n", hits);
	ptr = (GLuint *) buffer;


	for (i=0; i< hits; i++){ //for each hit
		names =*ptr;
		//printf("number of names for this hit = %d\n", names);
			ptr++;
		//printf(" z1 is %g;", (float) *ptr/0x7fffffff);
			ptr++;
		//printf(" z2 is %g\n;", (float) *ptr/0x7fffffff);
		ptr++;
		//printf("    names are ");
		for(j=0;j<names;j++){//  for each name
			//printf("%d -", *ptr);
			if(j==0)// set row and column
				ii=*ptr;
			else if (j==1)
				jj=*ptr;
			ptr++;
		}//end for names
		
	
		printf("\n");
		printf("\n");


		if(picnum ==0)
		{
		printf("\n pic num is 0");
	
		}

		if(picnum ==1)
		{
		xbox=jj;
		ybox=ii;
		printf("\n");
		printf(" xbox =%d ", xbox);
		printf("\n");
		printf(" ybox =%d ", ybox);
		}
		if(picnum ==2)
		{
		movx=jj;
		movy=ii;
		printf(" xbox =%d ", xbox);
		printf("\n");
		printf(" ybox =%d ", ybox);
		printf("\n");
		printf(" movx =%d ", movx);
		printf("\n");
		printf(" movy =%d ", movy);
		}

		
		
		printf("\n");
		printf("\n");
		
	}//end for hits

	//above comes from book----------------------------

if(box[xbox][ybox].T=='E'  ||
   (box[xbox][ybox].T <'Z' && turn==1)||
   (box[xbox][ybox].T >'Z' && turn==0))picnum=0;
//if no piece to move or not right turn

printf("\n");
printf("picnum is %d",picnum);
printf("\n");
//>>>>>>>>>>>>>>draw indicator and select 2nd Piece<<<<<<<<<<<<


//source not empty && not (both white) && 
//not (dest not empty && both black

if(picnum==3 && box[xbox][ybox].T != 'E' 
&& !(box[xbox][ybox].T >'Z' && box[movx][movy].T >'Z')
&& !(box[movx][movy].T !='E' && box[xbox][ybox].T <'Z' && box[movx][movy].T <'Z' )
&& islegal()
)
/* test
if(picnum==2 && box[xbox][ybox].T != 'E' 
&& !(box[xbox][ybox].T >'Z' && box[movx][movy].T >'Z')
&& !(box[movx][movy].T !='E' && box[xbox][ybox].T <'Z' && box[movx][movy].T <'Z' )
&& islegal()
)
*/
//^^^cant be taken by same type or empty square.------------------------------
{
	picnum=0;
turn++;

int row=0, col=0;

if(turn ==2) turn =0;//turn alternator
	printf("successflull move");

	if(box[movx][movy].T!='E' && box[movx][movy].T>'Z')
	{
		if(bdcurs>7)
		{
			row = bdcurs -8; col =1;
		}
		else row=bdcurs;
		bdcurs++;
	blackdead[row][col].T = box[movx][movy].T;
	}

	if(box[movx][movy].T!='E' && box[movx][movy].T<'Z')
	{
		if(wdcurs>7){row = wdcurs -7; col =1;}
		else row=wdcurs;
		wdcurs++;
	whitedead[row][col].T = box[movx][movy].T;
	}
//----above asigns dead to 1 black and 1 white 8x2 dead grid

	box[movx][movy].T = box[xbox][ybox].T;
	box[xbox][ybox].T = 'E';

//copy source piece to destination square, empty source


//----------------------Below is for Queen from pawn.------
	if(movy == 7)
	{
		//--------put graphics code here-------

		if(box[movx][movy].T == 'p')
		{

		//--------graphich here---------

		box[movx][movy].T ='q';
		}
	}

	if(movy == 0)
	{
		//------put graphics here-------

		if(box[movx][movy].T == 'P')
		{

		//------put graphics here-------

		box[movx][movy].T ='Q';
		}
	}
glutPostRedisplay();

}//end same kind or empty and 2nd piece if----------------------





}//-----------------END SELECT------------------------------------



//-------------------------------------begin islegal()__-----------------


int islegal()
{
if( 
//----------------------pawn movement---------------------

(box[xbox][ybox].T == 'p' &&  box[movx][movy].T !='K' && ( (movy-ybox==2 && ybox==1 && box[movx][2].T=='E' && xbox==movx
&& box[movx][3].T=='E')
||(movy-ybox ==1 && ybox>=1 && box[movx][movy].T=='E' && xbox==movx) 
||((xbox-movx == 1 || xbox-movx ==-1) && box[movx][movy].T !='E' && movy-ybox==1) )

    )//---end Blackpawn paren


||  


(box[xbox][ybox].T == 'P'  &&  box[movx][movy].T !='k' && ( (ybox-movy<=2 && ybox==6 && box[movx][5].T=='E' && xbox==movx
&& box[movx][4].T=='E')
||(ybox-movy ==1 && ybox<=6 && box[movx][movy].T=='E' && xbox==movx)
||((xbox-movx == 1 || xbox-movx ==-1) && box[movx][movy].T !='E' && ybox-movy==1) )

    )//---end Whitepawn paren


//--------------------end pawn movement_____________________
//_____________________Begin Rook___________________________

||

( ((box[xbox][ybox].T == 'r' &&  box[movx][movy].T !='K' ) 
 || (box[xbox][ybox].T=='R' &&  box[movx][movy].T !='k' )) && (xbox==movx || ybox==movy)
&& isemptypath()   
	)//-----end rook paren----

//-----------end rook movement--------------
//-----------begin queen-------

||

( ((box[xbox][ybox].T == 'q' &&  box[movx][movy].T !='K' ) 
 || (box[xbox][ybox].T == 'Q' &&  box[movx][movy].T !='k' )) 
&& (xbox==movx || ybox==movy || xbox-movx == ybox-movy || movx-xbox == ybox-movy ) 
&& isemptypath()

	)//----end queen paren

//-------------end queen movement------------
//-------------begin bishop movement---------

||

( ((box[xbox][ybox].T == 'b' &&  box[movx][movy].T !='K' )
 || (box[xbox][ybox].T == 'B' &&  box[movx][movy].T !='k' )) 
&& (xbox-movx == ybox-movy || movx-xbox == ybox-movy ) 
&& isemptypath()

	)//----end bishop paren

//-------------end bishop movement----------
//-------------begin king-------------------

||

( ((box[xbox][ybox].T=='k' &&  box[movx][movy].T !='K' )
 || box[xbox][ybox].T == 'K' &&  box[movx][movy].T !='k' )
&& (xbox-movx <=1 && xbox-movx >=-1 && ybox-movy <=1 && ybox-movy >=-1)

	)//----end king paren


//-------------end king movement----------
//-------------begin knight-------------------

||

( ((box[xbox][ybox].T=='n' &&  box[movx][movy].T !='K' )
 || (box[xbox][ybox].T == 'N' &&  box[movx][movy].T !='k' ))
&& ( (abs(xbox-movx)==2 && abs(ybox-movy)==1)||(abs(xbox-movx)==1 && abs(ybox-movy)==2))

	)//----end knight paren


  )//----end if paren

{
return 1;

}//end move constraints_________________________

return 0;	
}//----------------------------------------------end islegal-------------------------


int isemptypath()
{

int nump = 0;
int xdif = movx-xbox;
int ydif = movy-ybox;
int xs=1;
int ys=1;
int tempy = ybox;


if(xdif < 0) xs = -1;
if(ydif < 0) ys = -1;

if(xdif==0 && ydif !=0)
{

for(int y= ybox + ys; y != movy; y+=ys)
	if(box[xbox][y].T != 'E') nump = nump +1;

}

if(xdif!=0 && ydif ==0)
{

for(int x= xbox + xs; x !=movx; x+=xs)
	if(box[x][ybox].T != 'E') nump = nump +1;

}


if(ydif * ys == xdif * xs)
{

for(int x= xbox + xs; x !=movx; x+=xs)
{
	tempy = tempy + ys; 
	if(box[x][tempy].T != 'E') nump = nump +1;
}

}



if(nump >0)  return 0;
if(nump <=0) return 1;
return 1;

}//--------------------------------------end isemptypath()-----------------------





void idle(void)//---------------------------Begin IDLE-------------
{


float sdis=(sightradius*cos(ydirection))*sin(direction)*scale/10;//zydir?
float cdis=(sightradius*cos(ydirection))*cos(direction)*scale/10;//xydir


    //down
	if(down) 
	{	
		
			
			cz+=sdis;
			cx-=cdis;
			
		
			lx-=cdis;
			lz+=sdis;
			

		if(cy-sightradius*sin(ydirection)>3 )
			{
		cy-=sightradius*sin(ydirection)*scale/10;
		ly-=sightradius*sin(ydirection)*scale/10;
			}

		
		
	}//------end normal down



	//up
	if(up ) {

		cx+=cdis;
		cz-=sdis;
		lz-=sdis;
		lx+=cdis;
		
			if(cy+sightradius*sin(ydirection)>3 )
			{
		cy+=sightradius*sin(ydirection)*scale/10;
		ly+=sightradius*sin(ydirection)*scale/10;
			}

		
	}//end up



	//------normal left
	if(left ){

		direction+=.1;
			
		if(direction > 2*PI) direction -= 2*PI;

		lx=cx + sightradius*cos(ydirection)* cos(direction);
		lz=cz - sightradius*cos(ydirection)* sin(direction);
		
	}//-----end normal left




	//----------normal right
	if(right ){
		
		direction-=.1;

		if(direction < -2*PI) direction += 2*PI;


		lx=cx + sightradius*cos(ydirection)* cos(direction);
		lz=cz - sightradius*cos(ydirection)* sin(direction);
		
	}



	


		//pup
	if(pup && ydirection<PI/2 -.2 ){
		ydirection+=.2;
		lx=cx + sightradius*cos(ydirection)* cos(direction);
		lz=cz - sightradius*cos(ydirection)* sin(direction);
		ly=cy + sightradius*sin(ydirection);
		
	}


	//pdown
	if(pdown && ydirection > -PI/2 +.2 ){
		ydirection-=.2;
		lx=cx + sightradius*cos(ydirection)* cos(direction);
		lz=cz - sightradius*cos(ydirection)* sin(direction);
		ly=cy + sightradius*sin(ydirection);
		
	}


	
		

glutPostRedisplay(); 
}

//---------------------------------------END IDLE---------------------------


void mouse(int button, int state, int x, int y)
{


	if (button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN)
	{
		picnum--;		
		return;
	}

	if (button != GLUT_LEFT_BUTTON || state != GLUT_DOWN)
		return;

	
picnum++;
if(picnum >3 )picnum=0;

	GLuint selectBuf[BUFSIZE];
	GLint hits;
	GLint viewport[4];

	glGetIntegerv(GL_VIEWPORT, viewport);

	glSelectBuffer(BUFSIZE, selectBuf);
	glRenderMode(GL_SELECT);

	glInitNames();
	glPushName(0);
	
	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();


	gluPickMatrix((GLdouble) x,(GLdouble) (viewport[3]-y),
		.5, .5, viewport);
//  create 5x5 pixel picking region near cursor location 



//-------Below is to maintain aspect ratio-----
	
float l=float(twidth)/float(theight);	
	if(twidth<=theight)
	glFrustum(-1, 1 ,-1/l ,1/l, 1.5, clip*scale);
	else
	glFrustum(-l , l , -1 ,1, 1.5, clip*scale);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

//-----------------------------------------------------


	gluLookAt(cx, cy, cz, lx, ly, lz, 0.0, 1.0, 0.0);
	// (camera at x,y,z, aimed at 0,0,0, up is 0,1,0)
/**/
	drawnewboard(GL_SELECT);

	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	//glLoadIdentity();
	
	glutSwapBuffers();
	glFlush();

	
	//cleartest----------------------------------
	hits = glRenderMode(GL_RENDER);
	//if (hits>0)
	selectbox(hits, selectBuf);

	glutPostRedisplay();




}//---------End mouse------------


//--------------------------------------BEGIN INIT-------------

void init(void)
{
//glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
	

	if(gm)glutEnterGameMode();
	glClearColor(0.0,0.0,0.0,1);
//-----------------------------------material properties from book-

	GLfloat mat_specular[] ={1,1,1,1};
	GLfloat mat_shininess[] ={120};

GLfloat white_light[] ={1,1,1,1};
GLfloat lmodel_ambient[]={.1, .1, .1, .1};






	glShadeModel(GL_SMOOTH);
	glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER, GL_TRUE);
	glLightModeli(GL_LIGHT_MODEL_TWO_SIDE, GL_FALSE);

	float pos[]={1,1,1,0};
	float posb[]={1,20,1,1};

glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);

	glLightfv(GL_LIGHT0, GL_POSITION, pos);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, white_light);
	glLightfv(GL_LIGHT0, GL_SPECULAR, white_light);


    glEnable(GL_COLOR_MATERIAL);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
	glEnable(GL_DEPTH_TEST);

	
	glutIgnoreKeyRepeat(1);
//------------------------------------------------makeboard-------	

glNewList(theBoard, GL_COMPILE);


int col=1;

for(int z=-4; z<=3; z++)//-----------begin outer for loop for checkerboard
{
      
col=-col;

	for(int x=-4;x<=3;x++)//////////begin inner loop
	{


//-----------------------begin if monolith test----------------
		if((z==-4 && x==-4) ||(z==-4 && x==3 )|| (z==3 && x==-4)
			||(z==3 && x==3)){
		glPushMatrix();glEnable(GL_LIGHTING);

if(z==-4 && x==-4){
	glTranslatef(-7*20+10,-10,-7*20+10);glScalef(1,20,1);glColor3f(0.1, 0.1, 0.1);}

if(z==-4 && x==3){
	glTranslatef(7*20+10,-10,-7*20+10);glScalef(1,20,1);glColor3f(0.1,0.1,0.1);}
if(z==3 && x==-4){
	glTranslatef(-7*20 +10,-10,7*20+10);glScalef(1,20,1);glColor3f(.9, .9, .9);}
if(z==3 && x==3){
	glTranslatef(7*20+10,-10,7*20+10);glScalef(1,20,1);glColor3f(.9, .9, .9);}

	

glutSolidCube(20);

glPopMatrix();


		}///---------------------end if monolith----------------



///////////////////////////////////BEGIN CHECKERBOARD-------------------
col=-col;
glDisable(GL_LIGHTING);		

		if(col==1)
		{
			glColor3f(.2, .2, .2);
		}
		else glColor3f(.9,.9,.9);

        
		glBegin(GL_QUADS);
		//glNormal3f(0,1,0);
		glVertex3i(x*20,0,-z*20);
		//glNormal3f(0,1,0);
		glVertex3i(x*20+20,0,-z*20);
		//glNormal3f(0,1,0);
		glVertex3i(x*20+20,0,-z*20 -20);
	//	glNormal3f(0,1,0);
		glVertex3i(x*20,0,-z*20 -20);

		glEnd();

	
	}/////////end inner loop
	




	
}//---------------------end outer makeboard loop



//------------------------------------------ground
glPushMatrix();
glColor3f(.2, .6,.2);


glTranslatef(0,-10,0);
glRotatef(-90,1,0,0);
glRectf(-300,-300,300,300);
glPopMatrix();

	
glEndList();

	
make_board();
glEnable(GL_LIGHTING);

}//-------------------------END INIT--------------




//------------------------------------Begin Display-------------------------
void
display(void)
{
	glMatrixMode(GL_MODELVIEW);

	if(turn==1)glClearColor(0.0,0.0,0.0,1);
	if(turn==0)glClearColor(0.0,.2,.5,1);

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glColor3f(1.0,1.0,1.0);
	glLoadIdentity();//clears matrix

gluLookAt(cx, cy, cz
		, lx, ly, lz, 0.0, 1.0, 0.0);

	// (camera at x,y,z, aimed at 0,0,0, up is 0,1,0)


	glPolygonMode(GL_FRONT, GL_FILL);
	glPolygonMode(GL_BACK, GL_FILL);


glCallList(theBoard);


if(turn==1)
{
	lightning();
	stars();
	//------------------------------------------ground
glPushMatrix();
glColor3f(.5, .0,.0);


glTranslatef(0,-9,0);
glRotatef(-90,1,0,0);
glRectf(-300,-300,300,300);
glPopMatrix();

}



//if(turn==0)





glEnable(GL_LIGHTING);
drawnewboard(GL_RENDER);
drawdead();

int tempmove[]={movx,movy};


if(picnum ==1 || picnum ==2)
{
		
		glPushMatrix();
		gotopos(xbox,ybox);
	
		//glTranslatef(0,0,0);
		glColor3f(1,.2,0.2);
		drawasquare(1,1);
		glPopMatrix();
		glPopMatrix();

for(int row=0; row<8; row++)
{
	for(int col=0; col<8; col++)
	{
	movx=row;
	movy=col;

		if(box[xbox][ybox].T != 'E' 
&& !(box[xbox][ybox].T >'Z' && box[movx][movy].T >'Z')
&& !(box[movx][movy].T !='E' && box[xbox][ybox].T <'Z' && box[movx][movy].T <'Z' )
&& islegal())
		{
			if(box[movx][movy].T =='E')
			{
		glPushMatrix();
		gotopos(movx,movy);
		
		glTranslatef(0,0,0);
		glRotatef(90,1,0,0);
		glColor3f(.2,.2, 1);
		glutWireSphere(4,10,10);
		glPopMatrix();
		glPopMatrix();
			}//end if empty

		




if(box[movx][movy].T != 'E')
{

glPushMatrix();
gotopos(movx, movy);
	glTranslatef(0,8,0);
	
		glColor3f(.2,.2, 1);
glutWireCube(15);
glPopMatrix();
glPopMatrix();

}//end if not empty

		}//end if islegal


	}//end col for
}//end row for

movx= tempmove[0];
movy= tempmove [1];
		
}//end if picnum is 1 or 2.


if(picnum ==2)
		{
		
		glPushMatrix();
		gotopos(movx,movy);
	//	glPushMatrix();
		glTranslatef(0,.01,0);
		glColor3f(.8,.8,0.2);
		drawasquare(1,1);
		glPopMatrix();
		glPopMatrix();
		
		}

//------------------------------------put new code here!!!!!!!


glutSwapBuffers();
	 glFlush();

	 		

}//-------------------------------------End Display--------------------------

void
reshape(int width, int height)
{

 twidth=width;
 theight=height;

    glViewport(0, 0, width, height);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

//-------Below is to maintain aspect ratio-----
	
float l=float(width)/float(height);	
	if(width<=height)
	glFrustum(-1, 1 ,-1/l ,1/l, 1.5, clip*scale);
	else
	glFrustum(-l , l , -1 ,1, 1.5, clip*scale);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

	glEnable(GL_DEPTH_TEST);

}//----------end reshape-----------------



void
keyboard(unsigned char key, int x, int y)
{   	
	if (key ==27) {
        exit(0);
	   }

	if (key ==32)
	{

	 cx=0, cy=8, cz=0;//camera coordinates
     lx=0,ly=8,lz=40;//camera look at coordinates

     direction=PI/2; //camera orientation (radians) 
     ydirection=0;   // for looking up and down


	}
		
		




}//------------------end keyboard--------------




void
special(int key, int x, int y)
{
  switch (key) {
  
  case GLUT_KEY_UP:
    up = 1;
    
    break;
  case GLUT_KEY_LEFT:
    left = 1;
    
    break;
  case GLUT_KEY_RIGHT:
    right = 1;
    
    break;
  case GLUT_KEY_DOWN:
    down = 1;

    break;
  case GLUT_KEY_PAGE_UP:
    pup = 1;
    
    break;
  case GLUT_KEY_PAGE_DOWN:
    pdown = 1;
    break;




  }
}


void
specialup(int key, int x, int y)
{
  switch (key) {
  case GLUT_KEY_UP:
    up = 0;
    break;
  case GLUT_KEY_LEFT:
    left = 0;
    break;
  case GLUT_KEY_RIGHT:
    right = 0;
    break;
  case GLUT_KEY_DOWN:
    down = 0;
    break;
  case GLUT_KEY_PAGE_DOWN:
    pdown = 0;
    break;
  case GLUT_KEY_PAGE_UP:
    pup = 0;
    break;




  }
}


int
main(int argc, char** argv)
{	
	glutInit(&argc, argv);

    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB |GLUT_DEPTH);
    glutInitWindowSize(500, 500);
    if(!gm)glutInitWindowPosition(50, 50);

    if(!gm)glutCreateWindow(argv[0]);
	init();
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutKeyboardFunc(keyboard);
    //glutKeyboardUpFunc(keyup);
    glutSpecialFunc(special);
    glutSpecialUpFunc(specialup);
	glutMouseFunc(mouse);
	glutIdleFunc(idle);
    glutMainLoop();
    return 0;
}
