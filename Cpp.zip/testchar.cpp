#include <conio.h>
#include <iostream.h>
#include <stdio.h>
#include <stdlib.h>
#include <fstream.h>
#include <string.h>

char st[900];

void main(void)
{
ifstream in("compare.txt");

cout.getline(st, 900, '\n');

cout << 'A';
}
