/* 
 *    Example program for the Allegro library, by Shawn Hargreaves.
 *
 *    This program demonstrates the use of memory bitmaps. It creates
 *    a small temporary bitmap in memory, draws some circles onto it,
 *    and then blits lots of copies of it onto the screen.
 */


#include <stdlib.h>
#include <stdio.h>
#include <rand.h>


#include "allegro.h"


int main()
{
   BITMAP *memory_bitmap;
   int x, y;

   allegro_init();
   install_keyboard(); 
   set_gfx_mode(GFX_VGA, 320, 200, 0, 0);
   set_pallete(desktop_pallete);

   /* make a memory bitmap sized 20x20 */
   memory_bitmap = create_bitmap(320, 200);

   /* draw some circles onto it */
   //clear(memory_bitmap);
   //for (x=0; x<200; x++)
      //circle(memory_bitmap, 160, 100, x, x/2);

   /* blit lots of copies of it onto the screen */

   //for (y=0; y<SCREEN_H; y+=200)
      //for (x=0; x<SCREEN_W; x+=200)
	x=0;y=0;


	 blit(memory_bitmap, screen, 0, 0, x, y, 320, 200);

int inc =1;

	rectfill(memory_bitmap, 0, 0, 320, 200, -1);

// first animation------------------------------------------------
while (!key[KEY_ESC]){
for (int n =2; n<100; n = n + inc)
{
	clear(memory_bitmap);
   	for (x=0; x<200; x =x+inc){
      	circle(memory_bitmap, 160, 100, x, x/n);
	


	//line(memory_bitmap, 160, 100, RND() % 300, RND() %200, RND()%100);
		//line(memory_bitmap, 0, 0, 100, 100, 6);


	blit(memory_bitmap, screen, 0, 0, 0, 0, 320, 200);

	




if(n > 90 || n < 2)
	inc = -inc;
if(n <2){inc =1; n=5;}

}

//----------------------------------------------------------------

   /* free the memory bitmap */
   destroy_bitmap(memory_bitmap);

   readkey();
   return 0;
}}}
