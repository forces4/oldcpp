
#include <math.h>
#include <stdlib.h>
#include <GL/glut.h>
#include <conio.h>
#include <iostream.h>
#include <stdio.h>


GLuint theBoard;
GLuint theBox;

const float PI=3.14159;

int cx=0, cy=50/20, cz=300/20;//camera coordinates
int lx=0,ly=0,lz=200/20;//look at coordinates
float direction=PI/2; //radians
int up=0, down=0, left=0, right=0;
int sqdone=0;

void makeboard(void)
{

if(sqdone==0)
{
static GLint square[15876];
//---[ 3color, 3normal, x,y,z,]*21*21


int col=1;
int vcount=0;
GLint r=0,g=0,b=0;    //red green blue
GLint xcoo, ycoo, zcoo;


for(int z=-10; z<=10; z++)
{
	for(int x=-10;x<=10;x++)
	{
		for(int corner=0,corner<=3, corner++)
		{
		//-------------------colors---------
		if(col==1)
		{
		r=1;g=0;b=0;	
	        //glColor3f(1, 0, 0);
		}

		else
		{
		r=1;g=1;b=0;
		//glColor3f(1,1,0);
		} 

		//start setting array values---------------------
		

		square[vcount]=r;
		vcount++;
		square[vcount]=g;
		vcount++;
		square[vcount]=b;
		vcount++;

		
		
		//---------------------normals--------------
		square[vcount]=0;
		vcount++;
		square[vcount]=1;
		vcount++;
		square[vcount]=0;
		vcount++;
		
		//--------------------XYZ Coodinates-------------
		
		if(corner==0){xcoo=x*20/4; ycoo=-50/4; zcoo=-z*20/4;}//lower left
		if(corner==1){xcoo=x*20/4+20/4; ycoo=-50/4; zcoo=-z*20/4;}//lower right
		if(corner==2){xcoo=x*20/4+20/4; ycoo=-50/4; zcoo=-z*20/4 -20/4;}//upper right
		if(corner==3){xcoo=x*20/4; ycoo=-50/4; zcoo=-z*20/4;}//uper left

		square[vcount]=xcoo;
		vcount++;
		square[vcount]=ycoo;
		vcount++;
		square[vcount]=zcoo;
		vcount++;
		

		}//----------end corner for loop------------


	
		
/*-----------------------------------------------

*/-----------------------------------------------------

		col=-col;
	
	}//---------end x loop

}//---------end zloop
}//------------------------------end sqdone if--------------
sqdone=1;

//---[ 3color, 3normal, x,y,z,]*21*21


glColorPointer(3, GL_INT, 9*sizeof(GLint), &square[0]);
glNormalPointer(3, GL_INT, 9*sizeof(GLint), &square[3]);
glColorPointer(3, GL_INT, 9*sizeof(GLint), &square[6]);

theBoard = glGenLists(1);
glNewList(theBoard, GL_COMPILE);

for(int count=0; count<(21*21); count++)
{


		glBegin(GL_QUADS);
		glArrayElement(count);
		
		glEnd();
	
}//-------------------end count loop-----
glEndList();


}//---------end makeboard-----------------------









float spin =0;

void idle(void)//---------------------------Begin IDLE-------------
{
spin = spin + 5;
if(spin >360*5)
	spin = 0 ;


int sdis=(2)*sin(direction);
int cdis=(2)*cos(direction);


    //down
	if(down) {	
		cz+=sdis;
		lz+=sdis;
		cx-=cdis;
		lx-=cdis;
		
		
	}
	
	//up
	if(up) {
		cz-=sdis;
		lz-=sdis;
		cx+=cdis;
		lx+=cdis;
		
	}
	//left
	if(left){
		direction+=.2;
		lx=cx + (100/10)* cos(direction);
		lz=cz - (100/10)* sin(direction);
		
	}


	//right
	if(right){
		direction-=.2;
		lx=cx + (100/10)* cos(direction);
		lz=cz - (100/10)* sin(direction);
		
	}

glutPostRedisplay(); 
}

//---------------------------------------END IDLE---------------------------





void spincam(void)
{

spin = spin + .01;
if(spin >2)
	spin = spin -2 ;
glutPostRedisplay(); 

}

void init(void)
{
	glClearColor(0.0,0.0,0.0,0.0);
	glShadeModel(GL_SMOOTH);
	makeboard();
	glutIgnoreKeyRepeat(1);
	glEnableClientState(GL_NORMAL_ARRAY);
	glEnableClientState(GL_VERTEX_ARRAY);

}




//------------------------------------Begin Display-------------------------
void
display(void)
{
    glClear(GL_COLOR_BUFFER_BIT |GL_DEPTH_BUFFER_BIT);

    glColor3f(1.0,1.0,1.0);
	glLoadIdentity();//clears matrix

gluLookAt(cx, cy, cz
		, lx, ly, lz, 0.0, 1.0, 0.0);

//	gluLookAt(cos(spin * 3.141592) *180, 0.0, sin(spin *3.131592) *180
//		, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
	// (camera at x,y,z, aimed at 0,0,0, up is 0,1,0)
	glScalef(.1,.1,.1);
//glutWireCube(1.0);


	glPolygonMode(GL_FRONT, GL_FILL);
	glPolygonMode(GL_BACK, GL_FILL);

glCallList(theBoard);

theBox=glGenLists(2);
glNewList(theBox, GL_COMPILE);



glPushMatrix();
glRotatef(spin,0,1,0);



    glBegin(GL_QUADS);

// back  face

glColor3f(1, 0, 0);
	glNormal3f(0,0,-1);
	glVertex3i(50/4, 50/4,-50/4);
	glNormal3f(0,0,-1);
	glVertex3i(50/4, -50/4,-50/4);
	glNormal3f(0,0,-1);
	glVertex3i(-50/4, -50/4,-50/4);
	glNormal3f(0,0,-1);
	glVertex3i(-50/4, 50/4,-50/4);

// face left

glColor3f(0, 1, 0);
	glNormal3f(-1,0,0);
	glVertex3i(-50/4, -50/4,50/4);
	glNormal3f(-1,0,0);
	glVertex3i(-50/4, 50/4,50/4);	
	glNormal3f(-1,0,0);
	glVertex3i(-50/4, 50/4,-50/4);
	glNormal3f(-1,0,0);
	glVertex3i(-50/4, -50/4,-50/4);

// front face

glColor3f(0, 0, 1);
	glNormal3f(0,0,1);
    glVertex3i(50/4, -50/4,50/4);
	glNormal3f(0,0,1);
	glVertex3i(50/4, 50/4,50/4);	
	glNormal3f(0,0,1);
	glVertex3i(-50/4, 50/4,50/4);	
	glNormal3f(0,0,1);
	glVertex3i(-50/4, -50/4,50/4);

//  right  face

glColor3f(0, 1, 1);
	glNormal3f(1,0,0);
    glVertex3i(50/4, -50/4,-50/4);
	glNormal3f(1,0,0);
	glVertex3i(50/4, 50/4,-50/4);	
	glNormal3f(1,0,0);
	glVertex3i(50/4, 50/4,50/4);
	glNormal3f(1,0,0);
	glVertex3i(50/4, -50/4,50/4);


    glEnd();


glPopMatrix();

glPushMatrix();
glTranslatef(-100/4,0,0);
glutWireTorus(99/4,101/4,20,1);
glPopMatrix();

glPushMatrix();
glRotatef(-spin,0,1,0);
	glTranslatef(100/4,0,0);
	
    glColor3f(1,0,1);
	glutSolidCube(30/4);

glPushMatrix();
glTranslatef(-40/4,0,0);
glutWireTorus(39/4,41/4,20,1);
glPopMatrix();

glRotatef(3*spin,0,1,0);
//glRotatef(spin,1,0,0);
	glTranslatef(40/4,0,0);
	
    glColor3f(1,0,0);
	glutSolidCube(3);

glPopMatrix();
//light

glPushMatrix();

float pos[]={0,0,0,.1};

glRotatef(.2 * spin,0,1,0);

glTranslatef(200/4,50/4,50/4);
glLightfv(GL_LIGHT0, GL_POSITION, pos);

glDisable(GL_LIGHTING);
glColor3f(1,1,1);

glutWireSphere(20/4,20,20);
glEnable(GL_LIGHTING);
glPopMatrix();

glEndList();

glCallList(theBox);

glutSwapBuffers();
	 glFlush();
}


//-------------------------------------End Display--------------------------

void
reshape(int width, int height)
{
    glViewport(0, 0, width, height);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    //glOrtho(0, 100, 0, 100, -100, 100);
	glFrustum(-1, 1 ,-1 ,1, 1.5, 100);
	//gluPerspective(60.0,1.0,1.5,20);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

	glEnable(GL_DEPTH_TEST);
	float pos[]={100/4,100/4,100/4,1};
	glLightfv(GL_LIGHT0, GL_POSITION, pos);
  glEnable(GL_COLOR_MATERIAL);
  glEnable(GL_LIGHTING);
  glEnable(GL_LIGHT0);
}



void
keyboard(unsigned char key, int x, int y)
{   	
	if (key ==27) {
        exit(0);
	   }
}



void
special(int key, int x, int y)
{
  switch (key) {
  
  case GLUT_KEY_UP:
    up = 1;
    
    break;
  case GLUT_KEY_LEFT:
    left = 1;
    
    break;
  case GLUT_KEY_RIGHT:
    right = 1;
    
    break;
  case GLUT_KEY_DOWN:
    down = 1;
    break;
  }
}


void
specialup(int key, int x, int y)
{
  switch (key) {
  case GLUT_KEY_UP:
    up = 0;
    break;
  case GLUT_KEY_LEFT:
    left = 0;
    break;
  case GLUT_KEY_RIGHT:
    right = 0;
    break;
  case GLUT_KEY_DOWN:
    down = 0;
    break;
  }
}


int
main(int argc, char** argv)
{	
	glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB |GLUT_DEPTH);
    glutInitWindowSize(500, 500);
    glutInitWindowPosition(50, 50);

    glutCreateWindow(argv[0]);
	init();
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutKeyboardFunc(keyboard);
    //glutKeyboardUpFunc(keyup);
    glutSpecialFunc(special);
    glutSpecialUpFunc(specialup);
	glutIdleFunc(idle);
    glutMainLoop();
    return 0;
}

