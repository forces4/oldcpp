

#include "allegro.h"
#include <stdlib.h>
#include <math.h>
#include <stdio.h>

int xmax =1024;
int ymax=768;
int zmax=1000;


class point
{

	public:

	 point();
	

	// member functions

	void move_rand(int distance);
	void move_x(float distance);
	void move_y(float distance);
	void move_z(float distance);
	void plot();
	void zplot();
	void unplot();
	void zunplot();
	void set_x(float coordinate);
	void set_y(float coordinate);
	void set_z(float coordinate);

	void set_xvel(float speed);
	void set_yvel(float speed);
	void set_zvel(float speed);

	void set_xacl(float rate);
	void set_yacl(float rate);
	void set_zacl(float rate);

	float gx();
	float gy();
	float gz();

	float gxvel();
	float gyvel();
	float gzvel();
	
	float gxacl();
	float gyacl();
	float gzacl();

int colr;
	private:

	float x_pos;
	float y_pos;
	float z_pos;
	
	float x_vel;
	float y_vel;
	float z_vel;
	
	float x_acl;
	float y_acl;
	float z_acl;

	float mass;
	
};

point::point()
{
	x_pos = random() % xmax;
	y_pos = random() % ymax;
	z_pos = random() % zmax;

	x_vel = 0;
	y_vel = 0;
	z_vel = 0;

	x_acl = 0;
	y_acl = 0;
	z_acl = 0;
	mass = 1;

	colr = random () % 50; //if(colr % 3 == 1)colr =0;
	//colr = 2;
}

void point::move_rand(int distance)
{
	int mx, my, mz;

	mx = random ()% (distance) - (distance-(random()%2))/2 ;
 	my = random ()% (distance) - (distance-(random()%2))/2 ;
	mz = random ()% (distance) - (distance-(random()%2))/2 ;


	if ((x_pos + mx) < 2 || (x_pos + mx) > xmax)
		x_pos = x_pos - mx;
	else x_pos = x_pos + mx;

	if ((y_pos + my) < 2 || (y_pos + my) > ymax)
		y_pos = y_pos - my;
	else y_pos = y_pos + my;

	if ((z_pos + mz) < 2 || (z_pos + mz) > zmax)
		z_pos = z_pos - mz;
	else z_pos = z_pos + mz;

}

void point::move_x(float distance)
{
	if ((x_pos + distance < 2)|| (x_pos +distance > xmax))
	{
		//x_pos = x_pos - distance;
		x_vel = -x_vel;
		
	}
	else x_pos = x_pos + distance;
}

void point::move_y(float distance)
{
	if ((y_pos + distance < 2)|| (y_pos +distance > ymax))
	{
		//y_pos = y_pos - distance;
		y_vel = -y_vel;
		
	}	
	else y_pos = y_pos + distance;
}

void point::move_z(float distance)
{
	if ((z_pos + distance < 2)|| (z_pos +distance > zmax))
	{
		//z_pos = z_pos - distance;
		z_vel = -z_vel;
		

	}
	else z_pos = z_pos + distance;
}

void point::set_x(float coordinate)
{
	if (!( coordinate < 2) || (coordinate > xmax))
	 x_pos = coordinate;

}

void point::set_y(float coordinate)
{
	if (!( coordinate < 2) || (coordinate > ymax))
	 y_pos = coordinate;
}

void point::set_z(float coordinate)
{
	if (!( coordinate < 2) || (coordinate > zmax))
	 z_pos = coordinate;
}


void point::set_xvel(float speed)
{
	
	 x_vel = speed;
}

void point::set_yvel(float speed)
{
	
	 y_vel = speed;
}

void point::set_zvel(float speed)
{
	
	 z_vel = speed;
}


void point::set_xacl(float rate)
{
	
	 x_acl = rate;
}

void point::set_yacl(float rate)
{
	
	 y_acl = rate;
}

void point::set_zacl(float rate)
{
	
	 z_acl = rate;

}

void point::plot()
{
putpixel(screen, int(x_pos), int(y_pos), colr);

}
void point::zplot()
{
circle(screen, int(x_pos), int(y_pos), int(z_pos/50), colr);
}


void point::unplot()
{

putpixel(screen, int(x_pos), int(y_pos), 15);
}
void point::zunplot()
{
circle(screen, int(x_pos), int(y_pos), int(z_pos/50), 15);
}



float point::gx()
{
return (x_pos);
}

float point::gy()
{
return (y_pos);
}

float point::gz()
{
return (z_pos);
}


float point::gxvel()
{
return(x_vel);
}

float point::gyvel()
{
return(y_vel);
}

float point::gzvel()
{
return(z_vel);
}


float point::gxacl()
{
return(x_acl);
}

float point::gyacl()
{
return(y_acl);
}

float point::gzacl()
{
return(z_acl);
}







