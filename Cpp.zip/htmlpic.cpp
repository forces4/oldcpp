#include <iostream.h>
#include <rand.h>
#include <math.h>
#include <stdlib.h>
#include <fstream.h>

#include "allegro.h"




void main()
{

allegro_init();
install_mouse();
install_timer();


install_keyboard(); 
 set_gfx_mode(GFX_AUTODETECT, 640, 480, 1024, 1024);
   set_pallete(desktop_pallete);

extern volatile char key[128]; // keyboard flags--if (key[KEY_SPACE])



//-----------------------------------------------------------------



int clr;
int shape=45;
int sdx=1;
int flag=0;
int type=8;
int a,b;



show_mouse(screen);


while ( !flag){
for(int type=1;type<=6 && !flag;){


for(int y=3;y<480 && !flag;y++)
{


	for(int x=3;x<640;x++)
	{
	if(type==6)clr=((x^2+y*x -2 * shape))/shape;//psycostars
	if(type==5)clr=((shape * x^2 + shape * y^2)/shape);//canopy
	if(type==4)clr=(x*x + y*y)/shape;//atomics
	//if(type==5)clr=(x*mouse_x + y*mouse_y)/shape * y;//mousestars
       	
	if(type==3)clr=( (y^(2))*(x^3) )/(shape); //flower
	if(type==2)clr=( (y^x)*(x^y) )/(x+y * shape); //fire & water
	if(type==1)clr=( (y*y*x*x))/(shape); //linolium
	
	putpixel(screen, x, y, clr);




 	//putpixel(screen, x,y, clr);

	if(keypressed() ) 
	{
		if( (readkey() >> 8) == KEY_SPACE)type++;
		else flag=1;

	}

	}//--end xfor
	


}//--end yfor


shape+=sdx;
if (shape>100 || shape <2) {sdx=-sdx;if(sdx<0 || key[KEY_SPACE]) type++;}

}//--end typefor

}//--end whilefor 	


}//--------------------------------------end main

