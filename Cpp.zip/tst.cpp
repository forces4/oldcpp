#include <iostream.h>
#include <rand.h>
#include <math.h>

#include "allegro.h"
#include "3dpoint.h"

int main(void)
{
int allegro_init();
int install_timer();

install_mouse();

install_keyboard(); 
 set_gfx_mode(GFX_AUTODETECT, 640, 480, 1024, 1024);
   set_pallete(desktop_pallete);

extern volatile char key[128]; // keyboard flags--if (key[KEY_SPACE])

show_mouse(screen);

do{

scare_mouse();	
unscare_mouse();


}while (! keypressed());	

}

