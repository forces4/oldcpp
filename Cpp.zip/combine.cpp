#include <conio.h>
#include <iostream.h>
#include <stdio.h>
#include <stdlib.h>
#include <fstream.h>
#include <string.h>
#include <istream.h>

const int MAXSTRING = 1000;
typedef char string[MAXSTRING];
char temporary;


void heading();
void combine();
void init(int n);
int isame(int num_rcd);
void assign(int R);
void begin_rec_out();
void copy(int dest, int source);



class big1
{
public:

big1();

string record;

string name;
string price ;
string number;
string url;

string kind ;
string justincase;
string sug_ret ;
string description ;
char *cursor;
char *curs2;
char *hdpt;
int kurs;
int kurs2;
private:


};

big1::big1()
{
	hdpt = record;

}

int num_rcd = 1;
int num_rec = 1;
int maxfields;
int recnum = 1;
int recref = 0;
int rectop =1;
ifstream inFile("original.txt");
ofstream outFile("after.txt");

big1 field[300];


void main(void)
{

heading();



	inFile.getline(field[recref].record, MAXSTRING, '\n');
	
	assign(recref);

while(inFile.good() && ! inFile.eof() && recnum < 301)
{

	

	combine();


}//----end while

}//--------------------------------------------END MAIN---------------------------





void heading()      //----------------------heading------------
{


	string tary;

	
	if(inFile.good() )
	{
        	for(int i=0; i < 3; i++) 
        	{
        		 inFile.getline(tary, MAXSTRING, '\n');
			cout << tary << '\n';
			outFile << tary << '\n';
		}

	}



}//-------------------------------------------END VOID HEADING.----------------------------



//-*************************COMBINE***********************************

void combine()
{

	


	inFile.getline(field[recnum].record, MAXSTRING, '\n');
	
	assign(recnum);


begin_rec_out();


if (!(isame(recnum) ))
{

	outFile << "</font></td></tr><tr><td></td><td></td></tr><td></td>"
	<< "<td></td></tr><td></td><td></td></tr></table>~" << field[recref].justincase
	<< "~" << field[recref].kind
	<< "~" << field[recref].url << '\n';

	copy(recref, recnum);
	recnum = 1;

} //------------------end if--------
else
{


	outFile << "</font></td></tr><tr><td>" << field[recref].kind << "</td><td></td></tr><td>"
	<< field[recnum].kind;
	
	

	recnum++;

	inFile.getline(field[recnum].record, MAXSTRING, '\n');

	assign(recnum);	 

	while(!inFile.eof() && isame(recnum))
	{
	outFile << "</td><td></td></tr><td>" << field[recnum].kind;

	recnum++;

	 inFile.getline(field[recnum].record, MAXSTRING, '\n');

	assign(recnum);


	}//---------------end while

	if(( recnum - recref) > maxfields)
		maxfields = ( recnum - recref);

	rectop = (recnum -1);


	outFile << "</td><td></td></tr></table>~" <<field[recref].justincase 
		<< "~" << field[recref].kind << "~" << field[recref].url;

	for(int i = recref; i <= rectop; i++)
	{
		outFile << '~' << field[i].kind;
	}
	outFile << '\n';

	copy(recref, recnum);
	recref = 0;
	recnum = 1;
	rectop = 0;

}//-------------------END ELSE------


}//---------------******************************-------------------End Combine






int isame(int num_rcd)
{
if(( (strcmp(field[recref].name, field[recnum].name) ==0) && (strcmp(field[recref].price, field[recnum].price) ==0)  ))
	return 1;
else return 0;

}//----------------end isame-------------------





void assign(int R)//-----------------------------------------------begin assign
{


	field[R].kurs = 0;
	field[R].kurs2 = 0;


	//-----------------name------------------
	
	
	while( field[R].record[field[R].kurs] != '~')
	{
		field[R].name[field[R].kurs2] = field[R].record[field[R].kurs];
		

		field[R].kurs++;
		field[R].kurs2++;
	}

	field[R].kurs++;
	field[R].name[field[R].kurs2] = '\0';
	field[R].kurs2 = 0;

//cout << field[R].name << endl;



	while( field[R].record[field[R].kurs] != '~')
	{
		field[R].price[field[R].kurs2] = field[R].record[field[R].kurs];

		field[R].kurs++;
		field[R].kurs2++;
	}
	field[R].kurs++;
	field[R].price[field[R].kurs2] = '\0';
	field[R].kurs2 = 0;
//cout << field[R].price << endl;


	while( field[R].record[field[R].kurs] != '~')
	{
		field[R].number[field[R].kurs2] = field[R].record[field[R].kurs];

		field[R].kurs++;
		field[R].kurs2++;
	}
	
	field[R].kurs++;
	field[R].number[field[R].kurs2] = '\0';
	field[R].kurs2 = 0;
//cout << field[R].number << endl;


//-----------------------------------url

	while( field[R].record[field[R].kurs] != '~')
	{
		field[R].url[field[R].kurs2] = field[R].record[field[R].kurs];

		field[R].kurs++;
		field[R].kurs2++;
	}
	
	field[R].kurs++;
	field[R].url[field[R].kurs2] = '\0';
	field[R].kurs2 = 0;
//cout << field[R].url << endl;



//--------------------------------------end url



	while( field[R].record[field[R].kurs] != '~')
	{
		field[R].kind[field[R].kurs2] = field[R].record[field[R].kurs];

		field[R].kurs++;
		field[R].kurs2++;
	}
	
	field[R].kurs++;
	field[R].kind[field[R].kurs2] = '\0';
	field[R].kurs2 = 0;
//cout << field[R].kind << endl;



//-----------------------------------justincase

	while( field[R].record[field[R].kurs] != '~')
	{
		field[R].justincase[field[R].kurs2] = field[R].record[field[R].kurs];

		field[R].kurs++;
		field[R].kurs2++;
	}
	
	field[R].kurs++;
	field[R].justincase[field[R].kurs2] = '\0';
	field[R].kurs2 = 0;




//--------------------------------------end justincase



	while( field[R].record[field[R].kurs] != '~')
	{
		field[R].sug_ret[field[R].kurs2] = field[R].record[field[R].kurs];

		field[R].kurs++;
		field[R].kurs2++;
	}
	field[R].kurs++;
	field[R].sug_ret[field[R].kurs2] = '\0';
	field[R].kurs2 = 0;
//cout << field[R].sug_ret << endl;




	while( field[R].record[field[R].kurs] != '\0')
	{
		field[R].description[field[R].kurs2] = field[R].record[field[R].kurs];

		field[R].kurs++;
		field[R].kurs2++;
	}
	field[R].kurs = 0;
	field[R].description[field[R].kurs2] = '\0';
	field[R].kurs2 = 0;




	


}//-----------=------------------------------------------------end assign



void begin_rec_out()/////---------------FIRST PART OF RECORD---------
{

outFile << field[recref].name << '~' << field[recref].price << "~" << field[recref].number
<< "~<br><center><table border=0 cellspacing=0 cellpadding=0><tr><td><img src=\""
<< field[recref].url << "�></td></tr></table>"
<< "</center><br><br><center><font size=�+2�>" << field[recref].name << "</font></center><br><br><font size=�+1�>"
<< field[recref].description << "</font><br>Suggested Retail: " << field[recref].sug_ret 
<< "<br><table border=�1� cellspacing=�0� cellpadding=�0�><tr><td><font size=�+3�>"
<< "Color/Size</font></td><td><font size=�+3�>Quanitiy in Stock";





}// ------END begin_rec_out-----



void copy(int dest, int source)   // -----------------------------------COPY-------------
{



strcpy( field[dest].record, field[source].record);
strcpy( field[dest].name, field[source].name);
strcpy( field[dest].price , field[source].price);
strcpy( field[dest].number, field[source].number);
strcpy( field[dest].url, field[source].url);
strcpy( field[dest].kind, field[source].kind);
strcpy( field[dest].justincase, field[source].justincase);
strcpy( field[dest].sug_ret , field[source].sug_ret);
strcpy( field[dest].description , field[source].description);



}//------------------END COPY


