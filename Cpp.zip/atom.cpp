#include "3dPOINT.H"
#include <stdlib.h>
#include <iostream.h>
#include <rand.h>
#include <math.h>

int numatoms = 1;


void main()
{

point atom[numatoms];


atom.set_x[0](320);
atom.set_y[0](240);
atom.set_z[0](200);




int install_timer();
	int allegro_init();

	install_keyboard(); 
 	set_gfx_mode(GFX_AUTODETECT, 640, 480, 1024, 1024);
  	 set_pallete(desktop_pallete);

	extern volatile char key[128]; // keyboard flags--if (key[KEY_SPACE])

	


	floodfill(screen, 100, 100, 25);


 	

