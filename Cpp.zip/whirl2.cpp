#include "point.h"
#include <iostream.h>
#include <math.h>


int dir = 1;

int trails = 0;


int numpoints = 500;
float k =.0;
int xmov = 320;
int ymov = 240;
int xfact = 10;
int yfact = 20;
	char x;

point history[601][200];

	int a=1;
	



void spin();

void main()
{
	x= 'k';	
	

	int install_timer();
	int allegro_init();

	install_keyboard(); 
 	set_gfx_mode(GFX_AUTODETECT, 640, 480, 1024, 1024);
  	 set_pallete(desktop_pallete);

	extern volatile char key[128]; // keyboard flags--if (key[KEY_SPACE])

	


	floodfill(screen, 100, 100, 25);


spin();	




}//--------------end main------------------------------------------


void spin()
{

point whirl[numpoints];



	while(! keypressed())
	{

xfact = (random () % 50) +1;
yfact = (random () % 10) +1;
floodfill(screen, 100, 100, 25);


	//k = -k;  dir = -dir;
	for (float i =  random() % 40 - 20 ; i  < random() % 100; i+= .0001)
	{

	dir = -dir;
		for (int j = 1; j < numpoints; j++)
		{
			
			whirl[j].set_x(xmov + dir * j * cos((j/xfact) * i)/2);
			
			//history[j][int(i)].set_x(xmov + dir * j * int(cos((j/xfact) * i)/2));

			 
			whirl[j].set_y(ymov + j * sin((j/yfact) * i)/2 );
			if(whirl[j].gy() < 0)
				whirl[j].set_y(-(ymov + j * sin((j/yfact) * i)/2));
			

			//history[j][int(i)].set_y(ymov + j * sin((j/yfact) * i)/2);

			whirl[j].plot();
			//if(j>10)history[j-10][int(i)].unplot();
			if(j== int(random()%40))whirl[j].unplot();


		
		
	if(keypressed())
		j = numpoints;

		}


//xmov = int(640 * sin(i/(random () % 10)));

	ymov = int(400 * sin(i/(random () % 3)));
	if (ymov < 0) ymov = -ymov;
	if(keypressed())
		i = 30;
	}

	}






}
