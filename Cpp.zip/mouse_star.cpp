#include <iostream.h>
#include <rand.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>

#include "allegro.h"
#include "3dpoint.h"



void main()
{

allegro_init();
install_mouse();
install_timer();


install_keyboard(); 
 set_gfx_mode(GFX_AUTODETECT, 640, 480, 1024, 1024);
   set_pallete(desktop_pallete);

extern volatile char key[128]; // keyboard flags--if (key[KEY_SPACE])



//-----------------------------------------------------------------

point first;

int clr=0;
int shape=45;
int sdx=1;


show_mouse(screen);


do{

for(int y=1;y<480;y++)
{


	for(int x=1;x<640;x++)
	{
	clr=(x*mouse_x + y*mouse_y)/shape * y;
	putpixel(screen, x, y, clr/100);
	
	}




}
// shape+=sdx;
if (shape>200 || shape <20) sdx=-sdx;


}while (! keypressed());	


}//--------------------------------------end main

