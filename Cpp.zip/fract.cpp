#include "3dpoint.h"
#include <iostream.h>
#include <math.h>
#include <rand.h>

const int BLACK = 15;
const int MAXL = 13;
void c_curve(int x1, int y1, int x2, int y2, int level, int color);


void main()
{
	

	int install_timer();
	int allegro_init();

	install_keyboard(); 
 	set_gfx_mode(GFX_AUTODETECT, 640, 480, 1024, 1024);
  	 set_pallete(desktop_pallete);

	extern volatile char key[128]; // keyboard flags--if (key[KEY_SPACE])

	floodfill(screen, 100, 100, 25);


int temp;


while(!keypressed())//      (readkey() & 0xff) != 'd')
{
for(int i=0; i<MAXL; i++)
{	
	c_curve(100, 100, 600, 100, i, i);

//if ((readkey() & 0xff) == 'd')         // by ASCII code
//         printf("You pressed 'd'\n");

for(float k=3; k< 534;k++){}

//if(i>1)
//	c_curve(200, 200, 400, 200, i-1, BLACK);
//else 
//c_curve(200, 200, 400, 200, MAXL-1, BLACK);

}
}
}//--------------end main------------------------------------------


void c_curve(int x1, int y1, int x2, int y2, int level, int color)
{

int xm, ym;

if (level==0)
    line(screen, x1, y1,  x2, y2, int (RND() * 20));

else
{
xm = (x1 + x2)/2;
ym = (y1 + y2)/2;


c_curve(xm, ym, x2, ym, level-1, color);

c_curve(xm, y1, xm, ym, level-1, color);
c_curve(xm, ym, xm, y2, level-1, color);

}

}


