


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
//#include <windows.h>
#include <GL/glut.h>

void
reshape(int width, int height)
{
  
    glViewport(0, 0, width, height);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 2, 0, 2, -1, 1);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glEnable(GL_COLOR_MATERIAL);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
}

void
draw(void)
{
    glClear(GL_COLOR_BUFFER_BIT);

    glColor3ub(255, 255, 255);
    glBegin(GL_TRIANGLES);
    glNormal3f(0, 0, 1);
    glColor3ub(255, 0, 0);
    glVertex2i(1, 2);
    glColor3ub(0, 255, 0);
    glVertex2i(0, 0);
    glColor3ub(0, 0, 255);
    glVertex2i(2, 0);
    glEnd();

    glutSwapBuffers();
}



void
display(void)
{
    draw();
    
}

void
keyboard(unsigned char key, int x, int y)
{
    if (key == 27) {
        exit(0);
    }
}

int
main(int argc, char** argv)
{   glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowPosition(50, 50);
    glutInitWindowSize(320, 320);
    

    glutCreateWindow("Area");
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutKeyboardFunc(keyboard);

    glutMainLoop();
    return 0;
}
