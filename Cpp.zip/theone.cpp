#include <conio.h>
#include <iostream.h>
#include <stdio.h>
#include <stdlib.h>
#include <fstream.h>
#include <string.h>




void main(void)
{

const rlength = 10000;

char record[rlength];
char rec_next[rlength];

char name[100];//-----------
char name_next[100];
char price_num[100];
char price_next[100];
char trash[rlength];
char kind[100];


int num_records;
int maxfields;


ifstream inFile("original.txt");

ofstream ouFile("after.txt");


while(inFile.good() )
{

     
        for(int i=0; i < 3; i++) //----------------------heading------------
        {
        	inFile.getline(record, rlength, '\n');
		outFile << record << '\n';
	}
	
}

while(inFile.good())
{

	inFile.getline(record, rlength, '\n');
	inFile.getline(rec_next, rlength, '\n');

	for(int leter = 0; leter < 100; leter++)//---------get names-------
	{
		if( !(record[leter] == '~') )
		{
			name[leter] = record[leter];
			name[leter +1] = '\0';	
			
		}
		else if (rec_next[leter] == '~')
		{leter = 999}
		
	
		if(leter < 200 && !(rec_next[leter] == '~')  )
		{
			name_next[leter] = record[leter];
			name_next[leter +1] = '\0';	
		}
	}
	

	
//------------------------compare names
     if( strcmp(name, name_next) != 0) 
	{
		outFile << record << endl << rec_next << endl;
	}
	else
	{
		
		for(int leter = strlen(name) -1; leter < 20; leter++)//---------get price-------
		{
			if( !(record[leter] == ' ') )
			{
				price_num[leter - strlen(name)+1] = record[leter];
				price_num[leter - strlen(name)+2] = '\0';	
			
			}
			else if (price_next[leter - strlen(name)+1] == ' ')
			{leter = 999}
		
	
			if( leter < 30 && !(rec_next[leter] == ' ') )
			{
				price_next[leter] = record[leter];
				price_next[leter +1] = '\0';	
			}

		}//end for

   if( strlen(price_num) < 25 )
   {
		//compare --prices-----------------------------

		if (strcmp(price_num, price_next) == 0)
		{
			inFile.getline(trash, rlength, '~');	
			


	}//end else
				





}
