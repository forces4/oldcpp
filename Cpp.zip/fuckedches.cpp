#include <iostream.h>
#include "allegro.h"
#include <string.h>


struct square {

	BITMAP *memory_bitmap;
	char T;//type of piece
	int xpos;//-------------------location on board
	int ypos;//
	int movx;//
	int movy;//



}board[8][8];


square dead[6][8];

square mempictuer[8][2];


const int RED = 224;
const int BLUE = 11;
const int GREEN = 16; 
const int BLACK = 1;
const int WHITE = 255;
const int GREY = 3;
const int MSKED = 0;

int buff_temp = 0;       //-------------color of piece, 0 or 1
int xbox, ybox, scrmspxl;//----------------for higlight
//int xpos[8], ypos[8];// ----------------------grid location on board

//int movx, movy;//------------------------ location of target move to square
int boxcolor = 1;

PALLETE my_pallete;
char pict[200];

BITMAP *scrbuff;

BITMAP *buffer;
BITMAP *ptemp[3];
BITMAP *mousprite;

//-----------------------------------------------------------------




void init();
void make_board();
void draw_board();
void pick_piece();
//int canmove();

for(int y = 0; y<8; y++)
{
	for(int x=0;x<8;x++)
	{
	board[x][y].xpos = x*60; 
	board[x][y].ypos = y*60;
	}


}  // ----------------------------------------------setup position for board


for(int y = 0; y<16; y++)
{	
	for(int x=0; x<6;x++)
	{
	dead[x][y].xpos = x*30 +(8*60); 
	dead[x][y].ypos= y*30;
	}  

}// ----------------------------------------------setup position for deadzone


for(int y = 0; y<2; y++)
{	
	for(int x=0; x<8; x++)
	{
	mempicture[x][y].xpos = x*80 +10 ; 
	mempicture[x][y].ypos= y*60;
	}  

}// --setup position grid for picture buffer



int main(int argc, char *argv[])//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
{
replace_filename(pict, argv[0], "chess3.bmp", sizeof(pict));



init();
make_board();	
draw_board();	
pick_piece();



save_bitmap("dump.bmp", screen, my_pallete);
//----------------------------------------------------------------

	for(int n = 0; n < 8 ; n++)
	{	
		for(int m = 0; m < 8 ;m++)
		{
		destroy_bitmap(board[n][m].memory_bitmap);
		}
	}

	for(int n = 0; n < 18 ; n++)
	{	
		for(int m = 0; m < 6;m++)
		{
		destroy_bitmap(dead[n][m].memory_bitmap);
		}
	}

	for(int n = 0; n < 2 ; n++)
	{	
		for(int m = 0; m < 8 ;m++)
		{
		destroy_bitmap(mempicture[n][m].memory_bitmap);
		}
	}

destroy_bitmap(scrbuff);

destroy_bitmap(buffer);

for(int n = 0; n<=2 ; n++)
	destroy_bitmap(ptemp[n]);

destroy_bitmap(mousprite);

//The above clears memory for exit-------------------------

   readkey();
   return 0;

}//-----------------------------------------------------------End Main







//-----------------------FUNCTIONS------------------------------

void init()
{
allegro_init();
install_timer();
install_mouse();
install_keyboard(); 

set_gfx_mode(GFX_AUTODETECT, 640, 480, 1024, 1024);
   set_pallete(desktop_pallete);

extern volatile char key[128]; // -------keyboard flags--if (key[KEY_SPACE])


scrbuff = load_bitmap(pict, my_pallete);//--------load picture--------------
set_pallete (my_pallete);

buffer = create_bitmap(560, 120);

for(int n =0 ; n <=2; n++)
	ptemp[n] = create_bitmap(60, 60);

for(int n =0 ; n <=2; n++)
{	
	for(int m =0 ; m <=8; m++)
	{
	mempicture[m][n] = create_bitmap(60, 60);
	}
}

mousprite = create_bitmap(60, 60);


for(int y = 0; y<8; y++){xpos[y] = y*80; ypos[y] = y*60;}  // --setup position grid for pic pieces-
for(int y = 0; y<5; y++){xposdead[y] = y*40; yposdead[y] = y*40;}  // --setup position grid for pic pieces-



blit(scrbuff, buffer, 0, 0, 0, 0, 570, 130);
floodfill(buffer, 1, 1, MSKED);

for(int n =0 ; n <=2; n++)
{	
	for(int m =0 ; m <=8; m++)
	{
	blit(buffer, mempicture[m][n].memory_bitmap, m*80 +10, n*60,
	}
}




show_mouse(screen);

for(int y = 0; y<8; y++)
{xpos[y] = y*80; ypos[y] = y*60;}  // --setup position grid for pic pieces-

for(int y = 0; y<5; y++)
{xposdead[y] = y*40; yposdead[y] = y*40;}  // --setup position grid for dead pic pieces-
}

//------------------------------------MAKE BOARD-----------------------

void make_board()
{
int col = RED;
int colswtch = 0;

	for(int n = 0; n < 8 ; n++)
	{
	
	for(int m = 0; m < 8; m++)
	{
		if(colswtch == 0 && m!=0)
		{
			colswtch = 1;
			col = BLACK;
		}
		
		else if(colswtch == 1 && m!=0)
		{
			colswtch = 0;
			col = RED;
		}
	
		box[m][n].memory_bitmap = create_bitmap(60, 60);
		clear_to_color(box[m][n].memory_bitmap, col);
		
		

	}
	
	}


}

//-----------------------------------------

void draw_board()
{
for(int y = 0; y < 8; y++)
{
	if((y > 1) || (y<6))
		

	for(int x = 0; x < 8; x++)
	{
		if((y > 1) || (y<6))
			box[x][y].T = 'E';

	scare_mouse();
	
	//----------------------pawns------------

	if(y == 1)
	{
		masked_blit(buffer, box[x][y].memory_bitmap, 10, 0, 0, 0, 60, 60);
		box[x][y].T = 'p';
	}
	if(y == 6)
	{
		masked_blit(buffer, box[x][y].memory_bitmap, 10, 60, 0, 0, 60, 60);
		box[x][y].T = 'P';
	}

	//------------------- player pieces-----------------------
	if(y==0)buff_temp = 0;
	if(y==7)buff_temp = 1;
	if(y != 0 && y != 7)buff_temp = -1;
	
	if(buff_temp != -1 && (x == 0 || x == 7))//--------ROOKS--------------
	{
	
		masked_blit(buffer, box[x][y].memory_bitmap, xpos[1]+10, ypos[buff_temp], 0, 0, 60, 60);
		if( y == 7)
			box[x][y].T = 'R';
		if( y == 0)
			box[x][y].T = 'r';
			
	}	
	
	if(buff_temp != -1 && (x == 1 || x == 6))//--------KNIGHTS--------------
	{
		masked_blit(buffer, box[x][y].memory_bitmap, xpos[2]+10, ypos[buff_temp], 0, 0, 60, 60);
		
		if( y == 7)
			box[x][y].T = 'N';
		if( y == 0)
			box[x][y].T = 'n';	
	}

	if(buff_temp != -1 && (x == 2 || x == 5))//--------BISHOPS--------------
	{
		masked_blit(buffer, box[x][y].memory_bitmap, xpos[5]+10, ypos[buff_temp], 0, 0, 60, 60);
		if( y == 7)
			box[x][y].T = 'B';
		if( y == 0)
			box[x][y].T = 'b';	
	}

	if(buff_temp != -1 && (x == 3))//--------QUEENS--------------
	{
		masked_blit(buffer, box[x][y].memory_bitmap, xpos[4]+10, ypos[buff_temp], 0, 0, 60, 60);
		if( y == 7)
			box[x][y].T = 'Q';
		if( y == 0)
			box[x][y].T = 'q';	
	}

	if(buff_temp != -1 && (x == 4))//--------KINGS--------------
	{
		masked_blit(buffer, box[x][y].memory_bitmap, xpos[3]+10, ypos[buff_temp], 0, 0, 60, 60);	
		if( y == 7)
			box[x][y].T = 'K';
		if( y == 0)
			box[x][y].T = 'k';
	}

		

	 blit(box[x][y].memory_bitmap, screen, 0, 0, xpos[x] -(20*x), ypos[y] , 60, 60);

	unscare_mouse();
	}
}

floodfill(screen, 639, 10, BLACK);
}

//-------------------PICK PIECE------------------------------

void pick_piece()
{


for(int stop=1;stop<10;stop+=0)
{

//scrmspxl = getpixel(screen , mouse_x, mouse_y);//color of mouse point

if (mouse_b & 1 && mouse_x <=(60*8) ) 
{



//----------------------------------select box------------------
	for(int y = 0; y < 8; y++)
	{
		for(int x = 0; x < 8; x++)
		{
		if(mouse_x >= xpos[x] -(x*20) ) xbox = x;  //pos[x];
		if(mouse_y >= ypos[y] ) ybox = y;  //pos[y];			
		}
	}

//--------------------------------end select box-----------------
//--------------------------------draw box-----------------------

	
	scare_mouse();
	

	rect(screen, xpos[xbox] + 1 -(xbox*20), ypos[ybox] +1, xpos[xbox]+58 -(xbox*20), ypos[ybox]+59, boxcolor);
	rect(screen, xpos[xbox] + 2 -(xbox*20), ypos[ybox] +2, xpos[xbox]+57 -(xbox*20), ypos[ybox]+58, boxcolor);

	rect(screen, xpos[xbox] + 3 -(xbox*20), ypos[ybox] +3, xpos[xbox]+55 -(xbox*20), ypos[ybox]+56, boxcolor);

	

blit(box[xbox][ybox].memory_bitmap, mousprite, 0, 0, 0, 0, 60, 60);
floodfill(mousprite, 1, 1, MSKED);


set_mouse_sprite(mousprite);
set_mouse_sprite_focus(30, 30);

unscare_mouse();
do{

	boxcolor++;
	if(boxcolor > 254) boxcolor = BLUE;


}while(mouse_b & 1);



	for(int y = 0; y < 8; y++) // -------get second box number
	{
		for(int x = 0; x < 8; x++)
		{
		if(mouse_x >= xpos[x]-(x*20) ) movx = x;
		if(mouse_y >= ypos[y]) movy = y;			
		}
	}
	scare_mouse;
	rect(screen, xpos[xbox] + 1 -(xbox*20), ypos[ybox] +1, xpos[xbox]+58 -(xbox*20), ypos[ybox]+59, boxcolor);
	rect(screen, xpos[xbox] + 2 -(xbox*20), ypos[ybox] +2, xpos[xbox]+57 -(xbox*20), ypos[ybox]+58, boxcolor);

	rect(screen, xpos[xbox] + 3 -(xbox*20), ypos[ybox] +3, xpos[xbox]+55 -(xbox*20), ypos[ybox]+56, boxcolor);

	unscare_mouse();



//------------------------------------------------actually move pieces

if(box[xbox][ybox].T != 'E' && !(box[xbox][ybox].T >'Z' && box[movx][movy].T >'Z')
&& !(box[movx][movy].T !='E' && box[xbox][ybox].T <'Z' && box[movx][movy].T <'Z' ))

//cant be taken by same type or empty square.------------------------------
{

	scare_mouse();

	blit(box[xbox][ybox].memory_bitmap, ptemp[0], 0, 0, 0, 0, 60, 60);
	floodfill(ptemp[0], 1, 1, MSKED);


	clear_to_color(box[xbox][ybox].memory_bitmap, getpixel(screen, xpos[xbox]+4 -xbox*20, ypos[ybox]+4));
	clear_to_color(box[movx][movy].memory_bitmap, getpixel(screen, xpos[movx]+4 -movx*20, ypos[movy]+4));

	masked_blit(ptemp[0], box[movx][movy].memory_bitmap, 0, 0, 0, 0, 60, 60);
	blit(box[xbox][ybox].memory_bitmap, screen, 0, 0, xpos[xbox]-(xbox*20), ypos[ybox] , 60, 60);	
	blit(box[movx][movy].memory_bitmap, screen, 0, 0, xpos[movx]-(movx*20), ypos[movy] , 60, 60);
	unscare_mouse();

	box[movx][movy].T = box[xbox][ybox].T;
	box[xbox][ybox].T = 'E';



blit(box[movx][movy].memory_bitmap, ptemp[0], 0, 0, 0, 0, 60, 60); // ---get piece bmp-------
	floodfill(ptemp[0], 4, 4, MSKED);

	if(movy == 7)
	{
		masked_blit(buffer, ptemp[1], 0, 0, 0, 0, 60, 60);
		floodfill(ptemp[1], 4, 4, MSKED);

		if(box[movx][movy].T == 'p')
		{


		masked_blit(buffer, box[movx][movy].memory_bitmap, xpos[4]+10, ypos[0], 0, 0, 60, 60);
		scare_mouse();	
		blit(box[movx][movy].memory_bitmap, screen, 0, 0, xpos[movx]-20*movx, ypos[movy], 60, 60); 
		unscare_mouse();
		}
	}
	if(movy == 0)
	{
		masked_blit(buffer, ptemp[1], 0, 60, 0, 0, 60, 60);
		floodfill(ptemp[1], 4, 4, MSKED);

		if(box[movx][movy].T == 'P')
		{
		masked_blit(buffer, box[movx][movy].memory_bitmap, xpos[4]+10, ypos[1], 0, 0, 60, 60);
		scare_mouse();
		blit(box[movx][movy].memory_bitmap, screen, 0, 0, xpos[movx]-20*movx, ypos[movy], 60, 60); 
	
		unscare_mouse();
		}
	}

}//end same kind or empty if----------------------
	
set_mouse_sprite(NULL);
 
}//end if mouse button1--------------------------



if(key[KEY_ESC])stop=20; 

}//end stop for loop   

}//----------------------------------end pick piece

/*int viable()
{

}//------------------------------------------end viable
*/
