#include <iostream.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "allegro.h"
#include "3dpoint.h"
void main()
{
allegro_init();
install_mouse();
install_timer();
install_keyboard(); 
 set_gfx_mode(GFX_AUTODETECT, 640, 480, 1024, 1024);
   set_pallete(desktop_pallete);
extern volatile char key[128]; // keyboard flags--if (key[KEY_SPACE])
//-----------------------------------------------------------------
int clr=0;int shape=1;int sdx=1;do{for(int y=1;y<480;y++){for(int x=1;x<640;x++){
	clr=((x^2+y+x -(2 * shape)))/shape;putpixel(screen, x, y, clr);}}shape+=sdx;if (shape>200 || shape <2) sdx=-sdx;

}while (! keypressed());
}//--------------------------------------end main

