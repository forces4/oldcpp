#include <iostream.h>
#include <rand.h>
#include "point.h"
//#include "chess.h"
#include "allegro.h"

const int RED = 224;
const int BLUE = 11;
const int GREEN = 16;
const int BLACK = 1;
const int WHITE = 255;
const int GREY = 3;
const int MSKED = 0;
int buff_temp = 0;       //-------------color of piece, 0 or 1
int xbox, ybox, scrmspxl;
int xpos[8], ypos[8];

PALLETE my_pallete;
char pict[200];

BITMAP *scrbuff;
BITMAP *memory_bitmap[8][8];//80 squares in mem.
BITMAP *buffer;

//-----------------------------------------------------------------




void init();
void make_board();
void draw_board();
void pick_piece();





int main(int argc, char *argv[])//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
{




init();
make_board();	
draw_board();	
pick_piece();



//save_bitmap("dump.bmp", buffer, my_pallete);

	for(int n = 0; n < 8 ; n++)
	{
	
	for(int m = 0; m < 8 ;m++)
	{

	destroy_bitmap(memory_bitmap[n][m]);
	}
	}


destroy_bitmap(scrbuff);

destroy_bitmap(buffer);


   readkey();
   return 0;

}//-----------------------------------------------------------
//-----------------------FUNCTIONS------------------------------

void init()
{
allegro_init();
install_timer();
install_mouse();
install_keyboard(); 

set_gfx_mode(GFX_AUTODETECT, 640, 480, 1024, 1024);
   set_pallete(desktop_pallete);

extern volatile char key[128]; // -------keyboard flags--if (key[KEY_SPACE])

replace_filename(pict, argv[0], "chess2.bmp", sizeof(pict));
scrbuff = load_bitmap(pict, my_pallete);//--------load picture--------------
set_pallete (my_pallete);

buffer = create_bitmap(560, 120);

blit(scrbuff, buffer, 0, 0, 0, 0, 570, 130);
floodfill(buffer, 1, 1, MSKED);
show_mouse(screen);

for(int y = 0; y<8; y++){xpos[y] = y*80; ypos[y] = y*60;}  // --setup position grid-

}

//------------------------------------MAKE BOARD-----------------------

void make_board()
{
int col = RED;
int colswtch = 0;

	for(int n = 0; n < 8 ; n++)
	{
	
	for(int m = 0; m < 8; m++)
	{
		if(colswtch == 0 && m!=0)
		{
			colswtch = 1;
			col = BLACK;
		}
		
		else if(colswtch == 1 && m!=0)
		{
			colswtch = 0;
			col = RED;
		}
	
		memory_bitmap[m][n] = create_bitmap(80, 60);
		clear_to_color(memory_bitmap[m][n], col);
		floodfill(memory_bitmap[m][n], 10, 10, col);
		

	}
	
	}


}

//-----------------------------------------

void draw_board()
{
for(int y = 0; y < 8; y++)
{

	for(int x = 0; x < 8; x++)
	{
	scare_mouse();
	
	//----------------------pawns------------

	if(y == 1)
		masked_blit(buffer, memory_bitmap[x][y], 0, 0, 0, 0, 80, 60);
	if(y == 6)
		masked_blit(buffer, memory_bitmap[x][y], 0, 60, 0, 0, 80, 60);


	//------------------- player pieces-----------------------
	if(y==0)buff_temp = 0;
	if(y==7)buff_temp = 1;
	if(y != 0 && y != 7)buff_temp = -1;
	
	if(buff_temp != -1 && (x == 0 || x == 7))//--------ROOKS--------------
	{
	
		masked_blit(buffer, memory_bitmap[x][y], xpos[1], ypos[buff_temp], 0, 0, 80, 60);	
	}	
	
	if(buff_temp != -1 && (x == 1 || x == 6))//--------KNIGHTS--------------
	{
		masked_blit(buffer, memory_bitmap[x][y], xpos[2], ypos[buff_temp], 0, 0, 80, 60);	
	}

	if(buff_temp != -1 && (x == 2 || x == 5))//--------BISHOPS--------------
	{
		masked_blit(buffer, memory_bitmap[x][y], xpos[5], ypos[buff_temp], 0, 0, 80, 60);	
	}

	if(buff_temp != -1 && (x == 3))//--------QUEENS--------------
	{
		masked_blit(buffer, memory_bitmap[x][y], xpos[4], ypos[buff_temp], 0, 0, 80, 60);	
	}

	if(buff_temp != -1 && (x == 4))//--------KINGS--------------
	{
		masked_blit(buffer, memory_bitmap[x][y], xpos[3], ypos[buff_temp], 0, 0, 80, 60);	
	}

	
	blit(memory_bitmap[x][y], screen, 0, 0, xpos[x], ypos[y] , 80, 60);
	unscare_mouse();
	}
}
}

//-------------------PICK PIECE------------------------------

void pick_piece()
{
do{

//scrmspxl = getpixel(screen , mouse_x, mouse_y);//color of mouse point

if (mouse_b & 1) 
{
	scare_mouse();

	//cout << scrmspxl << endl;
	//floodfill(screen, mouse_x, mouse_y, MSKED);
	

//----------------------------------select box------------------
	for(int y = 0; y < 8; y++)
	{
		for(int x = 0; x < 8; x++)
		{
		if(mouse_x >= xpos[x]) xbox = xpos[x];
		if(mouse_y >= ypos[y]) ybox = ypos[y];			
		}
	}
//--------------------------------end select box-----------------
//--------------------------------draw box-----------------------

rect(screen, xbox + 1, ybox +1, xbox+79, ybox+59, GREEN);


	unscare_mouse();
}


}while (! keypressed());

}

