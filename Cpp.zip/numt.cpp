#include <conio.h>
#include <iostream.h>
#include <stdio.h>
#include <stdlib.h>
#include <fstream.h>
#include <string.h>
#include <istream.h>



const int MAXSTRING =10000;
typedef char string[MAXSTRING];
char temporary;



void combine();
void init(int n);
int isame(int num_record);

string trshy;

class big1
{
public:

big1();

string record;

string trash;

string name;
string price ;
string number;
string kind ;
string sug_ret ;
string description ;
char *cursor;
char *curs2;
char *hdpt;
private:


};
big1::big1()
{
	hdpt = record;


}

int num_record = 1;
int maxfields;

ifstream inFile("original.txt");
ofstream outFile("after.txt");




big1 field[100];


void main(void)
{



//-*************************START ROUTINE*********************************
string tary;

	
	if(inFile.good() )//--------------HEADING
	{
        	for(int i=0; i < 3; i++) 
        	{
        		 inFile.getline(tary, MAXSTRING, '\n');
			cout << tary << '\n';
			outFile << tary << '\n';
		}

	}




cout << " after heading" << endl;


inFile.getline(trshy, MAXSTRING, '\n');

field[7].record = trshy;

cout << "trash" << field[7].record;

inFile.getline(field[0].record, MAXSTRING, '\n');

cout << "after first getline";

cout << field[0].record << "field one!!!!!!!!!!!!!!!!!" << "jjjjjjj" ;

cout << "lksfjlkasjfkljasfjklafkjjf";	

while(inFile.good() && ! inFile.eof())
{

	

	 inFile.getline(field[1].record, MAXSTRING, '\n');
	cout << field[1].record;


for(int nxt = 0; nxt < 2; nxt++)
{
	
	


	field[nxt].cursor = field[0].hdpt;
 

 	field[nxt].curs2 = field[nxt].name;
	while( *(field[nxt].cursor) != '~' )
	{
		*(field[nxt].curs2) = *(field[nxt].cursor);
		field[nxt].cursor++;
		field[nxt].curs2++;
	}
	field[nxt].cursor++;


	 field[nxt].curs2 = field[nxt].price;
	while( *(field[nxt].cursor) != '~' )
	{
		*(field[nxt].curs2) = *(field[nxt].cursor);
		field[nxt].cursor++;
		field[nxt].curs2++;
	}
	field[nxt].cursor++;

	 field[nxt].curs2 = field[nxt].number;
	while( *(field[nxt].cursor) != '~' )
	{
		*(field[nxt].curs2) = *(field[nxt].cursor);
		field[nxt].cursor++;
		field[nxt].curs2++;
	}field[nxt].cursor++;
	field[nxt].cursor++;

	 field[nxt].curs2 = field[nxt].kind;
	while( *(field[nxt].cursor) != '~' )
	{
		*(field[nxt].curs2) = *(field[nxt].cursor);
		field[nxt].cursor++;
		field[nxt].curs2++;
	}field[nxt].cursor++;
	field[nxt].cursor++;


	 field[nxt].curs2 = field[nxt].sug_ret;
	while( *(field[nxt].cursor) != '~' )
	{
		*(field[nxt].curs2) = *(field[nxt].cursor);
		field[nxt].cursor++;
		field[nxt].curs2++;
	}field[nxt].cursor++;

	 field[nxt].curs2 = field[nxt].description;
	while( *(field[nxt].cursor) != '\n' )
	{
		*(field[nxt].curs2) = *(field[nxt].cursor);
		field[nxt].cursor++;
		field[nxt].curs2++;
	}
	

cout << "name" << field[nxt].name<< endl << field[nxt].price ;



	
}//----------------------end for
	 combine();

}//----------end while

cout << maxfields;

inFile.close();
outFile.close();

}//-------------------------------------END MAIN.-------------------------------------





//-*************************COMBINE***********************************


void combine()
{
outFile << field[0].name << '~' << field[0].price << "~" << field[0].number
<< "~<br><center><table border=0 cellspacing=0 cellpadding=0><tr><td><img src="
<< "\"http://www.art2artonline.com/store/images/7W-1002010.jpg�></td></tr></table>"
<< "</center><br><br><center><font size=�+2�>" << field[0].name << "</font></center><br><br><font size=�+1�>"
<< field[0].description << "</font><br>Suggested Retail: " << field[0].sug_ret 
<< "<table border=�1� cellspacing=�0� cellpadding=�0�><tr><td><font size=�+3�>"
<< "Color/Size</font></td><td><font size=�+3�>Quanitiy in Stock";

// ------------------is single or compressed?

if (!(isame(1) ))
{

	outFile << "</font></td></tr><tr><td></td><td></td></tr><td></td>"
	<< "<td></td></tr><td></td><td></td></tr></table>~~" << field[0].kind
	<< "~http://www.art2artonline.com/store/images/7W-1002010.jpg" << '\n';

	field[0] = field[1];


} //------------------end if--------
else
{


	outFile << "</font></td></tr><tr><td>" << field[0].kind << "</td><td></td></tr><td>"
	<< field[1].kind;
	
	

	num_record++;
	 inFile.getline(field[num_record].record, MAXSTRING, '\n');
	init(num_record);

while(isame(num_record))
{
	outFile << "</td><td></td></tr><td>" << field[num_record].kind;

	
	num_record++;
	 inFile.getline(field[num_record].record, MAXSTRING, '\n');
	init(num_record);


}//---------------end while

outFile << "</td><td></td></tr></table>~~" << field[0].kind 
	<< "~http://www.art2artonline.com/store/images/7W-1002010.jpg";

for(int i = 0; i < num_record; i++)
{
	outFile << '~' << field[i].kind;
}
outFile << '\n';

field[0] = field[num_record];

if(num_record > maxfields)
{
	maxfields = num_record;
}
num_record = 1;

}//-------------------END ELSE------
}//---------------------------------------------End Combine



void init(int n)
{
int nxt;
nxt = n;

field[nxt].cursor = field[nxt].record;

 	field[nxt].curs2 = field[nxt].name;
	while( *(field[nxt].cursor) != '~' )
	{
		*(field[nxt].curs2) = *(field[nxt].cursor);
		field[nxt].cursor++;
		field[nxt].curs2++;
	}
	field[nxt].cursor++;

	

	 field[nxt].curs2 = field[nxt].price;
	while( *(field[nxt].cursor) != '~' )
	{
		*(field[nxt].curs2) = *(field[nxt].cursor);
		field[nxt].cursor++;
		field[nxt].curs2++;
	}
	field[nxt].cursor++;

	 field[nxt].curs2 = field[nxt].number;
	while( *(field[nxt].cursor) != '~' )
	{
		*(field[nxt].curs2) = *(field[nxt].cursor);
		field[nxt].cursor++;
		field[nxt].curs2++;
	}field[nxt].cursor++;
	field[nxt].cursor++;

	 field[nxt].curs2 = field[nxt].kind;
	while( *(field[nxt].cursor) != '~' )
	{
		*(field[nxt].curs2) = *(field[nxt].cursor);
		field[nxt].cursor++;
		field[nxt].curs2++;
	}field[nxt].cursor++;
	field[nxt].cursor++;


	 field[nxt].curs2 = field[nxt].sug_ret;
	while( *(field[nxt].cursor) != '~' )
	{
		*(field[nxt].curs2) = *(field[nxt].cursor);
		field[nxt].cursor++;
		field[nxt].curs2++;
	}field[nxt].cursor++;

	 field[nxt].curs2 = field[nxt].description;
	while( *(field[nxt].cursor) != '\n' )
	{
		*(field[nxt].curs2) = *(field[nxt].cursor);
		field[nxt].cursor++;
		field[nxt].curs2++;
	}

}//-----------------end init------------------------


int isame(int num_record)
{
if(( (strcmp(field[0].name, field[num_record].name) ==0) && (strcmp(field[0].price, field[num_record].price) ==0) && (strcmp(field[0].number, field[num_record].number) ==0) ))
	return 1;
else return 0;

}//----------------end isame-------------------




