#include "3dpoint.h"
#include <iostream.h>
#include <math.h>
#include <rand.h>

#include <stdlib.h>
#include <stdio.h>

int color=1;
const int RED = 1;
const int BLUE = 4;
const int GREEN = 2; 
const int BLACK = 15;
const int WHITE = 255;
const int MSKED = 0;
const int YELLOW=3;

int xmid=1024/2;
int ymid=768/2;

float xzoom=100;
float yzoom=100;
float res=.07;



void main()
{
	

	install_timer();
	allegro_init();


	install_keyboard(); 
 	set_gfx_mode(GFX_AUTODETECT, 1024, 768, 1024, 768);
  	 set_pallete(desktop_pallete);

	extern volatile char key[128]; // keyboard flags--if (key[KEY_SPACE])

	floodfill(screen, 100, 100, BLACK);

line(screen, 0,ymid,2*xmid,ymid,GREEN);
line(screen,xmid,0,xmid,2*ymid,GREEN);

float y=0;

float oldy=y;

for(int n=1;n<80;n++)
{

for(float x=-xmid;x<xmid;x+=res)
{

oldy=y;

//_______________________________________EQUATIONS______________
y=sin(n)*x*n/((x*x)+1);
//y=(2*x*x*x*x)/(x*n*x*x +1);
//y=(x-1)/(n*x -x -6);
//y=sin(x);
//y=sin(x)+sin(x+n);
//y=x* pow(x,-n);


y=yzoom*y;

if(ABS(y-ymid)>10*yzoom) color=4;

line(screen, int(xzoom*(x-res))+xmid,int(-oldy+ymid),int(xzoom*(x))+xmid,int(-y+ymid),color);
color=RED;

}//_____end X for-----

}//----------------end n for---


/*

for(float x=-xmid;x<xmid;x+=res)
{

oldy=y;

//_______________________________________EQUATIONS______________
//y=x*x;
//y=(2*x*x*x*x)/(x*n*x*x +1);
//y=(x-1)/(n*x -x -6);
//y=sin(x);
y=sin(x+PI)+cos(x+n);

y=yzoom*y;

if(ABS(y-ymid)>10*yzoom) color=4;

line(screen, int(xzoom*(x-res))+xmid,int(-oldy+ymid),int(xzoom*(x))+xmid,int(-y+ymid),color);
color=BLUE;

}//_____end X for-----

}//----------------end n for---



*/



readkey();


}//--------------End Main--------------------



