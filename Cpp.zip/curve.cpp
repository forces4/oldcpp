#include "3dpoint.h"
#include <iostream.h>
#include <math.h>
#include <rand.h>
//#include "allegro.h"
#include <stdlib.h>
#include <stdio.h>
#include "string.h"

const int BLACK = 15;
const int MAXL = 15;
void c_curve(int x1, int y1, int x2, int y2, int level, int color);
int done =0;

//typedef char string[50];
//string string1;
void main()
{
	

	install_timer();
	allegro_init();


	install_keyboard(); 
 	set_gfx_mode(GFX_AUTODETECT, 640, 480, 1024, 1024);
  	 set_pallete(desktop_pallete);

	extern volatile char key[128]; // keyboard flags--if (key[KEY_SPACE])

	floodfill(screen, 100, 100, 25);


int temp;



while(!keypressed() && !done)//      (readkey() & 0xff) != 'd')
{

for(int i=0; i<MAXL; i++)
{	
//	c_curve(int(RND() * 200), int(RND() * 200), int(RND() * 300 +300)
//	, int(RND() * 400), i, int (RND() * 10) );

	c_curve(300, 100, 500, 250, i, int (RND() * 20) );


    
//for(double k=3; k< 5433424;k++){if (keypressed()){ break; done =1;}}//delay-----

//if(i>=1)
	//c_curve(300, 100, 500, 250, i-1, BLACK);
//else 
//c_curve(300, 100, 500, 250, MAXL-1, BLACK);

}
}
}//--------------end main------------------------------------------


void c_curve(int x1, int y1, int x2, int y2, int level, int color)
{

int xm, ym, xm2, ym2;

if (level==1)
	
    	line(screen, x1, y1,  x2, y2, 12 );
	
	
	
else
{

xm = (x1 + x2 + y1 - y2)/2;
ym = (y1 + y2 + x2 - x1)/2;

//xm2 = (x1 + x2 + y2 - y1)/2;
//ym2 = (y1 + y2 + x1 - x2)/2;

//textout(screen, font, itoa(xm, string1,10),xm, ym, 10);

//line(screen, x1, y1,  x2, y2, color );

c_curve(x1, y1, xm, ym, level-1, color);
c_curve(xm, ym, x2, y2, level-1, color);

//c_curve(x1, y1, xm2, ym2, level-1, color);
//c_curve(xm2, ym2, x2, y2, level-1, color);



}

}


