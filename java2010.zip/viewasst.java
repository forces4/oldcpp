import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import java.text.*;
import java.util.*; 
import java.lang.String;


public class viewasst extends HttpServlet {


//--------------------Start the DoPost function-----------------------
     public void doPost(HttpServletRequest request, HttpServletResponse response)
     throws IOException {

String url="jdbc:mysql://localhost:3306/ampyro69_inventory?autoReconnect=true";
response.setContentType ("text/html;charset=utf-8");
PrintWriter out = response.getWriter();  

String product=request.getParameter("product");


out.println("<html><body> "); 


//________________BUILD QUERIES BELOW FOR FORM__________


String showprod="SELECT prod, descrip, numshells FROM AssortmentItems WHERE (AssortmentItems.prod like '"+product+"') order by descrip";

String vendorqry= "SELECT Aggragate.subitems, FireOne.VendorNumber, Aggragate.numshells, Aggragate.Productnum, FireOne.Description FROM FireOne INNER JOIN Aggragate ON FireOne.ProductNumber = Aggragate.subitems WHERE ((Aggragate.Productnum)='"+product+"') order by FireOne.Description ";



try{						
Class.forName  ("com.mysql.jdbc.Driver");
Connection con = DriverManager.getConnection(url, "ampyro69_Rob", "eugene19" );

Statement prodstmnt= con.createStatement ();
ResultSet prodrs= prodstmnt.executeQuery (showprod);//-----------gets data


Statement venstmnt= con.createStatement ();
ResultSet venrs= venstmnt.executeQuery (vendorqry);//-----------gets data


out.println("<table border=1 width=100%><tr>");


//prodrs
//showprod="SELECT prod, descrip, numshells FROM AssortmentItems WHERE (AssortmentItems.prod like '"+product+"') order by descrip";

//venrs
/*SELECT Aggragate.subitems 1, FireOne.VendorNumber 2, Aggragate.numshells 3, Aggragate.Productnum 4
FROM FireOne INNER JOIN Aggragate ON FireOne.ProductNumber = Aggragate.subitems
WHERE (((Aggragate.Productnum)='"+product+"'));
*/


out.println("<td bgcolor=Silver><center><b><font size=5>Vendor<td bgcolor=Silver><center><b><font size=5># of Shells<td bgcolor=Silver><center><b><font size=5> Items in Assortment "+product+"</font></b>");

boolean prodnext=prodrs.next();
boolean vennext=venrs.next();

 while ( prodnext || vennext )
          {




                  if(vennext) out.println("<tr><td>"+ venrs.getString(2));
                  if(!vennext)out.println("<tr><td>&nbsp;");

                  //numshells
		  if(vennext)out.println("<td>"+ venrs.getString(3));
                  if(!vennext)out.println("<td>"+ prodrs.getString(3));


		  if(prodnext)out.println("<td>"+ prodrs.getString(2));

if(prodnext)prodnext=prodrs.next();
if(vennext) vennext=venrs.next();

                 
          }  // ---------end while



out.println("</table>");

//---------------------------end querry display----------------------------------------

prodrs.close();
prodstmnt.close();
venrs.close();
venstmnt.close();



con.close();




out.println("</body></html>");

 }  // end try
        catch (SQLException ex) {           
		
	        response.setContentType("text/html");			
		while (ex != null) {  
                	out.println ("SQL Exception:  " + ex.getMessage ());
                	ex = ex.getNextException ();  
              }  // end while
        }  // end catch SQLException

        catch (java.lang.Exception ex) {
      			response.setContentType("text/html");	
		out.println ("Exception:  " + ex.getMessage ());
	  }

    }// ------------end dopost() function----------


//______________________________Start doget()__________
//______________________________Start doget()__________
//______________________________Start doget()__________



public void doGet(HttpServletRequest request, HttpServletResponse response)
     throws IOException {

doPost(request, response);

    }// ------------end doget() function----------

}//------------end display prod class-------------

      
