import java.util.*;
import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import java.text.*;
import java.lang.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;




public class ammail extends HttpServlet{

    String temptext="";

public void doPost(HttpServletRequest request, HttpServletResponse response)
     throws IOException {


String name= request.getParameter("user");
String mailaddy= request.getParameter("email");
String notes= request.getParameter("notes");
String ordnum=request.getParameter("ordnum");
String day=request.getParameter("day");

float total=0;
float brokecase=0;
String tempstr;
String tempstr2;
String tempstr3;
String tempstr4;
String tempstr5;
String tempstr6;
String tempstr7;
String tempstr8;//amd

String url="jdbc:mysql://localhost:3306/ampyro69_inventory?autoReconnect=true";
DecimalFormat df = new DecimalFormat("'$'0.00");


response.setContentType ("text/html;charset=utf-8");
PrintWriter out = response.getWriter();  


String query="SELECT orders.usrname, orders.product, orders.quantity,  FireOne.Sizes, FireOne.VendorNumber, FireOne.Description, orders.id, FireOne.Wholesale, FireOne.percase,  FireOne.QtyLeft, FireOne.ATFtype FROM orders INNER JOIN FireOne ON orders.product = FireOne.ProductNumber where ((  orders.usrname='" +name+"') AND orders.ordnum='"+ordnum+"') order by id";


try{						
Class.forName  ("com.mysql.jdbc.Driver");
Connection con = DriverManager.getConnection(url, "ampyro69_Rob", "eugene19" );

Statement stmt = con.createStatement ();

ResultSet rs = stmt.executeQuery (query);//-----------gets data

int numCols = rs.getMetaData().getColumnCount ();

temptext=temptext +"<html><table border=1 cellpadding=2 width=100%> <tr><td>Product<td>Quantity<td>Size<td> Vendor<td>Description<td>Price<td>Subtotal";
tempstr2="12 inch";
tempstr3="10 inch";
tempstr4="Caballer";
tempstr5="LaRosa";
tempstr6="ematch";
tempstr7="equipment";
tempstr8="AMPYRO-D";
while ( rs.next() )
{

/*SELECT orders.usrname1, orders.product2, orders.quantity3,  FireOne.Sizes4, FireOne.VendorNumber5, FireOne.Description6, orders.id7, FireOne.Wholesale8, FireOne.percase9,  FireOne.QtyLeft10, ATFtype 11 
*/

              
temptext=temptext + "<tr>";
//temptext=temptext + "\n";

for (int i=1; i<=numCols; i++) 
		  { 
if(i!=1 && i!=7 && i!=8  && i!=9 && i!=10 && i!=11) temptext=temptext  + "<td>"+rs.getString(i) ;

if (i==8)
     {
         temptext=temptext + "<td>"+ df.format(Float.parseFloat(rs.getString(i)) );
         temptext=temptext + "<td>"+ df.format(Float.parseFloat(rs.getString(i)) * Float.parseFloat(rs.getString(3)));



     }


                  }  // ----------end for
total+=(Float.parseFloat(rs.getString(8)) * Float.parseFloat(rs.getString(3)) );

tempstr=rs.getString(4) ;



if(!tempstr4.equalsIgnoreCase(rs.getString(5)) && !tempstr7.equalsIgnoreCase(rs.getString(11))  && !tempstr6.equalsIgnoreCase(rs.getString(11))  && !tempstr5.equalsIgnoreCase(rs.getString(5)) 
&& !tempstr8.equalsIgnoreCase(rs.getString(5)) && !tempstr.equalsIgnoreCase(tempstr3) && !tempstr.equalsIgnoreCase(tempstr2) && java.lang.Integer.parseInt(rs.getString(10))> java.lang.Integer.parseInt(rs.getString(9)) ) brokecase+=(Float.parseFloat(rs.getString(8))*(Float.parseFloat(rs.getString(3))%Float.parseFloat(rs.getString(9))  )  );



 }  // ---------end while

temptext=temptext + "<tr><td> &nbsp; <td>&nbsp; <td>&nbsp;  <td>&nbsp;<td colspan=2> Your total is:<td> <b>" + df.format(total);

temptext=temptext + "<tr><td> &nbsp; <td>&nbsp;<td>&nbsp; <td>&nbsp;<td colspan=2> Broken Case Charge is:<td> <b>" +df.format(.1* brokecase);

temptext=temptext + "<tr><td> &nbsp; <td>&nbsp;<td>&nbsp; <td>&nbsp;<td colspan=2><b><big>Grand Total:</big><b><td> <b><big><u>" +df.format(.1* brokecase+total)+"</u></big></b>";


temptext=temptext + "</table><p> Order #"+ordnum+" for username:" + name+ "<p>";


rs.close();
stmt.close();
con.close();


}  // end try

        catch (SQLException ex) {           		
	        response.setContentType("text/html");			
		while (ex != null) {  
                	out.println ("SQL Exception:  " + ex.getMessage ());
                	ex = ex.getNextException ();  
              }  // end while
        }  // end catch SQLException

        catch (java.lang.Exception ex) {
      			response.setContentType("text/html");	
		out.println ("Exception:  " + ex.getMessage ());
	  }



 String to = mailaddy;
 String from = "sales@ampyro.com";
String subj=name + " order "+ ordnum;

for(int i=1; i<=2; i++){

if (i==2) to="sales@ampyro.com";

if (i==2)temptext=temptext + "<p> Email:" + mailaddy+ "<p>Date: "+day+"<p>";
if (i==1)temptext=temptext+ "<p>Notes:<p>" + notes + "<p>";
 
        // SUBSTITUTE YOUR ISP'S MAIL SERVER HERE!!!
        String host = "mail.ampyro.com";

        // Create properties, get Session
        Properties props = new Properties();

        // If using static Transport.send(),
        // need to specify which host to send it to
        props.put("mail.ampyro.com", host);
        // To see what is going on behind the scene
        props.put("mail.debug", "true");
        Session session = Session.getInstance(props);

        try {

             Transport bus = session.getTransport("smtp");

            // Connect only once here
            // Transport.send() disconnects after each send
            // Usually, no username and password is required for SMTP
            bus.connect();
            //bus.connect("smtpserver.yourisp.net", "username", "password");

            // Instantiatee a message
            Message msg = new MimeMessage(session);
           
            //Set message attributes
            msg.setFrom(new InternetAddress(from));
            InternetAddress[] address = {new InternetAddress(to)};
            msg.setRecipients(Message.RecipientType.TO, address);

            if(i==1)msg.setSubject("Your Ampyro order");
            if(i==2)msg.setSubject(subj);

            msg.setSentDate(new java.util.Date());

            //msg.setText( temptext);
            //msg.saveChanges();


            setHTMLContent(msg);
            msg.saveChanges();
            //bus.sendMessage(msg, address);


            //Send the message
            Transport.send(msg);
            }//------------End try



        catch (MessagingException mex) {
            // Prints all nested (chained) exceptions as well
            mex.printStackTrace();
             }


}//end for addies


temptext="";


out.println("<big>Your order has been submitted, <a href=http://www.ampyro.com>Click Here</a> to return to homepage</big>");

    }//end do post





    //------------------------------------ Set a single part html content.
    // Sending data of any type is similar.
    public void setHTMLContent(Message msg) throws MessagingException {

        String html = temptext;

        // HTMLDataSource is an inner class
        msg.setDataHandler(new DataHandler(new HTMLDataSource(html)));

    }//-------------------------End setHtmlContent---------------



    /*
     * Inner class to act as a JAF datasource to send HTML e-mail content
     */
    static class HTMLDataSource implements DataSource {
        private String html;

        public HTMLDataSource(String htmlString) {
            html = htmlString;
        }

        // Return html string in an InputStream.
        // A new stream must be returned each time.
        public InputStream getInputStream() throws IOException {
            if (html == null) throw new IOException("Null HTML");
            return new ByteArrayInputStream(html.getBytes());
        }

        public OutputStream getOutputStream() throws IOException {
            throw new IOException("This DataHandler cannot write HTML");
        }

        public String getContentType() {
            return "text/html";
        }

        public String getName() {
            return "JAF text/html dataSource to send e-mail only";
        }
    }//--------------------End HTMLDATASource Class----------------------


}//End of class