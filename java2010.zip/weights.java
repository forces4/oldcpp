import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import java.text.*;
import java.util.*; 
import java.lang.String;


public class weights extends HttpServlet {


//--------------------Start the DoPost function-----------------------
     public void doPost(HttpServletRequest request, HttpServletResponse response)
     throws IOException {


String url="jdbc:mysql://localhost:3306/ampyro69_inventory?autoReconnect=true";

response.setContentType ("text/html;charset=utf-8");


PrintWriter out = response.getWriter();  


out.println("<html><body>");



//________________BUILD QUERIES BELOW FOR FORM__________


String weightquery="SELECT bunkers, weight FROM onlineweights ORDER BY weight";


//------------------This fetches a recordset(filtered)-------------------------------------
	

try{						
Class.forName  ("com.mysql.jdbc.Driver");
Connection con = DriverManager.getConnection(url, "ampyro69_Rob", "eugene19" );

Statement stmt = con.createStatement ();

ResultSet rs = stmt.executeQuery (weightquery);//-----------gets data


//------------------end record fetcher----------------------------------------------------

//start table---------------------
out.println("<table border=1 width=100%><tr><td>Bunker");


for(int ton=1; ton<=30; ton++)
{

out.println("<td>"+ton+" ton");

}


 while ( rs.next() )
		 {
out.println("<tr><td>"+rs.getString(1) );

for (int i=1; i<=30; i++)
{

     if( java.lang.Integer.parseInt(rs.getString(2)) >=i * 2000)
     {
      out.println("<td bgcolor=lime width=20>&nbsp;");
     }
     else out.println("<td bgcolor=black width=20>&nbsp;");

}


                     
                  }  // ---------end while

out.println("</table>");

//---------------------------end querry display----------------------------------------

rs.close();
stmt.close();
con.close();

//------------------------------------------------------------------------------




out.println("</body></html>");
 }  // end try
        catch (SQLException ex) {           
		
	        response.setContentType("text/html");			
		while (ex != null) {  
                	out.println ("SQL Exception:  " + ex.getMessage ());
                	ex = ex.getNextException ();  
              }  // end while
        }  // end catch SQLException

        catch (java.lang.Exception ex) {
      			response.setContentType("text/html");	
		out.println ("Exception:  " + ex.getMessage ());
	  }

    }// ------------end dopost() function----------


//______________________________Start doget()__________
//______________________________Start doget()__________
//______________________________Start doget()__________



public void doGet(HttpServletRequest request, HttpServletResponse response)
     throws IOException {

String url="jdbc:mysql://localhost:3306/ampyro69_inventory?autoReconnect=true";

response.setContentType ("text/html;charset=utf-8");


PrintWriter out = response.getWriter();  


out.println("<html><body>");



//________________BUILD QUERIES BELOW FOR FORM__________


String weightquery="SELECT bunkers, weight FROM onlineweights ORDER BY weight";


//------------------This fetches a recordset(filtered)-------------------------------------
	

try{						
Class.forName  ("com.mysql.jdbc.Driver");
Connection con = DriverManager.getConnection(url, "ampyro69_Rob", "eugene19" );

Statement stmt = con.createStatement ();

ResultSet rs = stmt.executeQuery (weightquery);//-----------gets data


//------------------end record fetcher----------------------------------------------------

//start table---------------------
out.println("<table border=1 width=100%><tr><td>Bunker");


for(int ton=1; ton<=30; ton++)
{

out.println("<td>"+ton+" ton");

}


 while ( rs.next() )
		 {
out.println("<tr><td>"+rs.getString(1) );

for (int i=1; i<=30; i++)
{

     if( java.lang.Integer.parseInt(rs.getString(2)) >=i * 2000)
     {
      out.println("<td bgcolor=lime width=20>&nbsp;");
     }
     else out.println("<td bgcolor=black width=20>&nbsp;");

}


                     
                  }  // ---------end while

out.println("</table>");

//---------------------------end querry display----------------------------------------

rs.close();
stmt.close();
con.close();

//------------------------------------------------------------------------------




out.println("</body></html>");
 }  // end try
        catch (SQLException ex) {           
		
	        response.setContentType("text/html");			
		while (ex != null) {  
                	out.println ("SQL Exception:  " + ex.getMessage ());
                	ex = ex.getNextException ();  
              }  // end while
        }  // end catch SQLException

        catch (java.lang.Exception ex) {
      			response.setContentType("text/html");	
		out.println ("Exception:  " + ex.getMessage ());
	  }


    }// ------------end doget() function----------

}//------------end display prod class-------------

      
