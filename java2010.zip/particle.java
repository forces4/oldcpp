package firework;

public class particle {
	
    // particle class fields---
    public float x;
    public float y;
    public float z;
    public float xvelocity;
    public float yvelocity;
    public float zvelocity;
    public float xacel;
    public float yacel;
    public float zacel;

	
    // the particle class has one constructor
    public particle() {
        
//random placement variables
        xacel=0;
	yacel=0;
	zacel=0;

        x =(float)(Math.random()*100F) -50F;
        y =(float)(Math.random()*100F) +20F;
        z =(float)(Math.random()*100F) -50F;

        xvelocity=(float)(Math.random()*4F) -2F;
        yvelocity=(float)(Math.random()*4F) -2F;
        zvelocity=(float)(Math.random()*4F) -2F;
	

      

    }
	
    // the Particle class has  methods
    public void move() {

	if (xvelocity >0 && xvelocity+xacel <=25)  xvelocity=xvelocity+xacel;
	if (xvelocity<=0 && xvelocity+xacel >=-25) xvelocity=xvelocity+xacel;

	if (yvelocity >0 && yvelocity+yacel <=25)  yvelocity=yvelocity+yacel;
	if (yvelocity<=0 && yvelocity+yacel >=-25) yvelocity=yvelocity+yacel;

	if (zvelocity >0 && zvelocity+zacel <=25)  zvelocity=zvelocity+zacel;
	if (zvelocity<=0 && zvelocity+zacel >=-25) zvelocity=zvelocity+zacel;


if(Math.abs(x) >= 1000){ xvelocity=-(float)0.90000*xvelocity; x=.80F*x;}
if(Math.abs(y) >= 1000){ yvelocity=-(float)0.90000*yvelocity; y=.80F*y;}
if(Math.abs(z) >= 1000){ zvelocity=-(float)0.90000*zvelocity; z=.80F*z;}

       x=x+xvelocity;
       y=y+yvelocity;
       z=z+zvelocity;

       


    }//end move()
	
    
	
}//---end particle class

