import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import java.text.*;
import java.util.*; 
import java.lang.String;


public class video extends HttpServlet {


//--------------------Start the DoPost function-----------------------
     public void doPost(HttpServletRequest request, HttpServletResponse response)
     throws IOException {

String url="jdbc:mysql://localhost:3306/ampyro69_inventory?autoReconnect=true";
response.setContentType ("text/html;charset=utf-8");
PrintWriter out = response.getWriter();  

String product=request.getParameter("product");


out.println("<html><body> "+product); 


//________________BUILD QUERIES BELOW FOR FORM__________




String showprod="SELECT start, end, ProductNumber, masternum, Description, Sizes FROM FireOne WHERE (FireOne.masternum like '"+product+"')";


try{						
Class.forName  ("com.mysql.jdbc.Driver");
Connection con = DriverManager.getConnection(url, "ampyro69_Rob", "eugene19" );

Statement prodstmnt= con.createStatement ();
ResultSet prodrs= prodstmnt.executeQuery (showprod);//-----------gets data



boolean prodnext=prodrs.next();

 //while ( prodnext )
   //       {


out.println(prodrs.getString(6)+" " +prodrs.getString(5)+"<p>");
out.println("<embed src='http://www.ampyro.com/video/"+product+".wmv' width=200 height=240>"); 

                  
if(prodnext)prodnext=prodrs.next();

                 
         // }  // ---------end while






//---------------------------end querry display----------------------------------------

prodrs.close();
prodstmnt.close();

con.close();




out.println("</body></html>");

 }  // end try
        catch (SQLException ex) {           
		
	        response.setContentType("text/html");			
		while (ex != null) {  
                	out.println ("SQL Exception:  " + ex.getMessage ());
                	ex = ex.getNextException ();  
              }  // end while
        }  // end catch SQLException

        catch (java.lang.Exception ex) {
      			response.setContentType("text/html");	
		out.println ("Exception:  " + ex.getMessage ());
	  }

    }// ------------end dopost() function----------


//______________________________Start doget()__________
//______________________________Start doget()__________
//______________________________Start doget()__________



public void doGet(HttpServletRequest request, HttpServletResponse response)
     throws IOException {


String url="jdbc:mysql://localhost:3306/ampyro69_inventory?autoReconnect=true";
response.setContentType ("text/html;charset=utf-8");
PrintWriter out = response.getWriter();  

String product=request.getParameter("product");


out.println("<html><body> "+product); 


//________________BUILD QUERIES BELOW FOR FORM__________




String showprod="SELECT start, end, ProductNumber, masternum, Description, Sizes FROM FireOne WHERE (FireOne.masternum like '"+product+"')";


try{						
Class.forName  ("com.mysql.jdbc.Driver");
Connection con = DriverManager.getConnection(url, "ampyro69_Rob", "eugene19" );

Statement prodstmnt= con.createStatement ();
ResultSet prodrs= prodstmnt.executeQuery (showprod);//-----------gets data



boolean prodnext=prodrs.next();

 //while ( prodnext )
   //       {



out.println(prodrs.getString(6)+" " +prodrs.getString(5)+"<p>");
out.println("<embed src='http://www.ampyro.com/video/"+product+".wmv' width=200 height=240>"); 

                  
if(prodnext)prodnext=prodrs.next();

                 
         // }  // ---------end while






//---------------------------end querry display----------------------------------------

prodrs.close();
prodstmnt.close();

con.close();




out.println("</body></html>");

 }  // end try
        catch (SQLException ex) {           
		
	        response.setContentType("text/html");			
		while (ex != null) {  
                	out.println ("SQL Exception:  " + ex.getMessage ());
                	ex = ex.getNextException ();  
              }  // end while
        }  // end catch SQLException

        catch (java.lang.Exception ex) {
      			response.setContentType("text/html");	
		out.println ("Exception:  " + ex.getMessage ());
	  }
    }// ------------end doget() function----------

}//------------end display prod class-------------

      
