import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.text.*;
import java.util.*; 
import java.lang.String;
import java.lang.Math;
import java.applet.*;
import java.awt.*;




public class zrtrails extends Applet implements Runnable
{

String trailstatus="";

int speedlimit=20;
int Num_dots=30;
int center_force=-1000;
int partical_force=1;
int trails =10;
int delay=10;
float xgrav =0;
float ygrav =0;
float zgrav =0;
int mouseX, mouseY;
boolean mouseclicked = false;
int x_dir;
int y_dir;
int z_dir;
int xmid=200/2;
int ymid=200/2;
int zmid=100/2;




public pnt[] first= new pnt[Num_dots];      // allocates memory for num_dot points


public pnt[][] second= new pnt[Num_dots][trails];
int trailswitch=0;
public String dbug="sdfsgsdf";




public int x;
public int y;
public int z;
Thread th;


 public boolean mouseDown(Event e, int x, int y ) {
        mouseX=x; mouseY=y;
        mouseclicked = true;

return true;
}









public void start ()
	{
		th = new Thread (this);
		th.start ();
	}

	public void stop()
	{

	}

	public void destroy()
	{

	}

	public void run ()
	{
		Thread.currentThread().setPriority(Thread.MIN_PRIORITY);

				

dbug="in main";

for (int i=0;i<Num_dots;i++){

dbug="inside first setup loop";
//first[i].set_x( (float) Math.random() * 200);
first[i].set_x((float) 7);
dbug="after accesing fist[i].set_x()";


first[i].set_y( (float) Math.random() * 200);
first[i].set_z( (float) Math.random() * 100);
first[i].set_xvel( (float)Math.random() *10 -5);
first[i].set_yvel(( float)Math.random() *10 -5);
first[i].set_zvel( (float)Math.random() *10 -5);
first[i].set_yacl(0);
first[i].set_xacl(0);
first[i].set_zacl(0);

dbug="after class use";
}//------------------------end for i, initializing






while(true){

if(trailswitch==1)trailstatus="one";
if(trailswitch==0)trailstatus="zero";

       
       
 xmid=mouseX;
 ymid=mouseY;
//if(mouseclicked ) zmid+=100;
//if(mouse_b & 2 ) zmid-=100;

//--------------------------------------------Start Trails loop---------------------------
for(int tr =0;tr <trails;tr++){



	for(int i=0;i<Num_dots;i++){


	second[i][tr].set_x(first[i].gx());
	second[i][tr].set_y(first[i].gy());
	second[i][tr].set_z(first[i].gz());

	//-----------------------------------Now can change first with ability to unplot old------
	first[i].move_x(first[i].gxvel());
	first[i].move_y(first[i].gyvel());
	first[i].move_z(first[i].gzvel());

	//----------Below is for center force------------------------


	if(center_force !=0){

	first[i].set_yacl(ygrav + get_yforce(first[i].gx(), first[i].gy(),first[i].gz()));
	first[i].set_xacl(xgrav + get_xforce(first[i].gx(), first[i].gy(),first[i].gz()));
	first[i].set_zacl(zgrav + get_zforce(first[i].gx(), first[i].gy(),first[i].gz()));
	}



	if ( Math.abs( (int)first[i].gx() - xmid) < 10 && Math.abs( (int) first[i].gy()  -ymid)< 10 && Math.abs( (int) first[i].gz() -zmid)<10){
	first[i].set_x((float)Math.random() * 200);
	first[i].set_y((float)Math.random() * 200);
	first[i].set_z((float)Math.random() * 100);
	first[i].set_z(zmid);
	}

	

	}//------------------------------------end Num_dots for-------------------------------

	//-------------------------------------Below is for partical charge-------------

	for( int i=0 ;i<Num_dots;i++){

if(partical_force !=0){
	float pxtotalforce=0;
	float pytotalforce=0;
	float pztotalforce=0;
	float pdistance=0;
	float tforce=0;
	float force=0;

//below tests each partical against every other partical to calculate force.---------------
		for (int j=0;j<Num_dots;j++){
			if(j!=i)
			{
	
			pdistance=(float) Math.sqrt( (first[i].gx()-first[j].gx())*(first[i].gx()-first[j].gx()) 
			+ (first[i].gy()-first[j].gy())*(first[i].gy()-first[j].gy()) 
			+ (first[i].gz()-first[j].gz())*(first[i].gz()-first[j].gz()) );
			tforce=(float) (Math.abs((int)first[i].gx()-first[j].gx()) + Math.abs((int) first[i].gy()-first[j].gy())+ Math.abs((int)first[i].gz()-first[j].gz()));
			force=( partical_force/(pdistance * pdistance) );
			pxtotalforce=pxtotalforce+ ( ((first[i].gx()-first[j].gx())/tforce) * force );
			pytotalforce=pytotalforce+ ( ((first[i].gy()-first[j].gy())/tforce) * force );
			pztotalforce=pztotalforce+ ( ((first[i].gz()-first[j].gz())/tforce) * force );

			}//----end if j

		}//-------end for j


	first[i].set_yacl( first[i].gyacl() + pytotalforce);
	first[i].set_xacl( first[i].gxacl() + pxtotalforce);
	first[i].set_zacl( first[i].gzacl() + pztotalforce);	
	//if(distance < 30)return( ((y1-ymid)/distance) * -force );
	//if(distance >= 30)return( ((y1-ymid)/distance) * force );

	pxtotalforce=0;
	pytotalforce=0;
	pztotalforce=0;
	pdistance=0;
	tforce=0;
	force=0;

	}//__________end 0 partical force test__________________

	first[i].set_xvel(first[i].gxvel() + first[i].gxacl());
	first[i].set_yvel(first[i].gyvel() + first[i].gyacl());
	first[i].set_zvel(first[i].gzvel() + first[i].gzacl());
	

	//--------------------------------line below bestows angular velocity filter for whirlpool effect
	//if((ymid - first[i].gy())/(first[i].gx()-xmid) <= (ymid - second[i][0].gy())/(second[i][0].gx()-xmid) )
	        

	//---------------------------------------------veleocity limits---------------------------------------


	if(first[i].gxvel()>=speedlimit || first[i].gxvel()<= -speedlimit)
	{
	first[i].set_xacl((float)(-.9 * first[i].gxacl()));
	first[i].set_xvel(  (float)first[i].gxvel()/Math.abs((int)first[i].gxvel() *3)  );
	}
	if(first[i].gyvel()>=speedlimit || first[i].gyvel()<= -speedlimit)
	{
	first[i].set_yacl((float)(-.8 * first[i].gyacl()));
	first[i].set_yvel((float)first[i].gyvel()/Math.abs((int)first[i].gyvel() *3));
	}
	if(first[i].gzvel()>=speedlimit || first[i].gzvel()<= -speedlimit)
	{
	first[i].set_zacl((float)(-.5 * first[i].gzacl()));
	first[i].set_zvel((float)first[i].gzvel()/Math.abs((int)first[i].gzvel() *3));
	}
	//---------------------------------------------end velocity limits------------------
	
	} //------------------------------------------end partical charge for------------------
	
	
	for(int dlay =0; dlay <delay; dlay++){}


	if(trailswitch ==1 && tr==trails -1)//zplot
        {
        for(int i=0;i<Num_dots;i++)
            {

           x=(int)second[i][0].gx();
           y=(int)second[i][0].gy();
           z=(int)second[i][0].gz();
repaint();
             }//end for i

        }//end if trailswitch


	if(trailswitch ==1 && tr < trails-1)//zunplot
        {
        for(int i=0;i<Num_dots;i++)
             {
              
             x=(int)second[i][tr+1].gx();
             y=(int)second[i][tr+1].gy();
             z=(int)second[i][tr+1].gz();
             repaint();

             }
        }

}//-------------------------------------------end outside trails for?______________________________________


trailswitch=1;

for(int i=0;i<Num_dots;i++){

x=(int)second[i][0].gx(); 
y=(int)second[i][0].gy(); 
z=(int)second[i][0].gz();
repaint();
}




if(trailswitch==1)trailstatus="one";
if(trailswitch==0)trailstatus="zero";


repaint();












			try
			{
				Thread.sleep (20);
			}
			catch (InterruptedException ex)
			{
				// do nothing
			}

			
			Thread.currentThread().setPriority(Thread.MAX_PRIORITY);
		}
	}























    
  






//------------------------------------------------------------UPDATE
 public void update ( Graphics g ) {
        paint(g);
    }
//------------------------------------------------------------End UPDATE






 public void init()  {
		setBackground(Color.orange);


	 }





 
//----------------------------------------start paint----------------------------

public void paint( Graphics g ) {
 g.setColor(Color.blue);

g.fillOval(x, y, z, z);

g.drawString(dbug, 10, 10);

if (mouseclicked) {
            g.fillOval((mouseX-5), (mouseY-5), 10, 10);
            mouseclicked = false;
        }



}//--------------end paint-----------------------------------------------------------



//------------------------------------------------------------FUNCTION GET_XFORCE----------------

public float get_xforce(float x1, float y1, float z1)
{
float distance;
float force;
float tforce;
distance=(float)Math.sqrt( (x1-xmid)*(x1-xmid) + (y1-ymid)*(y1-ymid) + (z1-zmid)*(z1-zmid) );
tforce=(float)Math.abs((int)(x1-xmid)) + Math.abs((int)(y1-ymid)) + Math.abs((int)(z1-zmid));
force=( center_force/(distance * distance) );

//if(distance < 30)return( ((x1-xmid)/distance) * -force );
//if(distance >= 30)return( ((x1-xmid)/distance) * force );
return( ((x1-xmid)/tforce) * force );
}

//------------------------------------------------------------FUNCTION GET_YFORCE----------------


public float get_yforce(float x1, float y1, float z1)
{
float distance;
float force;
float tforce;

distance=(float)Math.sqrt( (x1-xmid)*(x1-xmid) + (y1-ymid)*(y1-ymid)  + (z1-zmid)*(z1-zmid) );
tforce=(float)Math.abs( (int) (x1-xmid)) + Math.abs((int)(y1-ymid)) + Math.abs((int)(z1-zmid));
force=(center_force/(distance * distance));

//if(distance <30)return( ((y1-ymid)/distance) * -force );
//if(distance >= 30)return( ((y1-ymid)/distance) * force );
return( ((y1-ymid)/tforce) * force );
}



//------------------------------------------------------------FUNCTION GET_ZFORCE----------------
public float get_zforce(float x1, float y1, float z1)
{
float distance;
float force;
float tforce;
distance=(float)Math.sqrt( (x1-xmid)*(x1-xmid) + (y1-ymid)*(y1-ymid)  + (z1-zmid)*(z1-zmid) );
force=(center_force/(distance * distance));
tforce=(float)Math.abs((int)(x1-xmid)) + Math.abs((int)(y1-ymid)) + Math.abs((int)(z1-zmid));
//if(distance <30)return( ((z1-zmid)/distance) * -force );
//if(distance >= 30)return( ((z1-zmid)/distance) * force );
return( ((z1-zmid)/tforce) * force );
}




public class pnt
{

private int xmax =200;
private int ymax=200;
private int zmax=100;	
private int colr;
	

	public float x_pos;
	public float y_pos;
	public float z_pos;	
	public float x_vel;
	public float y_vel;
	public float z_vel;	
	public float x_acl;
	public float y_acl;
	public float z_acl;
	public float mass;
	
public pnt()
{
	x_pos = (float)Math.random() * xmax;
	y_pos = (float)Math.random() * ymax;
	z_pos = (float)Math.random() * zmax;

	x_vel = 0;
	y_vel = 0;
	z_vel = 0;
	x_acl = 0;
	y_acl = 0;
	z_acl = 0;
	mass = 1;
	colr = (int) Math.random() * 50; //if(colr * 3 == 1)colr =0;
	//colr = 2;
}



public void move_rand(int distance)
{
	int mx, my, mz;
	mx = (int)(Math.random()* (distance) - (distance-(Math.random()*2))/2) ;
 	my = (int)(Math.random()* (distance) - (distance-(Math.random()*2))/2) ;
	mz = (int)(Math.random()* (distance) - (distance-(Math.random()*2))/2);

	if ((x_pos + mx) < 2 || (x_pos + mx) > xmax)
		x_pos = x_pos - mx;
	else x_pos = x_pos + mx;

	if ((y_pos + my) < 2 || (y_pos + my) > ymax)
		y_pos = y_pos - my;
	else y_pos = y_pos + my;

	if ((z_pos + mz) < 2 || (z_pos + mz) > zmax)
		z_pos = z_pos - mz;
	else z_pos = z_pos + mz;
}


public void move_x(float distance)
{
	if ((x_pos + distance < 2)|| (x_pos +distance > xmax))
	{
		//x_pos = x_pos - distance;
		x_vel = -x_vel;		
	}
	else x_pos = x_pos + distance;
}



public void move_y(float distance)
{
	if ((y_pos + distance < 2)|| (y_pos +distance > ymax))
	{
		//y_pos = y_pos - distance;
		y_vel = -y_vel;	
	}	
	else y_pos = y_pos + distance;
}




public void move_z(float distance)
{
	if ((z_pos + distance < 2)|| (z_pos +distance > zmax))
	{
		//z_pos = z_pos - distance;
		z_vel = -z_vel;
	}
	else z_pos = z_pos + distance;
}


public void set_x(float coordinate)
{
	if (!( coordinate < 2) || (coordinate > xmax))
	 x_pos = coordinate;
}



public void set_y(float coordinate)
{
	if (!( coordinate < 2) || (coordinate > ymax))
	 y_pos = coordinate;
}



public void set_z(float coordinate)
{
	if (!( coordinate < 2) || (coordinate > zmax))
	 z_pos = coordinate;
}



public void set_xvel(float speed)
{	
	 x_vel = speed;
}




public void set_yvel(float speed)
{	
	 y_vel = speed;
}




public void set_zvel(float speed)
{	
	 z_vel = speed;
}



public void set_xacl(float rate)
{	
	 x_acl = rate;
}


public void set_yacl(float rate)
{	
	 y_acl = rate;
}



public void set_zacl(float rate)
{	
	 z_acl = rate;
}



public float gx()
{
return (x_pos);
}

public float gy()
{
return (y_pos);
}

public float gz()
{
return (z_pos);
}



public float gxvel()
{
return(x_vel);
}



public float gyvel()
{
return(y_vel);
}



public float gzvel()
{
return(z_vel);
}



public float gxacl()
{
return(x_acl);
}



public float gyacl()
{
return(y_acl);
}




public float gzacl()
{
return(z_acl);
}



}//end point class








}//----end zrtrails class


//==============================================================================================================
//==============================================================================================================
//==============================================================================================================
//==============================================================================================================
//==============================================================================================================
//==============================================================================================================
//==============================================================================================================
//==============================================================================================================
//==============================================================================================================
//==============================================================================================================