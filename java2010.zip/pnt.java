

class pnt
{

int xmax =200;
int ymax=200;
int zmax=100;	
int colr;
	

	private float x_pos;
	private float y_pos;
	private float z_pos;	
	private float x_vel;
	private float y_vel;
	private float z_vel;	
	private float x_acl;
	private float y_acl;
	private float z_acl;
	private float mass;
	
void pnt()
{
	x_pos = (float)Math.random() * xmax;
	y_pos = (float)Math.random() * ymax;
	z_pos = (float)Math.random() * zmax;

	x_vel = 0;
	y_vel = 0;
	z_vel = 0;
	x_acl = 0;
	y_acl = 0;
	z_acl = 0;
	mass = 1;
	colr = (int) Math.random() * 50; //if(colr * 3 == 1)colr =0;
	//colr = 2;
}



void move_rand(int distance)
{
	int mx, my, mz;
	mx = (int)(Math.random()* (distance) - (distance-(Math.random()*2))/2) ;
 	my = (int)(Math.random()* (distance) - (distance-(Math.random()*2))/2) ;
	mz = (int)(Math.random()* (distance) - (distance-(Math.random()*2))/2);

	if ((x_pos + mx) < 2 || (x_pos + mx) > xmax)
		x_pos = x_pos - mx;
	else x_pos = x_pos + mx;

	if ((y_pos + my) < 2 || (y_pos + my) > ymax)
		y_pos = y_pos - my;
	else y_pos = y_pos + my;

	if ((z_pos + mz) < 2 || (z_pos + mz) > zmax)
		z_pos = z_pos - mz;
	else z_pos = z_pos + mz;
}


void move_x(float distance)
{
	if ((x_pos + distance < 2)|| (x_pos +distance > xmax))
	{
		//x_pos = x_pos - distance;
		x_vel = -x_vel;		
	}
	else x_pos = x_pos + distance;
}



void move_y(float distance)
{
	if ((y_pos + distance < 2)|| (y_pos +distance > ymax))
	{
		//y_pos = y_pos - distance;
		y_vel = -y_vel;	
	}	
	else y_pos = y_pos + distance;
}




void move_z(float distance)
{
	if ((z_pos + distance < 2)|| (z_pos +distance > zmax))
	{
		//z_pos = z_pos - distance;
		z_vel = -z_vel;
	}
	else z_pos = z_pos + distance;
}


void set_x(float coordinate)
{
	if (!( coordinate < 2) || (coordinate > xmax))
	 x_pos = coordinate;
}



void set_y(float coordinate)
{
	if (!( coordinate < 2) || (coordinate > ymax))
	 y_pos = coordinate;
}



void set_z(float coordinate)
{
	if (!( coordinate < 2) || (coordinate > zmax))
	 z_pos = coordinate;
}



void set_xvel(float speed)
{	
	 x_vel = speed;
}




void set_yvel(float speed)
{	
	 y_vel = speed;
}




void set_zvel(float speed)
{	
	 z_vel = speed;
}



void set_xacl(float rate)
{	
	 x_acl = rate;
}


void set_yacl(float rate)
{	
	 y_acl = rate;
}



void set_zacl(float rate)
{	
	 z_acl = rate;
}



float gx()
{
return (x_pos);
}

float gy()
{
return (y_pos);
}

float gz()
{
return (z_pos);
}



float gxvel()
{
return(x_vel);
}



float gyvel()
{
return(y_vel);
}



float gzvel()
{
return(z_vel);
}



float gxacl()
{
return(x_acl);
}



float gyacl()
{
return(y_acl);
}




float gzacl()
{
return(z_acl);
}



}//end point class