// Source File Name:   firework.java by rob wolverton: ampyro

package firework;

import com.sun.opengl.util.Animator;
import com.sun.opengl.util.GLUT;
import com.sun.opengl.util.texture.Texture;
import com.sun.opengl.util.texture.TextureIO;
import java.applet.Applet;
import java.awt.BorderLayout;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;
import java.io.PrintStream;
import javax.media.opengl.*;
import javax.media.opengl.glu.GLU;

public class firework extends Applet
    implements GLEventListener, KeyListener
{

	


//------------------------------------begin initTextures--------------
    public void initTextures()
    {
        if(amtexture != null)
            amtexture.dispose();
        amtexture = amcreateTexture("/pic/amp256.jpg");

//AM4230mute_0001.jpg

 

    }//end init textures

//---------------------begin createTexture(String s)

    public Texture createTexture(String s, int tnum)
    {
        try
        {
            t[tnum] = TextureIO.newTexture(getClass().getResource(s), false, ".jpg");
            t[tnum].setTexParameteri(GL.GL_TEXTURE_MIN_FILTER, GL.GL_LINEAR);
            t[tnum].setTexParameteri(GL.GL_TEXTURE_MAG_FILTER, GL.GL_LINEAR);
        }
        catch(IOException ioexception)
        {
            System.err.println((new StringBuilder()).append("Error loading ").append(s).toString());
        }
        return t[tnum];
    }//end creatTexture


    public Texture createTexture2(String s, int tnum)
    {
        try
        {
            t2[tnum] = TextureIO.newTexture(getClass().getResource(s), false, ".jpg");
            t2[tnum].setTexParameteri(GL.GL_TEXTURE_MIN_FILTER, GL.GL_LINEAR);
            t2[tnum].setTexParameteri(GL.GL_TEXTURE_MAG_FILTER, GL.GL_LINEAR);
        }
        catch(IOException ioexception)
        {
            System.err.println((new StringBuilder()).append("Error loading ").append(s).toString());
        }
        return t2[tnum];
    }//end creatTexture





public Texture amcreateTexture(String s)
    {
        try
        {
            amt = TextureIO.newTexture(getClass().getResource(s), false, ".jpg");
            amt.setTexParameteri(GL.GL_TEXTURE_MIN_FILTER, GL.GL_LINEAR);
            amt.setTexParameteri(GL.GL_TEXTURE_MAG_FILTER, GL.GL_LINEAR);
        }
        catch(IOException ioexception)
        {
            System.err.println((new StringBuilder()).append("Error loading ").append(s).toString());
        }
        return amt;
    }//end creatTexture



//----------constructor???????????????????????????
    public firework()
    {
for(int i=0;i<32;i++)
{
t = null;
t2 = null;
}

        amt = null;
        scale = 1.0F;
        direction = -PI / 2.0F;
        ydirection = 0.0F;
        cx = -5F;
        cy = 50F;
        cz = -40F;
        lx = 0.0F;
        ly = 50.0F;
        lz = 0.0F;
        up = 0;
        down = 0;
        right = 0;
        left = 0;
        pup = 0;
        pdown = 0;
        sdis = (float)(((double)sightradius * Math.cos(ydirection) * Math.sin(direction) * (double)scale) / 10D);
        cdis = (float)(((double)sightradius * Math.cos(ydirection) * Math.cos(direction) * (double)scale) / 10D);
        spin = 0.0F;
        setLayout(new BorderLayout());
        setSize(600, 600);
        setLocation(40, 40);
        setVisible(true);
        requestFocus();
        requestFocusInWindow();
        requestFocus();
        GLCapabilities glcapabilities = new GLCapabilities();
        glcapabilities.setDoubleBuffered(true);
        glcapabilities.setHardwareAccelerated(true);
        GLCanvas glcanvas = new GLCanvas(glcapabilities);
        glcanvas.addGLEventListener(this);
        glcanvas.addKeyListener(this);
        add(glcanvas, "Center");
        Animator animator = new Animator(glcanvas);
        animator.start();
    }//end firework constructor

    public void keyReleased(KeyEvent keyevent)
    {
        switch(keyevent.getKeyCode())
        {
        case 38: // '&'
            up = 0;
            break;

        case 37: // '%'
            left = 0;
            break;

        case 39: // '\''
            right = 0;
            break;

        case 40: // '('
            down = 0;
            break;

        case 33: // '!'
            pup = 0;
            break;

        case 34: // '"'
            pdown = 0;
            break;
        }
    }

    public void keyPressed(KeyEvent keyevent)
    {
        switch(keyevent.getKeyCode())
        {
        case 38: // '&'
            up = 1;
            break;

        case 37: // '%'
            left = 1;
            break;

        case 39: // '\''
            right = 1;
            break;

        case 40: // '('
            down = 1;
            break;

        case 33: // '!'
            pup = 1;
            break;

        case 34: // '"'
            pdown = 1;
            break;
        }
    }

    public void keyTyped(KeyEvent keyevent)
    {
        if(keyevent.getKeyCode() == 10)
        {
            cx = -5F;
            cy = -5F;
            cz = -40F;
            lx = 0.0F;
            ly = 2.0F;
            lz = 0.0F;
            direction = PI / 2.0F;
            ydirection = 0.0F;
        }
    }

    public void init(GLAutoDrawable glautodrawable)
    {

        t= new Texture[32];
	t2= new Texture[32];
        GL gl = glautodrawable.getGL();
        glu = new GLU();
        glut = new GLUT();
        gl.glViewport(0, 0, 400, 400);
        
        gl.glMatrixMode(GL.GL_PROJECTION);
        gl.glLoadIdentity();
        gl.glFrustum(-1D, 1.0D, -1D, 1.0D, 1.5D, clip);
        
        gl.glMatrixMode(GL.GL_MODELVIEW);
        gl.glLoadIdentity();
        gl.glClear(16640);
        glu.gluLookAt(cx, cy, cz, lx, ly, lz, 0.0D, 1.0D, 0.0D);
        glautodrawable.addKeyListener(this);
        initTextures();
        gl.glEnable(GL.GL_TEXTURE_2D);


        box = gl.glGenLists(1);
        gl.glNewList(box, GL.GL_COMPILE);
        
        gl.glBegin(7);
        gl.glColor3f(1.0F, 1.0F, 1.0F);

        gl.glNormal3f(0.0F, 0.0F, -1F);
        gl.glTexCoord2f(0.0F, 1.0F);
        gl.glVertex3i(boxsize, 0, 0);

        gl.glNormal3f(0.0F, 0.0F, -1F);
        gl.glTexCoord2f(0.0F, 0.0F);
        gl.glVertex3i(boxsize, 2*boxsize, 0);

        gl.glNormal3f(0.0F, 0.0F, -1F);
        gl.glTexCoord2f(1.0F, 0.0F);
        gl.glVertex3i(-boxsize, 2*boxsize, 0);

        gl.glNormal3f(0.0F, 0.0F, -1F);
        gl.glTexCoord2f(1.0F, 1.0F);
        gl.glVertex3i(-boxsize, 0, 0);

        gl.glEnd();
        gl.glEndList();


if(texture != null)texture.dispose();
texture = createTexture("/pic/AM4230mute_0001.jpg",0);  
texture = createTexture("/pic/AM4230mute_0002.jpg",1);  
texture = createTexture("/pic/AM4230mute_0003.jpg",2); 
texture = createTexture("/pic/AM4230mute_0004.jpg",3);  
texture = createTexture("/pic/AM4230mute_0005.jpg",4);  
texture = createTexture("/pic/AM4230mute_0006.jpg",5);  
texture = createTexture("/pic/AM4230mute_0007.jpg",6);  
texture = createTexture("/pic/AM4230mute_0008.jpg",7);  
texture = createTexture("/pic/AM4230mute_0009.jpg",8);  
texture = createTexture("/pic/AM4230mute_0010.jpg",9);  
texture = createTexture("/pic/AM4230mute_0011.jpg",10);  
texture = createTexture("/pic/AM4230mute_0012.jpg",11);  
texture = createTexture("/pic/AM4230mute_0013.jpg",12);  
texture = createTexture("/pic/AM4230mute_0014.jpg",13);  
texture = createTexture("/pic/AM4230mute_0015.jpg",14);  
texture = createTexture("/pic/AM4230mute_0016.jpg",15);  
texture = createTexture("/pic/AM4230mute_0017.jpg",16);  
texture = createTexture("/pic/AM4230mute_0018.jpg",17);  
texture = createTexture("/pic/AM4230mute_0019.jpg",18);  
texture = createTexture("/pic/AM4230mute_0020.jpg",19);  
texture = createTexture("/pic/AM4230mute_0021.jpg",20);  
texture = createTexture("/pic/AM4230mute_0022.jpg",21);  
texture = createTexture("/pic/AM4230mute_0023.jpg",22);  
texture = createTexture("/pic/AM4230mute_0024.jpg",23);  
texture = createTexture("/pic/AM4230mute_0025.jpg",24);  
texture = createTexture("/pic/AM4230mute_0026.jpg",25);  
texture = createTexture("/pic/AM4230mute_0027.jpg",26);  
texture = createTexture("/pic/AM4230mute_0028.jpg",27);  
texture = createTexture("/pic/AM4230mute_0029.jpg",28);  
texture = createTexture("/pic/AM4230mute_0030.jpg",29);  
texture = createTexture("/pic/AM4230mute_0031.jpg",30);  
texture = createTexture("/pic/AM4230mute_0032.jpg",31);  


texture = createTexture2("/pic/PGI06_1.jpg",0);
texture = createTexture2("/pic/PGI06_2.jpg",1);
texture = createTexture2("/pic/PGI06_3.jpg",2);
texture = createTexture2("/pic/PGI06_4.jpg",3);
texture = createTexture2("/pic/PGI06_5.jpg",4);
texture = createTexture2("/pic/PGI06_6.jpg",5);
texture = createTexture2("/pic/PGI06_7.jpg",6);
texture = createTexture2("/pic/PGI06_8.jpg",7);
texture = createTexture2("/pic/PGI06_9.jpg",8);
texture = createTexture2("/pic/PGI06_10.jpg",9);
texture = createTexture2("/pic/PGI06_11.jpg",10);
texture = createTexture2("/pic/PGI06_12.jpg",11);
texture = createTexture2("/pic/PGI06_13.jpg",12);
texture = createTexture2("/pic/PGI06_14.jpg",13);
texture = createTexture2("/pic/PGI06_15.jpg",14);
texture = createTexture2("/pic/PGI06_16.jpg",15);
texture = createTexture2("/pic/PGI06_17.jpg",16);
texture = createTexture2("/pic/PGI06_18.jpg",17);
texture = createTexture2("/pic/PGI06_19.jpg",18);
texture = createTexture2("/pic/PGI06_20.jpg",19);
texture = createTexture2("/pic/PGI06_21.jpg",20);
texture = createTexture2("/pic/PGI06_22.jpg",21);
texture = createTexture2("/pic/PGI06_23.jpg",22);
texture = createTexture2("/pic/PGI06_24.jpg",23);
texture = createTexture2("/pic/PGI06_25.jpg",24);
texture = createTexture2("/pic/PGI06_26.jpg",25);
texture = createTexture2("/pic/PGI06_27.jpg",26);
texture = createTexture2("/pic/PGI06_28.jpg",27);
texture = createTexture2("/pic/PGI06_29.jpg",28);
texture = createTexture2("/pic/PGI06_30.jpg",29);
texture = createTexture2("/pic/PGI06_31.jpg",30);
texture = createTexture2("/pic/PGI06_32.jpg",31);

	
	for(int i=0; i<51; i++)
	{
	part[i]= new particle();
	}

//texture variable somewow needed on a temp basis for creation of t textures

    }//end init()

    public void reshape(GLAutoDrawable glautodrawable, int i, int j, int k, int l)
    {
    }

    public void displayChanged(GLAutoDrawable glautodrawable, boolean flag, boolean flag1)
    {
    }

    public void display(GLAutoDrawable glautodrawable)
    {
        GL gl = glautodrawable.getGL();
        gl.glClear(16640);
        
        gl.glEnable(GL.GL_DEPTH_TEST);
        
        gl.glEnable(GL.GL_COLOR_MATERIAL);
        
        gl.glPolygonMode(GL.GL_FRONT, GL.GL_FILL);
        
        gl.glPolygonMode(GL.GL_BACK, GL.GL_FILL);
        gl.glShadeModel(GL.GL_SMOOTH);
        float af[] = {
            1.0F, 1.0F, 1.0F, 1.0F
        };
        float af1[] = {
            120F
        };
        
        gl.glMaterialfv(GL.GL_FRONT, GL.GL_SPECULAR, af, 0);
        
        gl.glMaterialfv(GL.GL_FRONT, GL.GL_SHININESS, af1, 0);
        
        gl.glLightModeli(GL.GL_LIGHT_MODEL_LOCAL_VIEWER, 1);
        
        gl.glLightModeli(GL.GL_LIGHT_MODEL_TWO_SIDE, 0);

        float af2[] = {
            1.0F, 1.0F, 1.0F, 1.0F
        };
        float af3[] = {
            0.8F, 0.8F, 0.8F, 0.8F
        };
        float af4[] = {
            0.8F, 0.8F, 0.8F, 1.0F
        };
        float af5[] = {
            0.8F, 0.8F, 0.8F, 1.0F
        };
        
        gl.glLightfv(GL.GL_LIGHT0, GL.GL_POSITION, af2, 1);
        gl.glLightfv(GL.GL_LIGHT0, GL.GL_AMBIENT, af3, 0);
        gl.glLightfv(GL.GL_LIGHT0, GL.GL_DIFFUSE, af4, 0);
        gl.glLightfv(GL.GL_LIGHT0, GL.GL_SPECULAR, af5, 0);
        gl.glEnable(GL.GL_LIGHTING);
        gl.glEnable(GL.GL_LIGHT0);


//______________________________ground

gl.glColor3f(0.2F, 0.6F, 0.2F);
gl.glPushMatrix();

//rotate to lay flat
gl.glTranslatef(0.0F, -250.0F, 00F); // Lower the ground
gl.glRotatef(90, 1.0F, 0.0F, 0.0F);

gl.glRectf(-1000F, -1000F, 1000.0F, 1000.0F);

gl.glPopMatrix();
//______________________________

        gl.glColor3f(0.3F, 0.8F, 0.3F);

//crosshairs
        gl.glPushMatrix();
        gl.glRotatef(-spin, 1.0F, 1.0F, 1.0F);
        gl.glRectf(-1F, -1F, 1.0F, 1.0F);
        gl.glPopMatrix();
        gl.glColor3f(1.0F, 0.0F, 0.0F);
        
        gl.glBegin(3);
        gl.glVertex3i(-10, 0, 0);
        gl.glVertex3i(10, 0, 0);
        gl.glEnd();
        
        gl.glBegin(3);
        gl.glVertex3i(0, 10, 0);
        gl.glVertex3i(0, -10, 0);
        gl.glEnd();
        
        gl.glBegin(3);
        gl.glVertex3i(0, 0, 10);
        gl.glVertex3i(0, 0, -10);
        gl.glEnd();


       spin = spin + 1.0F;
        if(spin >= 720F)
            spin = 0.0F;
        gl.glPushMatrix();//-------------------------------------push level1
        gl.glTranslatef(0.0F, 0.0F, 50F); // go to 2nd middle (camera is 1st mid)
        gl.glRotatef(spin / 2.0F, 0.0F, 1.0F, 0.0F);

        //----cords for glow wire sphere
        gl.glTranslatef(200F, 100F, 12F);
        
        gl.glLightfv(GL.GL_LIGHT0, GL.GL_POSITION, af2, 1);
        
        gl.glDisable(GL.GL_LIGHTING);
        gl.glColor3f(1.0F, 1.0F, 100F);
        glut.glutWireSphere(5D, 20, 20);
        gl.glEnable(GL.GL_LIGHTING);
        gl.glPopMatrix();//------------------------------------pop level1



        gl.glPushMatrix();//----------------push level 1 before spin (camera loc)
        gl.glTranslatef(0.0F, 0.0F, 50F); //go to 2nd middle  (so not in same place as camera)
        gl.glRotatef(spin, 0.0F, 1.0F, 0.0F);

        amt.enable();
        amt.bind();

        
    
        gl.glCallList(box);//----first logo
	  
        gl.glPushMatrix();//--------------------------push level 2 with spin
        gl.glTranslatef(0.0F, 0.0F, 20F); //goto 2nd logo
        gl.glRotatef(180F, 0.0F, 1.0F, 0.0F); //flip logo

        gl.glCallList(box);// ----------2nd logo
	  
        gl.glPopMatrix();//---------------------------pop level 2 (back to 1 with spin
        gl.glPopMatrix();//--------------------------pop level 1 back to camloc no spin
        gl.glTranslatef(0.0F, 0.0F, 50F); //go to 2nd middle  (so not in same place as camera)

 amt.disable();

        t[texloop].enable();
	t2[texloop].enable();

        
//------------------------------------------------------------



        for(int i = 1; i < 50; i++)
        {



          if(i%2==1)t[texloop].bind();
	   if(i%2==0)t2[texloop].bind();

           
gl.glPushMatrix();//-------push level 1, should be at 2nd mid

         gl.glTranslatef(part[i].x, part[i].y, part[i].z);
 

	gl.glRotatef(spin / 2.0F, 0.0F, 1.0F, 0.0F);

            gl.glCallList(box);



distance=(float)Math.sqrt(part[i].x * part[i].x + part[i].y * part[i].y + part[i].z * part[i].z);

//distance=(float)Math.sqrt(part[i].x * part[i].x + part[i].y * part[i].y );//----2D


if(distance <=5)distance=5;//-----force limit


force=pcharge/(distance * distance);


if(part[i].x>0) part[i].xacel=-(float)(force * Math.cos(Math.atan(part[i].y/part[i].x)));
if(part[i].x<0) part[i].xacel= (float)(force * Math.cos(Math.atan(part[i].y/part[i].x)));


if(part[i].y>0) part[i].yacel=-(float)(force * Math.cos(Math.atan(part[i].x/part[i].y)));
if(part[i].y<0) part[i].yacel= (float)(force * Math.cos(Math.atan(part[i].x/part[i].y)));

if(part[i].z>0) part[i].zacel=-(float)(force * Math.cos(Math.atan(part[i].x/part[i].z)));
if(part[i].z<0) part[i].zacel= (float)(force * Math.cos(Math.atan(part[i].x/part[i].z)));




part[i].move();

gl.glPopMatrix(); // ----------Pop level 1 go back to 2nd mid
        }//------------------------------------end for each particle





if (t[texloop] != null) t[texloop].disable();
if (t2[texloop] != null) t2[texloop].disable();


        
        //gl.glPopMatrix();// do not think this is needed.


        sdis = (float)(((double)sightradius * Math.cos(ydirection) * Math.sin(direction) * (double)scale) / 10D);
        cdis = (float)(((double)sightradius * Math.cos(ydirection) * Math.cos(direction) * (double)scale) / 10D);


if (backup>=0) 
{
	backup--;
	down=1;
	if(backup==0){ backup=-1; down=0;}
}



        if(up == 1)
        {
            cx += cdis;
            cz -= sdis;
            lz -= sdis;
            lx += cdis;
            if((double)cy + (double)sightradius * Math.sin(ydirection) > 3D)
            {
                cy += ((double)sightradius * Math.sin(ydirection) * (double)scale) / 10D;
                ly += ((double)sightradius * Math.sin(ydirection) * (double)scale) / 10D;
            }
        }
        if(left == 1)
        {
            direction += 0.050000000000000003D;
            if(direction > 2.0F * PI)
                direction -= 2.0F * PI;
            lx = (float)((double)cx + (double)sightradius * Math.cos(ydirection) * Math.cos(direction));
            lz = (float)((double)cz - (double)sightradius * Math.cos(ydirection) * Math.sin(direction));
        }
        if(right == 1)
        {
            direction -= 0.050000000000000003D;
            if(direction < -2F * PI)
                direction += 2.0F * PI;
            lx = (float)((double)cx + (double)sightradius * Math.cos(ydirection) * Math.cos(direction));
            lz = (float)((double)cz - (double)sightradius * Math.cos(ydirection) * Math.sin(direction));
        }
        if(down == 1)
        {
            cz += sdis;
            cx -= cdis;
            lx -= cdis;
            lz += sdis;
            if((double)cy - (double)sightradius * Math.sin(ydirection) > 3D)
            {
                cy -= ((double)sightradius * Math.sin(ydirection) * (double)scale) / 10D;
                ly -= ((double)sightradius * Math.sin(ydirection) * (double)scale) / 10D;
            }
        }
        if(pup == 1 && (double)ydirection <= (double)(PI / 2.0F) + 0.050000000000000003D)
        {
            ydirection += 0.050000000000000003D;
            lx = (float)((double)cx + (double)sightradius * Math.cos(ydirection) * Math.cos(direction));
            lz = (float)((double)cz - (double)sightradius * Math.cos(ydirection) * Math.sin(direction));
            ly = (float)((double)cy + (double)sightradius * Math.sin(ydirection));
        }
        if(pdown == 1 && (double)ydirection >= (double)(-PI / 2.0F) + 0.050000000000000003D)
        {
            ydirection -= 0.050000000000000003D;
            lx = (float)((double)cx + (double)sightradius * Math.cos(ydirection) * Math.cos(direction));
            lz = (float)((double)cz - (double)sightradius * Math.cos(ydirection) * Math.sin(direction));
            ly = (float)((double)cy + (double)sightradius * Math.sin(ydirection));
        }
        gl.glLoadIdentity();
        gl.glLoadIdentity();
        glu.gluLookAt(cx, cy, cz, lx, ly, lz, 0.0D, 1.0D, 0.0D);

if(tswitch<0)texloop++;
tswitch=-tswitch;
if(texloop>=32) texloop=0;

    }

    public static void main(String args[])
    {

	
	//this has to come before member variables can be ref. nostatically
        firework firework = new firework();

	
	

        firework.setVisible(true);


    }

    public GLU glu;
    public GLUT glut;
    public Texture texture;
    public Texture amtexture;
    public Texture[] t;
    public Texture[] t2;
    public Texture amt;
    public static int clip = 3000;
    public static float PI = 3.141593F;
    public float scale;
    public float direction;
    public float ydirection;
    public static int sightradius = 40;
    public float cx;
    public float cy;
    public float cz;
    public float lx;
    public float ly;
    public float lz;
    public int backup=200;
    public int up;
    public int down;
    public int right;
    public int left;
    public int pup;
    public int pdown;
    public float sdis;
    public float cdis;
    public float spin;
    public int box;
    public int texloop=0;
    public int tswitch=1;
    public int boxsize=40;
    public float[] randx =new float[51];
    public float[] randy =new float[51];
    public float[] randz =new float[51];
    public particle part[]= new particle[51];
    
     	


//inner[] innerobj = new inner[10]; 



    public float distance;
    public float force;
    public float pcharge=1000;

}//end firework class
