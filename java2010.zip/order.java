import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import java.text.*;
import java.lang.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;




public class order extends HttpServlet {
//--------------------Start the DoPost function-----------------------
     public void doPost(HttpServletRequest request, HttpServletResponse response)
     throws IOException {

String url="jdbc:mysql://localhost:3306/ampyro69_inventory?autoReconnect=true";
response.setContentType ("text/html;charset=utf-8");
PrintWriter out = response.getWriter();  
DecimalFormat df = new DecimalFormat("'$'0.00");

String name= request.getParameter("user");
String pass= request.getParameter("pass");
String ordnum=request.getParameter("ordnum");
String restricted=request.getParameter("restricted");
String cases=request.getParameter("cases");
String percase=request.getParameter("percase");
String qty = request.getParameter("qty");
String product= request.getParameter("product");
String flager= request.getParameter("flag");
String indx= request.getParameter("indx");//for identifying rec. to change qty

int cnt=0;

if( Integer.parseInt(flager)==2) cnt=2;// flag to delete record 
if( Integer.parseInt(flager)==3) cnt=3;// flag to save record or not
if( Integer.parseInt(flager)==4) cnt=4;// flag to view shopping cart
if( Integer.parseInt(flager)==5) cnt=5;// flag to delete order
if( Integer.parseInt(flager)==6) cnt=6;// flag to update account info

if(restricted==null || restricted.length()==0) restricted="no";
if(qty==null || qty.length()==0) qty="1";
if(cases==null || cases.length()==0) cases="Individual Items";
if(percase==null || percase.length()==0) percase="1";
if(ordnum==null || ordnum.length()==0) ordnum="1";


qty= Integer.toString((int)Float.parseFloat(qty));


//-----------------------------------------------Account update variables-------
String person= request.getParameter("person");
String company= request.getParameter("company");
String email= request.getParameter("email");
String phone= request.getParameter("phone");
String addy1= request.getParameter("addy1");
String addy2= request.getParameter("addy2");
String city= request.getParameter("city");
String state= request.getParameter("state"); 
String zip= request.getParameter("zip");
String atfnum= request.getParameter("atfnum");
//----------end account variables



//-------------------javascript submit order form checker--------------------
out.println(" <script language=JavaScript><!-- // ignore if non-JS browser");
out.println("function checkForm(theForm) {");
out.println("if(theForm.email.value.length <4 || theForm.day.value.length < 4  ){");   
out.println("alert('Please make sure your email addy and pickup date fields are filled in.');");
out.println("return false;}");     
out.println("return true;");
out.println("}");
out.println("--></script>");
//-------------------end of order form checker-----



//--print instructions-----------------------
out.println("<html><p>This is your invoice page, here you may view, delete, or change the # of items you have ordered. To add more product, just close this page, the catalog form should still be open in another window or tab. To change the # of items ordered, simply erase the old quantity, then enter the new quantity and hit the UPDATE button for the product you wish to edit. <P><b>Our inventory is constantly being updated.  This means that if you created this invoice more than 1 day ago and have not yet submitted it, you are not likely to receive everything on it.</center></b><p>");

//-- End instructions------------------




//________________BUILD QUERRIES BELOW FOR FORM__________

String query="SELECT orders.usrname, orders.product, orders.quantity,  FireOne.Sizes, FireOne.Description, orders.id, FireOne.Wholesale, FireOne.percase, FireOne.VendorNumber, FireOne.QtyLeft, FireOne.Type, orders.ordnum, FireOne.ATFtype, FireOne.vid, FireOne.masternum FROM orders INNER JOIN FireOne ON orders.product = FireOne.ProductNumber where ((  orders.usrname='" +name+"')AND (orders.ordnum='"+ordnum+"')  ) order by id";
String namelookup="SELECT name, pass, person, company, email, phone, addy1, addy2, city, state, zip, atfnum FROM login WHERE ((name ='"+name+ "') AND (pass='"+pass+"'))";
String updinfoq="UPDATE login SET person='"+person+"', company='"+company+"', email='"+email+"', phone='"+phone+"', addy1='"+addy1+"', addy2='"+addy2+"', city='"+city+"', state='"+state+"', zip='"+zip+"', atfnum='"+atfnum+"' WHERE ((name ='"+name+ "') AND (pass='"+pass+"'))";
String updateqry="UPDATE orders SET quantity = '"+qty+"' WHERE (usrname='"+name+"' AND id='"+indx+"' AND orders.product='"+product+"')";
String delqry=" DELETE  FROM orders WHERE (usrname='"+name+"' AND id='"+indx+"' AND orders.product='"+product+"')";
String delallqry=" DELETE  FROM orders WHERE (usrname='"+name+"' AND orders.ordnum='"+ordnum+"')";
String addqry="INSERT INTO orders ( usrname, product, quantity, ordnum) VALUES('"+name+"', '"+product+"', '"+qty+"', '"+ordnum+"')";

//------------------This fetches a recordset(filtered)-------------------------------------
out.println("<p>");	

try{						
Class.forName  ("com.mysql.jdbc.Driver");
Connection con = DriverManager.getConnection(url, "ampyro69_Rob", "eugene19" );

Statement stmt = con.createStatement ();
Statement upd = con.createStatement ();
Statement delete = con.createStatement ();
Statement deleteall = con.createStatement ();
Statement updinfo= con.createStatement (); // account information
Statement add=  con.createStatement ();
Statement validate= con.createStatement ();//login

//--------------------------------------case modification---------
if (cases.equalsIgnoreCase("cases")){ 
addqry="INSERT INTO orders ( usrname, product, quantity, ordnum) VALUES('"+name+"', '"+product+"', '"+Integer.parseInt(qty) * Integer.parseInt(percase) +"', '"+ordnum+"')";
}//this overrides addqry to insert iqty instead of #cases


if(cnt==0) add.executeUpdate(addqry);    // adds item to order
if(cnt==2) delete.executeUpdate(delqry); // deletes item from order
if(cnt==3) upd.executeUpdate(updateqry); // updates quantity on order
// cnt 4 does nothing, just for viewing invoice....
if(cnt==5) deleteall.executeUpdate(delallqry);

if(cnt==6) updinfo.executeUpdate(updinfoq); // updates account info


ResultSet rs = stmt.executeQuery (query);//-----------gets data

ResultSet validaters =validate.executeQuery (namelookup);//------login and account info 
// namelookup="SELECT name1, pass2, person3, company4, email5, phone6, addy1 7, addy2 8, city 9, 
//state 10, zip 11, atfnum 12 FROM login WHERE ((name ='"+name+ "') AND (pass='"+pass+"'))";



//------------------end record fetcher----------------------------------------------------


 
//-----------------------------Displays querry results--------------------------------------  



if(validaters.next())
{
   


out.println("<font size=5>Order #"+ordnum+" For "+validaters.getString(3)+"</font><p>");


out.println("<table border=1 cellpadding=2 width=100%>");
out.println("<tr> <td><b>Vendor<td><b>Prod#<td><b>Qty<td><b>Size <td><b>Description <td><b>Price<td><b>Total<td>Type<td>delete<td><b>B.C. Charge<tr> ");


int numCols = rs.getMetaData().getColumnCount ();
float total=0;
float brokecase=0;
String tempstr;
String tempstr2;
String tempstr3;
String tempstr4;
String tempstr5;
String tempstr6;
String tempstr7;//atftype
String tempvid;
String tempstr8;//amd

                 while ( rs.next() )
		 {
		  out.println("<tr>");
 tempvid=rs.getString(14);
               	  for (int i=1; i<=numCols; i++) 
		  {   

// orders.usrname 1, orders.product 2, orders.quantity 3,  FireOne.Sizes 4, FireOne.Description 5, orders.id 6,
//FireOne.Wholesale 7, FireOne.percase 8, FireOne.VendorNumber 9, FireOne.QtyLeft 10, FireOne.Type 11, orders.ordnum 12,
//FireOne.ATFtype 13, FireOne.vid 14, FireOne.masternum 15 

if(i ==1) out.print("<td>" + rs.getString(9) + "</td>" );//vendor
                
if(i !=1 && i !=2 && i!=3 && i!=5 && i!=6 && i!=7 && i!=8  && i!=9 && i!=10 && i!=11 && i!=12 && i!=14 && i!=15) out.print("<td>" + rs.getString(i) + "</td>" );


if(  i==2 && rs.getString(11).equalsIgnoreCase("assortment") ) out.print("<td>"+rs.getString(2)+"<form method=post action=/test/aview target=_BLANK><input type=hidden name=product value='" +rs.getString(2)+"'><input type=submit value='View Items'></form>");


if(  i==2 && !rs.getString(11).equalsIgnoreCase("assortment") && (tempvid ==null || tempvid.length()==0 )) out.print("<td>"+rs.getString(2));


/****************************************************/

// orders.usrname 1, orders.product 2, orders.quantity 3,  FireOne.Sizes 4, FireOne.Description 5, orders.id 6,
//FireOne.Wholesale 7, FireOne.percase 8, FireOne.VendorNumber 9, FireOne.QtyLeft 10, FireOne.Type 11, orders.ordnum 12,
//FireOne.ATFtype 13, FireOne.vid 14, FireOne.masternum 15 

if(  i==2 && !rs.getString(11).equalsIgnoreCase("assortment") && tempvid !=null && tempvid.length()!=0)
{
 out.print("<td>"+rs.getString(2)+"<br><a href='http://www.ampyro.com/video/" +rs.getString(15)+".wmv' target=_BLANK> Watch Video</a>");

}

/********************************************************/




//---------------------Below is for qty change update
if(i==3){
out.println("<td><form method=post action=/test/saverec > <input type=text name=qty size=4 value='"+rs.getString(i)+"'><input type=hidden name=user value='"+name+"'><input type=hidden name=ordnum value='"+ordnum+"'><input type=hidden name=product value='"+rs.getString(2) +"'><input type=hidden value=3 name=flag> <input type=hidden name=pass value='"+pass+"'><input name=indx type=hidden value='"+rs.getString(6)+"'>"); 




if(restricted.equalsIgnoreCase("no"))out.println("<input type=submit value=update>");
out.println("</form>");

out.println(Float.parseFloat(rs.getString(3))/ Float.parseFloat(rs.getString(8))+" cases");

}//-----end if

if(i ==5) out.print("<td>" + rs.getString(5) + " (" + rs.getString(8) + " per case)</td>" );//add percase to descrip

if(i==7){


if(name.equalsIgnoreCase("test")) {out.println("<td>&nbsp;<td>&nbsp;");}


if(!name.equalsIgnoreCase("test")) {out.println("<td>"+df.format(Float.parseFloat(rs.getString(i)))+"<td>"+df.format((Float.parseFloat(rs.getString(i)) * Float.parseFloat(rs.getString(3)))));}



}//end if


                  }  // ----------end for

out.println("<td><form method=post action=/test/saverec target=_BLANK> <input type=hidden name=qty size=4><input type=hidden name=user value='"+name+"'><input type=hidden name=ordnum value='"+ordnum+"'> <input type=hidden name=product value='"+rs.getString(2) +"'><input name= indx type=hidden value='"+rs.getString(6)+"' ><input type=hidden name=pass value='"+pass+"'><input type=hidden value=2 name=flag>");

if(restricted.equalsIgnoreCase("no"))out.println("<input type=submit value=delete onClick=\"return confirm('Are you sure you want to remove this item from your order? Click OK if you no longer want this item.');\">");
out.println("</form><td>");


total+=(Float.parseFloat(rs.getString(7)) * Float.parseFloat(rs.getString(3)));

tempstr=rs.getString(4) ;
tempstr2="12 inch";
tempstr3="10 inch";
tempstr4="Caballer";
tempstr5="LaRosa";
tempstr6="ematch";
tempstr7="equipment";
tempstr8="AMPYRO-D";


//orders.usrname1, orders.product2, orders.quantity3,  FireOne.Sizes4, FireOne.Description5, orders.id6, 
// FireOne.Wholesale7, FireOne.percase8, FireOne.VendorNumber9, FireOne.QtyLeft10 , atftype 13
                

//--------------------------------START BROKEN CASE-------------------
 if(!name.equalsIgnoreCase("test"))
{

if(!tempstr4.equalsIgnoreCase(rs.getString(9))  && !tempstr7.equalsIgnoreCase(rs.getString(13))&& !tempstr5.equalsIgnoreCase(rs.getString(9)) && !tempstr8.equalsIgnoreCase(rs.getString(9)) && !tempstr6.equalsIgnoreCase(rs.getString(13)) && !tempstr.equalsIgnoreCase(tempstr3) && !tempstr.equalsIgnoreCase(tempstr2) && java.lang.Integer.parseInt(rs.getString(10))> java.lang.Integer.parseInt(rs.getString(8)) ) out.println(df.format( (.1*Float.parseFloat(rs.getString(7))*(Float.parseFloat(rs.getString(3))%Float.parseFloat(rs.getString(8))  ) ) ));
else out.println("$0.00");





if(!tempstr4.equalsIgnoreCase(rs.getString(9))   && !tempstr7.equalsIgnoreCase(rs.getString(13)) && !tempstr5.equalsIgnoreCase(rs.getString(9)) && !tempstr8.equalsIgnoreCase(rs.getString(9))  && !tempstr6.equalsIgnoreCase(rs.getString(13)) && !tempstr.equalsIgnoreCase(tempstr3) && !tempstr.equalsIgnoreCase(tempstr2) && java.lang.Integer.parseInt(rs.getString(10))> java.lang.Integer.parseInt(rs.getString(8)) ) brokecase+=(Float.parseFloat(rs.getString(7))*(Float.parseFloat(rs.getString(3))%Float.parseFloat(rs.getString(8))  )  );

}//------------end hide brokecase from test user

                  out.println("</tr>");
                  }  // ---------end while

out.println("</table><p><p>");
if(!name.equalsIgnoreCase("test")) out.println("<br><font size=6> Subtotal: "+ df.format(total) +"<p>");

if(!name.equalsIgnoreCase("test")) out.println("<font size=6> Broken  Case Charge: "+df.format(.1* brokecase)+"<p>" );

if(!name.equalsIgnoreCase("test")) out.println("<font size=6> <b>Grand total: <u>"+df.format(.1* brokecase+total)+"</u></b></font><p>" );

if(restricted.equalsIgnoreCase("no")) out.println("<form method=post action=/test/saverec><input type=hidden name=ordnum value='"+ordnum+"'> <input type=hidden name=pass value='"+pass+"'><input type=hidden name=user value='"+name+"'><input type=hidden value=5 name=flag> <input type=submit value='Delete All Items' onClick=\"return confirm('Are you sure you want to delete all of your items?');\"></form><p><hr width=90% color=red><p>"  );



if(!name.equalsIgnoreCase("test")){ 
out.println("<b><font size=3>Enter your email address and pickup/delivery date here and click <B>SUBMIT ORDER</B> to submit your order.  Modifying a submitted order is deceptively simple.  Just add product, delete product, or modify the quantities of product on your order and resubmit the order.  <p>Please fax a valid signed, current copy of your ATF license along with a <a href=../downloads/custform.doc>Customer Information Form</a> if you have not yet done so to 417-267-3798<form method=post action=/test/mail onsubmit='return checkForm(this);'>Email:<br><input type=text name=email value='"+validaters.getString(5)+"' ><br>Note to us:<br> <input type=text name=notes maxlength=500 size=200> <br>Delivery/Pickup Date<br><input type=text name=day maxlength=20 size=20> <input type=hidden name=pass value='"+pass+"'><input type=hidden name=user value='" +name+ "'> <input type=hidden name=ordnum value='"+ordnum+"'> <input type=submit value='Submit Order'> <font size=5 color=red><---Click Here to Send Your Order to Us.</font></form>  <p>"  );
}




//ResultSet validaters =validate.executeQuery (namelookup);//------login and account info 
// namelookup="SELECT name1, pass2, person3, company4, email5, phone6, addy1 7, addy2 8, city 9, 
//state 10, zip 11, atfnum 12 FROM login WHERE ((name ='"+name+ "') AND (pass='"+pass+"'))";


out.println("<td><table border=1 cellpadding=2 cellspacing=0 width=100%><tr><td>");
out.println("<table border=0 cellpadding=2 cellspacing=0 width=100%>");
out.println("<form method=post action=/test/saverec><tr><td colspan=2 bgcolor=grey width=100%><center><b>Customer Information</b> (Please keep updated)</center>");
out.println("<input type=hidden name=user value='"+name+"'><input type=hidden name=ordnum value='"+ordnum+"'><input type=hidden value=6 name=flag> <input type=hidden name=pass value='"+pass+"'>");
out.println("<tr><td>Name:    <td><input type=text size=50 name=person value='"+validaters.getString(3)+"'>");
out.println("<tr><td>ATF #:   <td><input type=text size=50 name=atfnum value='"+validaters.getString(12)+"'>");
out.println("<tr><td>Company: <td><input type=text size=50 name=company value='"+validaters.getString(4)+"'>");
out.println("<tr><td>Email:   <td><input type=text size=50 name=email value='"+validaters.getString(5)+"'>");
out.println("<tr><td>Phone:   <td><input type=text size=50 name=phone value='"+validaters.getString(6)+"'>");
out.println("<tr><td>Address: <td><input type=text size=50 name=addy1 value='"+validaters.getString(7)+"'>");
out.println("<tr><td>Address2:<td><input type=text size=50 name=addy2 value='"+validaters.getString(8)+"'>");

out.println("</table><tr><td>City:<input type=text size=20 name=city value='"+validaters.getString(9)+"'>"); 
out.println("State:<input type=text size=10 name=state value='"+validaters.getString(10)+"'>"); 
out.println("Zip:<input type=text size=10 name=zip value='"+validaters.getString(11)+"'>");
out.println("<tr><td><input type=submit value='Save Info'></form></table></table>");









//_________________________________Discount calculator_____________________________________

out.println("<hr width=100% color=red><p><center><font size=5>Discounted Total Calculator</font></center>");


if(!name.equalsIgnoreCase("test")) 
{
out.println("<SCRIPT LANGUAGE='JavaScript'><!--");
out.println("function Calculate(Atext, form){var A = parseFloat(Atext);  ");

out.println("form.distotal.value =Math.round((1- A) *"+(.1* brokecase+total)+");}");

out.println("//--></SCRIPT>  <FORM NAME='disc' METHOD='post'><font size=3><P>Enter your expected discount in decimal format (10%=.1): <INPUT TYPE=TEXT NAME='disdec' SIZE=5></P><P><INPUT TYPE='button' VALUE='Calculate Discount' name='calcButton' onClick='Calculate(this.form.disdec.value, this.form)'></P><P>Discounted Total ~ $<INPUT TYPE=TEXT NAME='distotal' SIZE=20 style='font-size: 20px' /></font></P></FORM>");

}//end if not guest

//______________________________________________________________________________















//---------------------------end querry display----------------------------------------

rs.close();
stmt.close();

add.close();
delete.close();
deleteall.close();
upd.close();

validaters.close();
validate.close();

con.close();

}//-------------------end login if--------
else{out.println("<font size=6 color=red>Your login has failed!</font><br><br>"+
"<a href=login.html>Click Here to Try Again, good luck!</a>");}

 }  // end try
        catch (SQLException ex) {           		
	        response.setContentType("text/html");			
		while (ex != null) {  
                	out.println ("SQL Exception:  " + ex.getMessage ());
                	ex = ex.getNextException ();  
              }  // end while
        }  // end catch SQLException

        catch (java.lang.Exception ex) {
      			response.setContentType("text/html");	
		out.println ("Exception:  " + ex.getMessage ());
	  }




}// ------------end dopost() function----------


//______________________________Start doget()__________
//______________________________Start doget()__________
//______________________________Start doget()__________

/*

public void doGet(HttpServletRequest request, HttpServletResponse response)
     throws IOException {



    }// ------------end doget() function----------

*/
}//------------end order class-------------

      
 
