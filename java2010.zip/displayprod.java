import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;


public class displayprod extends HttpServlet {

     public void doGet(HttpServletRequest request, HttpServletResponse response)
     throws IOException {
 

String url="jdbc:mysql://localhost:3306/ampyro69_inventory?autoReconnect=true";
	
String query = "select ProductNumber, VendorNumber, Sizes, Shot, Description, QtyLeft, PerCase, PerChain, ATFtype, Wholesale  from FireOne where( Sizes='3 inch')";
						
	try {
Class.forName  ("com.mysql.jdbc.Driver");
Connection con = DriverManager.getConnection(url, "ampyro69_Rob", "eugene19" );

            Statement stmt = con.createStatement ();
            ResultSet rs = stmt.executeQuery (query);


 
PrintWriter out = response.getWriter();       

 out.println("<table border='1'>");

           	int numCols = rs.getMetaData().getColumnCount ();
                while ( rs.next() ) {
		  out.println("<tr>");
               	  for (int i=1; i<=numCols; i++) {
                    out.print("<td>" + rs.getString(i) + "</td>" );
                  }  // end for
                  out.println("</tr>");
                }  // end while

out.println("</table>");



            rs.close();
            stmt.close();
            con.close();

        }  // end try
        catch (SQLException ex) {           
		PrintWriter out = response.getWriter();
	        response.setContentType("text/html");			
		while (ex != null) {  
                	out.println ("SQL Exception:  " + ex.getMessage ());
                	ex = ex.getNextException ();  
              }  // end while
        }  // end catch SQLException

        catch (java.lang.Exception ex) {
      	PrintWriter out = response.getWriter();
		response.setContentType("text/html");	
		out.println ("Exception:  " + ex.getMessage ());
	  }

   
  


    }
}

      
