import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import java.text.*;
import java.util.*; 
import java.lang.String;


public class badass extends HttpServlet {


//--------------------Start the DoPost function-----------------------
     public void doPost(HttpServletRequest request, HttpServletResponse response)
     throws IOException {

doGet(request, response);

    }// ------------end dopost() function----------


//______________________________Start doget()__________
//______________________________Start doget()__________
//______________________________Start doget()__________




public void doGet(HttpServletRequest request, HttpServletResponse response)
     throws IOException {


String browserType = request.getHeader("User-Agent");
browserType = browserType.toLowerCase();

String url="jdbc:mysql://localhost:3306/ampyro69_inventory?autoReconnect=true";

response.setContentType ("text/html;charset=utf-8");

PrintWriter out = response.getWriter();  

DecimalFormat df = new DecimalFormat("'$'0.00");


//------Date Stuff--------------
java.util.Date today;
today = new java.util.Date();
SimpleDateFormat formatdate;
Locale here= new Locale("en", "US");

formatdate= new SimpleDateFormat("yyyy-M-dd",here);


//"2010-1-01";
String progdate;

progdate=formatdate.format(today);

//--------end date stuff------------------------


String vendor = request.getParameter("vendor");
String size= request.getParameter("size");
String shot= request.getParameter("shot");
String groupname= request.getParameter("groupname");
String type= request.getParameter("type");
String name= request.getParameter("name");
String pass= request.getParameter("pass");
String ordnum=request.getParameter("ordnum");
String jhak="";
String divhak="";
//String locnot= request.getParameter("locnot");
String restricted=request.getParameter("restricted");
String cases=request.getParameter("cases");



String vendorselect="Empty";
String typeselect="Empty";
String groupselect="Empty";
String shotselect="Empty";
String sizeselect="Empty";


if(cases==null || cases.length()==0) cases="Individual Items";


//locnot="transit";


//____________________________________________________For sale price


String linecolor="white";


//____________________________________________________








out.print(" <script language=JavaScript><!-- // ignore if non-JS browser \n");

out.print("function checkForm(theForm) {\n");

out.print("if (parseInt(theForm.qty.value) >parseInt(theForm.qleft.value) || isNaN(parseInt(theForm.qty.value))){\n");
  
out.print("alert('Sorry, we do not have that many.  Please try again.');\n");
out.print("return false;}\n");
       
out.print("return true;\n");
out.print("}\n");
out.print("//-->\n</script>\n");



//String restricted="yes";

//if(name.equalsIgnoreCase("Deadly Detonating Dave")) restricted="no";
//if(name.equalsIgnoreCase("elite")) restricted="no";
if(name.equalsIgnoreCase("rob")) restricted="no";

String wwb=request.getParameter("wwb");


String namelookup="SELECT name, pass, person FROM login WHERE ((name ='"+name+ "') AND (pass='"+pass+"'))";

String maxorder="SELECT orders.usrname, Max(orders.ordnum) AS MaxOfordnum FROM orders GROUP BY orders.usrname HAVING (((orders.usrname)='"+name+"'))";

if(restricted==null || restricted.length()==0 ||  ( !restricted.equalsIgnoreCase("yes") || !restricted.equalsIgnoreCase("no")  )) restricted="no";


if(vendor==null || vendor.length()==0) vendor="%";
if(size==null || size.length()==0) size="%";
if(shot==null || shot.length()==0) shot="%";
if(groupname==null || groupname.length()==0) groupname="%";
if(type==null || type.length()==0) type="%";
//if(locnot==null || locnot.length()==0) locnot="fake";



if(wwb==null || wwb.length()==0) wwb="2020-1-01";


//---------------------------------------Output a form----------------








//________________BUILD QUERIES BELOW FOR FORM__________

if(cases.equalsIgnoreCase("Cases"))
{

vendorselect="SELECT VendorNumber, Type, Sizes, Shot, groupname FROM FireOne WHERE ((FireOne.Sizes like '"+size+"') AND (Type like '"+type+"') AND (Shot like '"+shot+"') AND (groupname like '"+groupname+"') AND QtyLeft >= PerCase AND listonline <> 0) GROUP BY VendorNumber";

sizeselect="SELECT Sizes, Type, VendorNumber, Shot, groupname FROM FireOne  WHERE ((VendorNumber like '"+vendor+"') AND (Type like '"+type+"') AND (Shot like '"+shot+"') AND (groupname like '"+groupname+"') AND QtyLeft >= PerCase AND listonline <>0) GROUP BY Sizes";

shotselect="SELECT Shot, Type, VendorNumber, Sizes, groupname FROM FireOne WHERE ((Sizes like '"+size+"') AND (Type like '"+type+"') AND (VendorNumber like '"+vendor+"') AND (groupname like '"+groupname+"') AND QtyLeft >= PerCase  AND listonline <>0) GROUP BY Shot";

groupselect="SELECT groupname, Type, VendorNumber, Sizes, Shot FROM FireOne WHERE ((Sizes like '"+size+"') AND (Shot like '"+shot+"') AND (VendorNumber like '"+vendor+"') AND (Type like '"+type+"') AND QtyLeft >= PerCase  AND listonline <>0) GROUP BY groupname ";

typeselect="SELECT Type, groupname, VendorNumber, Sizes, Shot FROM FireOne WHERE ((Sizes like '"+size+"') AND (Shot like '"+shot+"') AND (groupname like '"+groupname+"') AND  (VendorNumber like '"+vendor+"') AND QtyLeft >PerCase AND listonline <>0) GROUP BY Type ";

}//---------- END FULL CASE FILTERS---------


if(!cases.equalsIgnoreCase("Cases"))
{

vendorselect="SELECT VendorNumber, Type, Sizes, Shot, groupname FROM FireOne WHERE ((FireOne.Sizes like '"+size+"') AND (Type like '"+type+"') AND (Shot like '"+shot+"') AND (groupname like '"+groupname+"') AND QtyLeft >0 AND listonline <> 0) GROUP BY VendorNumber";

sizeselect="SELECT Sizes, Type, VendorNumber, Shot, groupname FROM FireOne  WHERE ((VendorNumber like '"+vendor+"') AND (Type like '"+type+"') AND (Shot like '"+shot+"') AND (groupname like '"+groupname+"') AND QtyLeft >0 AND listonline <>0) GROUP BY Sizes";

shotselect="SELECT Shot, Type, VendorNumber, Sizes, groupname FROM FireOne WHERE ((Sizes like '"+size+"') AND (Type like '"+type+"') AND (VendorNumber like '"+vendor+"') AND (groupname like '"+groupname+"') AND QtyLeft >0 AND listonline <>0) GROUP BY Shot";

groupselect="SELECT groupname, Type, VendorNumber, Sizes, Shot FROM FireOne WHERE ((Sizes like '"+size+"') AND (Shot like '"+shot+"') AND (VendorNumber like '"+vendor+"') AND (Type like '"+type+"') AND QtyLeft >0 AND listonline <>0) GROUP BY groupname";

typeselect="SELECT Type, groupname, VendorNumber, Sizes, Shot FROM FireOne WHERE ((Sizes like '"+size+"') AND (Shot like '"+shot+"') AND (groupname like '"+groupname+"') AND  (VendorNumber like '"+vendor+"') AND QtyLeft >0 AND listonline <>0) GROUP BY Type ";

}//---------------END individual FILTERS-----------


String ordnumselect="SELECT orders.usrname, orders.ordnum FROM orders WHERE((orders.usrname like '"+name+"')) GROUP BY orders.ordnum order by ordnum";




//------------------This fetches a recordset(filtered)-------------------------------------
	
String query = 
"select ProductNumber, VendorNumber, Sizes, Shot, Description, QtyLeft, " + "PerCase, PerChain, groupname, Type, Wholesale, location, `Date Acquired` , vid , masternum, listonline from FireOne where((VendorNumber like '"
 + vendor + 
"') AND (Sizes like '" 
+ size + 
"') AND (Shot like '" 
+ shot + 
"') AND (groupname like '" 
+ groupname + 
"') AND (Type like '" 
+ type + 
//"') AND (location NOT like '" 
//+ locnot + 
"') AND (`Date Acquired` <='" 
+ wwb + 
"') AND QtyLeft >0 AND listonline <>0 ) order by Sizes, groupname, VendorNumber, Description";



if(cases.equalsIgnoreCase("Cases"))
{
query = 
"select ProductNumber, VendorNumber, Sizes, Shot, Description, QtyLeft, " + "PerCase, PerChain, groupname, Type, Wholesale, location, `Date Acquired` , vid , masternum, listonline from FireOne where((VendorNumber like '"
 + vendor + 
"') AND (Sizes like '" 
+ size + 
"') AND (Shot like '" 
+ shot + 
"') AND (groupname like '" 
+ groupname + 
"') AND (Type like '" 
+ type + 
//"') AND (location NOT like '" 
//+ locnot + 
"') AND (`Date Acquired` <='" 
+ wwb + 
"') AND QtyLeft >= PerCase AND listonline <>0 ) order by Sizes, groupname, VendorNumber, Description";
}


try{						
Class.forName  ("com.mysql.jdbc.Driver");
Connection con = DriverManager.getConnection(url, "ampyro69_Rob", "eugene19" );

Statement stmt = con.createStatement ();

Statement stmtvn = con.createStatement ();//vendor
Statement stmtsz = con.createStatement ();//size
Statement stmtsh = con.createStatement ();//shot
Statement stmttp = con.createStatement ();//group
Statement stmttyp = con.createStatement ();//type
Statement validate= con.createStatement ();//login
Statement stordnum= con.createStatement ();//order number
Statement stmaxorder= con.createStatement(); //for new orders


ResultSet rs = stmt.executeQuery (query);//-----------gets data


ResultSet vendorrs = stmtvn.executeQuery (vendorselect);//-----------gets data
ResultSet sizers = stmtsz.executeQuery (sizeselect);//-----------gets data
ResultSet shotrs = stmtsh.executeQuery (shotselect);//-----------gets data
ResultSet grouprs = stmttp.executeQuery (groupselect);//-----------gets data
ResultSet validaters =validate.executeQuery (namelookup);//------login
ResultSet typers = stmttyp.executeQuery (typeselect);//-----------gets data
ResultSet ordnumrs = stordnum.executeQuery (ordnumselect);//--------for order number
ResultSet maxorderrs = stmaxorder.executeQuery(maxorder);





int mo=1;

try {
            if (maxorderrs.next() ) {
                mo=Integer.parseInt(maxorderrs.getString(2));
            }
            else {
            mo=1;
            }
        }
        catch(Exception e) { //e.printStackTrace();
            //goBack();
        }


//maxorderrs.next();

int neworder=mo+1;





if(ordnum==null || ordnum.length()==0) ordnum= Integer.toString(mo);






//------------------end record fetcher----------------------------------------------------

//start outside table---------------------

if(validaters.next())
{


out.print("<html><head>  <style type='text/css' media=screen> body { margin:0; padding:0; height:100%; font-size:14px;} td{ margin:0; padding:0;  font-size:14px;}  select option{ margin:0; padding:0;  font-size:14px;}   </style></head><body> <div id=firstdiv style='height=9%; width : 100%; overflow:auto'>\n");



out.print("<title>"+validaters.getString(3)+"</title>\n");
//start inside filters table---------
out.print("<table border=1  bordercolor=black cellspacing=1 cellpadding=1 width=100%>\n");
out.print(" <form method=POST action=/test/catalog>\n");


//---------------------------------------VENDOR-----------------------------
if(!vendor.equalsIgnoreCase("%") ) out.print("<tr><td bgcolor=yellow id=dc1>Vendor:<select name=vendor size=1 onchange=this.form.submit();> <option selected>" + vendor + "</option> \n");
if(vendor.equalsIgnoreCase("%") ) out.print("<tr><td id=dc1>Vendor:<select name=vendor size=1 onchange=this.form.submit();> <option selected value=%>ALL</option> \n");

out.print("<option value=%>ALL</option>\n");
while (vendorrs.next()){out.print("<option>" + vendorrs.getString(1));}

out.print("</select>\n");


//----------------------------------------SIZE------------------------------
if(!size.equalsIgnoreCase("%") ) out.print("<td bgcolor=yellow>Size:<select name=size size=1 onchange=this.form.submit();> <option selected>"+size+ "</option> \n");
if(size.equalsIgnoreCase("%")) out.print("<td>Size:<select name=size size=1 onchange=this.form.submit();> <option selected value=%>ALL</option> \n");



out.print("<option value=%>ALL</option>");
while ( sizers.next() ){out.print("<option>" +sizers.getString(1));}  
out.print("</select>\n");


//-------------------------------------------SHOT----------------------------
if(!shot.equalsIgnoreCase("%"))out.print("<td bgcolor=yellow>#&nbsp;Shots:<select name=shot size=1 onchange=this.form.submit();> <option selected>"+shot+ "</option>\n");
if(shot.equalsIgnoreCase("%"))out.print("<td>#&nbsp;Shots:<select name=shot size=1 onchange=this.form.submit();> <option selected value=%>ALL</option>\n");


out.print("<option value=%>ALL</option>\n");
while ( shotrs.next() ){out.print("<option>" +shotrs.getString(1));}  
out.print("</select>\n");


//-----------------------------------------ATF TYPE--------------------------
if(!groupname.equalsIgnoreCase("%"))out.print("<td bgcolor=yellow>Group&nbsp;Type:<select name=groupname size=1 onchange=this.form.submit();> <option selected>"+groupname+ "</option>\n ");
if(groupname.equalsIgnoreCase("%"))out.print("<td>Group&nbsp;Type:<select name=groupname size=1 onchange=this.form.submit();> <option selected value=%>ALL</option>\n ");


out.print("<option value=%>ALL</option>\n");
while ( grouprs.next() ){out.print("<option>" +grouprs.getString(1));}  
out.print("</select>\n");


//----------------------------------------TYPE---------------------------------
if(!type.equalsIgnoreCase("%"))out.print("<td bgcolor=yellow>Type:<select name=type size=1 onchange=this.form.submit();> <option selected>"+type+ "</option>\n ");
if(type.equalsIgnoreCase("%"))out.print("<td>Type:<select name=type size=1 onchange=this.form.submit();> <option selected value=%>ALL</option>\n ");



out.print("<option value=%>ALL</option>\n");
while ( typers.next() ){out.print("<option>" +typers.getString(1));}  
out.print("</select>\n");

/*--------------------------------------------Hide WWB  and transit Filter--------------------
if(locnot.equalsIgnoreCase("transit"))
{
out.print("<tr><td bgcolor=yellow><b>Only Current stock?: </b><td><select name=locnot size=1 onchange=this.form.submit();> <option selected value=transit>Only Current Stock</option> ");
out.print("<option value=fake>Include Future Stock</option>");
out.print("</select>");
}

if(locnot.equalsIgnoreCase("fake"))
{
out.print("<tr><td>Include future stock?:<td><select name=locnot size=1 onchange=this.form.submit();> <option selected value=fake>Include Future Stock</option> ");
out.print("<option value=transit>Only Current Stock</option>");
out.print("</select>");
}


//Old with wwb stock selected filter
if(wwb.equalsIgnoreCase("2009-2-08"))
{
out.print("<tr><td>Include future stock?: </b><td><select name=wwb size=1 onchange=this.form.submit();> <option selected value='2009-2-08'>Only WWB Available Stock</option> ");
out.print("<option value='2010-1-01'>Show All Stock</option>");
out.print("<option value='2009-1-01'>Show Only Current Stock</option>");
out.print("</select>");
}
-------------End  hide transit--------------------*/



//all stock selected
if(wwb.equalsIgnoreCase("2020-1-01"))
{
out.print("<td><select name=wwb size=1 onchange=this.form.submit();><option selected value='2020-1-01'>Show All Stock</option>");
out.print("<option value='"+progdate+"'>Show Current Stock</option></select></td>\n");
}


//current stock
if(wwb.equalsIgnoreCase(progdate))
{
out.print("<td bgcolor=yellow><select name=wwb size=1 onchange=this.form.submit();><option value='2020-1-01'>Show All Stock</option>");
out.print("<option selected value='"+progdate+"'>Show Only Current Stock</option></select></td>\n");
}






out.print("<INPUT type=hidden name=name value='" +name+"'>"+
"<INPUT type=hidden name=ordnum value='"+ordnum+"'>"+
"<INPUT type=hidden name=restricted value='"+restricted+"'>"+
"<INPUT type=hidden name=cases value='"+cases+"'>"+
"<INPUT type=hidden name=pass value='"+pass+"'>");

//---end filters table 
out.print("</form>\n");



/*-------------------------------------End First Line Filters------------- */

out.print("<tr><td id=dc2><form method=post action =/test/catalog>"+
"<INPUT type=submit value='View Equipment'></td>"+
"<INPUT type=hidden name=name value='" +name+"'>"+
"<INPUT type=hidden name=pass value='"+pass+"'>"+
"<INPUT type=hidden name=restricted value='"+restricted+"'>"+
"<INPUT type=hidden name=cases value='"+cases+"'>"+
"<INPUT type=hidden name=ordnum value='"+ordnum+"'>"+
"<INPUT type=hidden name=wwb value='" +wwb+ "'>"+
"<INPUT type=hidden name=groupname value='equipment'></form>\n");

//--------------------------------------------------------END EQUIPMENT BUTTON---------------

out.print("<td><form method=post action =/test/catalog>"+
"<INPUT type=submit value='View Ematches'></td>"+
"<INPUT type=hidden name=name value='" +name+"'>"+
"<INPUT type=hidden name=pass value='"+pass+"'>"+
"<INPUT type=hidden name=ordnum value='"+ordnum+"'>"+
"<INPUT type=hidden name=restricted value='"+restricted+"'>"+
"<INPUT type=hidden name=cases value='"+cases+"'>"+
"<INPUT type=hidden name=wwb value='"+wwb+"'>"+
"<INPUT type=hidden name=groupname value='ematch'></form>"+
"<form method=post action =/test/catalog>"+
"<td><INPUT type=submit value='Clear Filters'></td>"+
"<INPUT type=hidden name=name value='" +name+"'>"+
"<INPUT type=hidden name=restricted value='"+restricted+"'>"+
"<INPUT type=hidden name=pass value='"+pass+"'></form>\n");







//start picture and instructions table----------------

//----TEST JOINING GUEST USERS-------if(!name.equalsIgnoreCase("test"))
//----TEST JOINING GUEST USERS-------{

 
//-------------------------------------------Order #----------------------------



out.print("<form method=POST action=/test/catalog>\n");
out.print("<td valign=top bgcolor=lime>Order Number&nbsp;<select name=ordnum size=1 onchange=this.form.submit();> \n");


int on=1;

int emptynewflag=1;

try {
            if (ordnumrs.first() ) {
            on=Integer.parseInt(ordnumrs.getString(2));

               if(Integer.parseInt(ordnum)==on)
               {
               out.print("<option selected>" +on+"</option>");  
               emptynewflag=0;
               }//-------end if first ordnumber is selected ordnum
               else {
               out.print("<option>" +on+"</option>");  
               }//-----------end of else printing ordnum options


while ( ordnumrs.next() ){
 on=Integer.parseInt(ordnumrs.getString(2));


         if(Integer.parseInt(ordnum)==mo)
         {
         out.print("<option selected>" +on+"</option>");  
         emptynewflag=0;
         }//-------end if ordnumber is max of ordnumbers
         else {
         out.print("<option>" +on+"</option>");  
         }//-----------end of else printing ordnum options

}//-----------end while there are ordnumbers




}//--------------------- end of if there are ord numbers
            else {
            on=1;
            out.print("<option selected>" +on+"</option>");  

            }//-------end of else no ordnumbers
        }//-------------end try for ordnumbers
        catch(Exception e) { //e.printStackTrace();
            //goBack();
        }

if(emptynewflag==0){
out.print("<option value='"+neworder +"'>New ('"+neworder+"' )</option>");
}

if(emptynewflag==1){
out.print("<option selected>" +ordnum+"</option>");  
}


out.print("</select></td>\n");


out.print("<INPUT type=hidden name=name value='" +name+"'>"+
"<INPUT type=hidden name=restricted value='"+restricted+"'>"+
"<INPUT type=hidden name=cases value='"+cases+"'>"+
"<INPUT type=hidden name=ordnum value='"+ordnum+"'>"+
"<INPUT type=hidden name=pass value='"+pass+"'></form>\n");

//---end filters table 




//__________________________________________End Order #________________________
out.print("<form method=post action=/test/saverec target=_BLANK> <input type=hidden name=user value='"+name+"'>"+
"<INPUT type=hidden name=ordnum value='"+ordnum+"'> <input type=hidden name=pass value='"+pass+"'>"+
"<INPUT type=hidden name=restricted value='"+restricted+"'> <input type=hidden value=4 name=flag>" );

out.print( "<td><input type=submit value='View Order #"+ordnum+"'></td></form>\n");


//--------------------------------------------Test case ordering------------------------------

if(!name.equalsIgnoreCase("test"))
{


if(!cases.equalsIgnoreCase("Cases")) out.print("<td><form method=POST action=/test/catalog>");
if(cases.equalsIgnoreCase("Cases")) out.print("<td bgcolor=yellow><form method=POST action=/test/catalog>");

out.print("<select name=cases size=1 onchange=this.form.submit();><option selected>"+cases+ "</option>");

if(!cases.equalsIgnoreCase("Cases")) out.print("<option value='cases'>Order by Cases</option>"); 
if(!cases.equalsIgnoreCase("Individual Items"))out.print("<option value='Individual Items'>Order by the Piece</option>");

out.print("</select></td>\n");


out.print("<INPUT type=hidden name=name value='" +name+"'>"+
"<INPUT type=hidden name=restricted value='"+restricted+"'>"+
"<INPUT type=hidden name=ordnum value='"+ordnum+"'>"+
"<INPUT type=hidden name=pass value='"+pass+"'></form>\n");
}//------END HIDE ORDER METHOD FROM GUESTS
out.print("</table></div>\n");
//----------------------------------------------------------------------------------



//------------------This shouldset the first div height to the height of dc1 plus dc2.-------


divhak="<script language=javascript>\n";



divhak=divhak+"var dc1v = document.getElementById('dc1');\n";
divhak=divhak+"var dc2v = document.getElementById('dc2');\n";

divhak=divhak+"var d1h=dc1v.offsetHeight + dc2v.offsetHeight;\n";

divhak=divhak+"document.getElementById('firstdiv').style.height =d1h+7;\n";

divhak=divhak+"</script>\n";

out.print(divhak);





//______________________END QUERRY BUILDER FORM___________


 
//-----------------------------Displays querry results--------------------------------------     
//-----------------------------Displays querry results-------------------------------------- 
//-----------------------------Displays querry results-------------------------------------- 





out.print("<div id=d2 style='height=80%; width : 100%; overflow-y:scroll'> <table border='1' width=100% cellspacing=0 cellpadding=0>");


if(!cases.equalsIgnoreCase("Cases"))
{
out.print("<tr> <td id=c1>  Product#<td id=c2>Vendor<td id=c3> Size<td id=c4>Shot<td id=c5> Description<td id=c6>Qty Left<td id=c7>Per Case  <td id=c9>Group Type<td id=c10>Wholesale<td id=c11># Pieces Wanted<td id=c12> Arrival Date");  
}

if(cases.equalsIgnoreCase("Cases"))
{
out.print("<tr> <td id=c1>  Product#<td id=c2>Vendor<td id=c3> Size<td id=c4>Shot<td id=c5> Description<td id=c6>Qty Left<td id=c7>Per Case  <td id=c9>Group Type<td id=c10>Wholesale<td id=c11># Cases Wanted<td id=c12> Arrival Date");  

}

/*---------hide old headings
out.print("<tr> <td id=c1>  Product#<td id=c2>Vendor<td id=c3> Size<td id=c4>Shot<td id=c5> Description<td id=c6>Qty Left<td id=c7>Per Case  <td id=c9> ATF Type<td id=c10>Wholesale<td id=c11> Order Qty");  
--------end hide old headings */


int numCols = rs.getMetaData().getColumnCount ();
String temploc;
String trans="transit";
boolean istran=false;
String tempvid;
int tempcase=1;




//---below line gives rs field #s--------------------------------------------------
/*select ProductNumber 1, VendorNumber 2, Sizes 3, Shot 4, Description 5, QtyLeft 6, " + "PerCase 7, PerChain 8, groupname 9, Type 10, Wholesale 11, location 12, `Date Acquired` 13 , vid 14 , masternum 15 from FireOne where*/



                 while ( rs.next() )
		 {

if(rs.getString(7).equalsIgnoreCase("0"))
{
tempcase=1;
} else { tempcase=Integer.parseInt(rs.getString(7));}


		  out.print("<tr>");

//___________________sale price_________________________
if(rs.getString(1).equalsIgnoreCase("VUL620") ||rs.getString(1).equalsIgnoreCase("VUL630") || rs.getString(1).equalsIgnoreCase("JS70"))
{
linecolor="yellow";
}
else linecolor="white";
//_______________________end sale price____________________________________

                  temploc=rs.getString(12);
                  tempvid=rs.getString(14);
               	  for (int i=1; i<=numCols; i++) 
		  {



                    if(  i==1 && rs.getString(10).equalsIgnoreCase("assortment") ) out.print("<td bgcolor="+linecolor+">"+rs.getString(1)+"<form method=post action=/test/aview target=_BLANK>"+
"<input type=hidden name=product value='" +rs.getString(1)+"'> <input type=submit value='View Items'></form>");



if(  i==1 && !rs.getString(10).equalsIgnoreCase("assortment") && tempvid !=null && tempvid.length()!=0)
{
 out.print("<td bgcolor="+linecolor+">"+rs.getString(1)+"<br><a href='http://www.ampyro.com/video/" +rs.getString(15)+".wmv' target=_BLANK> Watch Video</a>");

//out.print("<td bgcolor="+linecolor+">"+rs.getString(1)+"<form method=post action=/test/wvideo target=_BLANK><input type=hidden name=product value='" +rs.getString(15)+"'><input type=submit value='Watch Video'></form>");

}


if(  i==1 && !rs.getString(10).equalsIgnoreCase("assortment") && ( tempvid ==null || tempvid.length()==0 ) ) out.print("<td bgcolor="+linecolor+">" + rs.getString(i) + "</td>" );

//---below line gives rs field #s
/*select ProductNumber 1, VendorNumber 2, Sizes 3, Shot 4, Description 5, QtyLeft 6, " + "PerCase 7, PerChain 8, groupname 9, Type 10, Wholesale 11, location 12, `Date Acquired` 13 , vid 14 , masternum 15 from FireOne where*/


                    //------Wholesale
                    if(i==11){

 if(!name.equalsIgnoreCase("test") && restricted.equalsIgnoreCase("no") && cases.equalsIgnoreCase("Individual Items") )
                          { out.print("<td bgcolor="+linecolor+">" + df.format(Float.parseFloat(rs.getString(i))) + "</td>" );}

//--------multiply cost * percase---------
 if(!name.equalsIgnoreCase("test") && restricted.equalsIgnoreCase("no") && cases.equalsIgnoreCase("Cases") )
    { out.print("<td bgcolor="+linecolor+">" + df.format(Float.parseFloat(rs.getString(i)) * tempcase ) + "</td>" );}


                    if(name.equalsIgnoreCase("test") || restricted.equalsIgnoreCase("yes"))
                          { out.print("<td bgcolor="+linecolor+">&nbsp;</td>" );}

                    }

                     //-----------Qty
                     if(i==6){

      if(!name.equalsIgnoreCase("test")&& restricted.equalsIgnoreCase("no") && cases.equalsIgnoreCase("Individual Items"))
                          { out.print("<td bgcolor="+linecolor+">" + rs.getString(i) + "</td>" );}

           if(!name.equalsIgnoreCase("test")&& restricted.equalsIgnoreCase("no") && cases.equalsIgnoreCase("Cases") )
                 { 
                 out.print("<td bgcolor="+linecolor+">" + (int)(Float.parseFloat(rs.getString(i)) / tempcase));

                if( tempcase != 1) out.print(" cs.");

                 out.print("</td>" );
                 }

                    if(name.equalsIgnoreCase("test")|| restricted.equalsIgnoreCase("yes"))
                          { out.print("<td>&nbsp;</td>" );}

                    }


                    if(i==5)
{

      out.print("<td bgcolor="+linecolor+">" + rs.getString(i) );
if(linecolor.equalsIgnoreCase("yellow")) out.print("   (SPECIAL SALE PRICE!!!)</td>");

}



                    if( (i!=1 && i!=5 && i!=6 && i!=8 && i!=10 && i!=11 && i!=12 && i !=13 && i != 14 && i != 15 && i != 16) ) out.print("<td bgcolor="+linecolor+">" + rs.getString(i) + "</td>" );

                     if(i==13 && temploc.equalsIgnoreCase(trans)) istran=true;


       }  // ----------end for


           

//---start incorperating order form into results--------------------

out.print("<td bgcolor="+linecolor+">");

if(restricted.equalsIgnoreCase("no")) out.print("<form method=post action=/test/saverec target=_BLANK onsubmit=");
if(restricted.equalsIgnoreCase("no")) out.print("'return checkForm(this);'>");

//---below line gives rs field #s
/*select ProductNumber 1, VendorNumber 2, Sizes 3, Shot 4, Description 5, QtyLeft 6, " + "PerCase 7, PerChain 8, groupname 9, Type 10, Wholesale 11, location 12, `Date Acquired` 13 , vid 14 , masternum 15 from FireOne where*/


//--------------------------------
if(restricted.equalsIgnoreCase("no") && cases.equalsIgnoreCase("Individual Items")) out.print("<input type=text name=qty size=4><input type=hidden name=qleft value='"+rs.getString(6)+"'><input type=hidden name=user value='"+name+"'><input type=hidden name=product value='"+rs.getString(1) +"'><input type=hidden value=1 name=flag><input type=hidden name=pass value='"+pass+"'>" +
"<INPUT type=hidden name=restricted value='"+restricted+"'>"+
"<INPUT type=hidden name=cases value='"+cases+"'>"+
"<INPUT type=hidden name=percase value='"+tempcase+"'>"+
"<INPUT type=hidden name=ordnum value='"+ordnum+"'>"+
"<input type=submit value=Add ></form>");


if(restricted.equalsIgnoreCase("no") && cases.equalsIgnoreCase("Cases")) out.print("<input type=text name=qty size=4><input type=hidden name=qleft value='"+Integer.parseInt(rs.getString(6))/ tempcase   +"'><input type=hidden name=user value='"+name+"'><input type=hidden name=product value='"+rs.getString(1) +"'><input type=hidden value=1 name=flag><input type=hidden name=pass value='"+pass+"'>" +
"<INPUT type=hidden name=restricted value='"+restricted+"'>"+
"<INPUT type=hidden name=cases value='"+cases+"'>"+
"<INPUT type=hidden name=percase value='"+tempcase+"'>"+
"<INPUT type=hidden name=ordnum value='"+ordnum+"'>"+
"<input type=submit value=Add ></form>");
//--------------------------------



//-----------hide arrival date
if(istran) out.print("<td><font color=red>" + rs.getString(13) + "</font></td>" );
if(!istran) out.print("<td>Here</td>" );
//----end arrival date hide
istran=false;

                  out.print("</tr>\n");
                  }  // ---------end while




out.print("</table>");

//---------------------------end querry display----------------------------------------

rs.close();
stmt.close();

vendorrs.close();
sizers.close();
shotrs.close();
grouprs.close();
typers.close();
ordnumrs.close();
maxorderrs.close();

validaters.close();

stmtvn.close();
stmtsz.close();
stmtsh.close();
stmttp.close();
stmttyp.close();
validate.close();
stordnum.close();
stmaxorder.close();
con.close();


out.print(" </div><div id=d3 style='height=35; overflow-y:scroll; '><table border='1' width=98% cellspacing=0 cellpadding=0 bgcolor=silver>");



out.print(" <tr> <td id=bottomcell > Product#<td >Vendor<td > Size<td >Shot<td > Description &nbsp; &nbsp;   (<b>Press Ctrl+F to search</b>)<td >Qty Left<td >Per Case <td > Group Type<td > Wholesale<td > Order Qty <td> Arrival Date");  

/* --------old headings
out.print(" <tr> <td > Product#<td >Vendor<td > Size<td >Shot<td > Description<td >Qty Left<td >Per Case <td > Group Type<td > Wholesale<td > Order Qty");  
-------End old headings */


//--------------------------------------------------------------------------------



divhak="<script language=javascript>\n";
divhak=divhak+"var dc1v = document.getElementById('dc1');\n";  //first filter cell
divhak=divhak+"var dc2v = document.getElementById('dc2');\n";  //2nd filter cell
divhak=divhak+"var d1h=dc1v.offsetHeight + dc2v.offsetHeight;\n"; // total height of filter cells

divhak=divhak+"var bc1v = document.getElementById('bottomcell');\n"; //
divhak=divhak+"var bc1h = bc1v.offsetHeight+7 \n"; // height of bottom cell


divhak=divhak+"var viewh= document.body.clientHeight;\n";

divhak=divhak+"document.getElementById('d2').style.height =viewh -(d1h+14)- bc1h -35;\n";

divhak=divhak+"</script>\n";

out.print(divhak);


//above is to try to resize inner frame to fit.----------------------------





jhak="<script language=javascript>";


jhak=jhak+"var c1 = document.getElementById('c1');";
jhak=jhak+"var c2 = document.getElementById('c2');";
jhak=jhak+"var c3 = document.getElementById('c3');";
jhak=jhak+"var c4 = document.getElementById('c4');";
jhak=jhak+"var c5 = document.getElementById('c5');";
jhak=jhak+"var c6 = document.getElementById('c6');";
jhak=jhak+"var c7 = document.getElementById('c7');";
//jhak=jhak+"var c8 = document.getElementById('c8');";
jhak=jhak+"var c9 = document.getElementById('c9');";
jhak=jhak+"var c10 = document.getElementById('c10');";
jhak=jhak+"var c11 = document.getElementById('c11');";
jhak=jhak+"var c12 = document.getElementById('c12');";

jhak=jhak+"document.write('<tr><td style=padding-left:',c1.offsetWidth-9,';>x');" ;
jhak=jhak+"document.write('<td style=padding-left:',c2.offsetWidth-9,';>x');" ;
jhak=jhak+"document.write('<td style=padding-left:',c3.offsetWidth-9,';>x');" ;
jhak=jhak+"document.write('<td style=padding-left:',c4.offsetWidth-9,';>x');" ;
jhak=jhak+"document.write('<td style=padding-left:',c5.offsetWidth-8,';>x');" ;
jhak=jhak+"document.write('<td style=padding-left:',c6.offsetWidth-9,';>x');" ;
jhak=jhak+"document.write('<td style=padding-left:',c7.offsetWidth-9,';>x');" ;
//jhak=jhak+"document.write('<td style=padding-left:',c8.offsetWidth-9,';>x');" ;
jhak=jhak+"document.write('<td style=padding-left:',c9.offsetWidth-9,';>x');" ;
jhak=jhak+"document.write('<td style=padding-left:',c10.offsetWidth-9,';>x');" ;
jhak=jhak+"document.write('<td style=padding-left:',c11.offsetWidth-9,';>x');" ;
jhak=jhak+"document.write('<td style=padding-left:',c12.offsetWidth-9,';>x');" ;
jhak=jhak+"</script>";
out.print(jhak);



//------------------------------------------------------------------------------




out.print("</body></html>");
}//-------------------end login if--------
else{out.print("<font size=6 color=red>Your login has failed!</font><br><br>"+
"<a href=login.html>Click Here to Try Again, good luck!</a>");}

 }  // end try
        catch (SQLException ex) {           
		
	        response.setContentType("text/html");			
		while (ex != null) {  
                	out.print ("SQL Exception:  " + ex.getMessage ());
                	ex = ex.getNextException ();  
              }  // end while
        }  // end catch SQLException

        catch (java.lang.Exception ex) {
      			response.setContentType("text/html");	
		out.print ("Exception:  " + ex.getMessage ());
	  }



    }// ------------end doget() function----------

}//------------end display prod class-------------

      
