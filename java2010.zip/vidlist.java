import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import java.text.*;
import java.util.*; 
import java.lang.String;


public class vidlist extends HttpServlet {


//--------------------Start the DoPost function-----------------------
     public void doPost(HttpServletRequest request, HttpServletResponse response)
     throws IOException {doGet(request, response); }// ------------end dopost() function----------


//______________________________Start doget()__________


public void doGet(HttpServletRequest request, HttpServletResponse response)
     throws IOException {


String browserType = request.getHeader("User-Agent");
browserType = browserType.toLowerCase();

String url="jdbc:mysql://localhost:3306/ampyro69_inventory?autoReconnect=true";
response.setContentType ("text/html;charset=utf-8");
PrintWriter out = response.getWriter();  

String vendor = request.getParameter("vendor"); //set from link



//---------------------------------------Output a form----------------

out.println("<html><style type='text/css' media=screen> body { margin:0; padding:0; height:100%;}</style><body>");



//------------------This fetches a recordset(filtered)-------------------------------------

/*
SELECT First(FireOne.VendorNumber) AS FirstOfVendorNumber, First(FireOne.Sizes) AS FirstOfSizes, First(FireOne.ATFtype) AS FirstOfATFtype, First(FireOne.Description) AS FirstOfDescription, First(FireOne.vid) AS FirstOfvid, FireOne.masternum
FROM FireOne
GROUP BY FireOne.masternum
HAVING (((First(FireOne.VendorNumber))="ampyro") AND ((First(FireOne.vid)) Is Not Null))
ORDER BY First(FireOne.Sizes), First(FireOne.ATFtype), First(FireOne.Description);

*/

String query = 
"select max(VendorNumber), max(Sizes) as firstsiz, max(Description) as firstdesc, max(ATFtype) as firstatf, max(vid) as firstvid , masternum from FireOne group by masternum having((max(VendorNumber) like '"
 + vendor + "')  AND max(vid) IS NOT NULL ) order by max(Sizes), max(ATFtype), max(Description)";

//


try{						
Class.forName  ("com.mysql.jdbc.Driver");
Connection con = DriverManager.getConnection(url, "ampyro69_Rob", "eugene19" );

Statement stmt = con.createStatement ();

ResultSet rs = stmt.executeQuery (query);//-----------gets data


//------------------end record fetcher----------------------------------------------------





//-----------------------------Displays querry results-------------------------------------- 



//query = "select 1 VendorNumber, 2 Sizes, 3 Description, 4 ATFtype, 5 vid , 6 masternum from FireOne
out.print("<h1> " +vendor +"</h1><p><p>");

out.print("<table border=0><tr><td><b>Prod # <td><b>Size<td><b>Video Link<td><b>Type");

                 while ( rs.next() )
		 {
         
 		  out.print("<tr><td>"+rs.getString(6)+ "<td>" +rs.getString(2)+ 
		  "<td><a href='http://www.ampyro.com/video/" +rs.getString(6)+".wmv' >"+ rs.getString(3) + "</a>");
        
out.println("<td>"+rs.getString(4));


                  out.println("</tr>");
                  }  // ---------end while




out.println("</table>");

//---------------------------end querry display----------------------------------------

rs.close();
stmt.close();

con.close();


out.println("</body></html>");



 }  // end try
        catch (SQLException ex) {           
		
	        response.setContentType("text/html");			
		while (ex != null) {  
                	out.println ("SQL Exception:  " + ex.getMessage ());
                	ex = ex.getNextException ();  
              }  // end while
        }  // end catch SQLException

        catch (java.lang.Exception ex) {
      			response.setContentType("text/html");	
		out.println ("Exception:  " + ex.getMessage ());
	  }

    }// ------------end doget() function----------

}//------------end vidlist class-------------

      
